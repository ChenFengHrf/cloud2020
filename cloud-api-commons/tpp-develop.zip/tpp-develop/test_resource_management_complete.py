#!/usr/bin/env python3
"""
完整的资源管理测试脚本
测试资源的注册、查询、刷新和信息功能
"""

import asyncio
import os
import sys
import json
from pathlib import Path

# 添加项目路径到sys.path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root / "src"))

from tpp.core.resource import ResourceManager
from tpp.core.FlowCLI import FlowCLI


class ResourceManagementTester:
    """资源管理测试器"""
    
    def __init__(self, working_directory: str = None):
        self.working_directory = working_directory or str(project_root)
        self.resource_manager = ResourceManager(self.working_directory)
        self.flow_cli = FlowCLI(self.working_directory)
        
    async def initialize(self):
        """初始化测试环境"""
        print("🚀 初始化资源管理测试环境...")
        await self.resource_manager.initialize()
        await self.flow_cli.initialize()
        print("✅ 初始化完成\n")
    
    async def test_resource_discovery(self):
        """测试资源发现功能"""
        print("🔍 测试资源发现功能...")
        print("-" * 50)
        
        # 刷新资源发现
        success = await self.resource_manager.refresh_resources()
        print(f"资源刷新: {'✅ 成功' if success else '❌ 失败'}")
        
        # 获取统计信息
        stats = self.resource_manager.get_stats()
        print(f"工作目录: {stats['working_directory']}")
        print(f"支持协议: {', '.join(stats['protocols'])}")
        print(f"总资源数: {stats['total_resources']}")
        print("按类型分布:")
        for res_type, count in stats['resources_by_type'].items():
            print(f"  {res_type}: {count}")
        print()
    
    async def test_manual_registration(self):
        """测试手动注册资源"""
        print("📝 测试手动注册资源...")
        print("-" * 50)
        
        # 定义测试资源
        test_resources = [
            {
                "id": "test-role-assistant",
                "type": "role",
                "reference": "file://src/tpp/agents/assistant.py"
            },
            {
                "id": "test-tool-calculator",
                "type": "tool", 
                "reference": "file://src/tpp/tool/calculator.py"
            },
            {
                "id": "test-manual-python",
                "type": "manual",
                "reference": "file://docs/python-guide.md"
            },
            {
                "id": "test-execution-best-practice",
                "type": "execution",
                "reference": "execution://best-practice"
            },
            {
                "id": "test-knowledge-programming",
                "type": "knowledge",
                "reference": "knowledge://programming"
            },
            {
                "id": "test-thought-creativity",
                "type": "thought",
                "reference": "thought://creativity"
            },
            {
                "id": "test-prompt-welcome",
                "type": "prompt",
                "reference": "prompt://system/welcome"
            },
            {
                "id": "test-project-src",
                "type": "project",
                "reference": "project://src"
            },
            {
                "id": "test-user-config",
                "type": "user",
                "reference": "user://config"
            },
            {
                "id": "test-package-lodash",
                "type": "package",
                "reference": "package://lodash"
            }
        ]
        
        # 注册测试资源
        for resource in test_resources:
            success = await self.resource_manager.register_resource(
                resource["id"], 
                resource["type"], 
                resource["reference"]
            )
            status = "✅ 成功" if success else "❌ 失败"
            print(f"注册 {resource['id']}: {status}")
        
        print()
    
    async def test_resource_listing(self):
        """测试资源列表功能"""
        print("📋 测试资源列表功能...")
        print("-" * 50)
        
        # 列出所有资源
        all_resources = self.resource_manager.list_resources()
        print(f"所有资源 (总计: {len(all_resources)}):")
        for resource in all_resources:
            print(f"  {resource['id']:<25} [{resource['type']}] - {resource['reference']}")
        print()
        
        # 按类型列出资源
        resource_types = ["role", "tool", "manual", "execution", "knowledge", "thought", "prompt", "project", "user", "package"]
        for res_type in resource_types:
            type_resources = self.resource_manager.list_resources(res_type)
            if type_resources:
                print(f"{res_type.upper()} 资源 (总计: {len(type_resources)}):")
                for resource in type_resources:
                    print(f"  {resource['id']:<25} - {resource['reference']}")
                print()
    
    async def test_resource_info(self):
        """测试资源信息功能"""
        print("ℹ️  测试资源信息功能...")
        print("-" * 50)
        
        # 获取所有资源的信息
        all_resources = self.resource_manager.list_resources()
        
        for resource in all_resources[:5]:  # 只显示前5个资源的详细信息
            resource_id = resource['id']
            metadata = self.resource_manager.get_resource_metadata(resource_id)
            
            if metadata:
                print(f"📄 资源信息: {resource_id}")
                print(f"  ID: {metadata['id']}")
                print(f"  类型: {metadata['type']}")
                print(f"  引用: {metadata['reference']}")
                print(f"  创建时间: {metadata['created_at']}")
                print(f"  更新时间: {metadata['updated_at']}")
                if metadata.get('metadata'):
                    print("  元数据:")
                    for key, value in metadata['metadata'].items():
                        print(f"    {key}: {value}")
                print()
    
    async def test_resource_loading(self):
        """测试资源加载功能"""
        print("📥 测试资源加载功能...")
        print("-" * 50)
        
        # 测试加载不同协议的资源
        test_references = [
            "execution://best-practice",
            "knowledge://programming", 
            "thought://creativity",
            "prompt://system/welcome",
            "project://src",
            "user://config"
        ]
        
        for reference in test_references:
            try:
                content = await self.resource_manager.load_resource(reference)
                print(f"✅ 成功加载: {reference}")
                print(f"   内容长度: {len(content)} 字符")
                # 显示内容预览
                preview = content[:100] + "..." if len(content) > 100 else content
                print(f"   预览: {preview}")
                print()
            except Exception as e:
                print(f"❌ 加载失败: {reference} - {e}")
                print()
    
    async def test_cli_integration(self):
        """测试CLI集成功能"""
        print("🖥️  测试CLI集成功能...")
        print("-" * 50)
        
        # 测试CLI资源命令
        cli_commands = [
            ["list"],
            ["stats"],
            ["refresh"],
            ["info", "test-role-assistant"],
            ["register", "cli-test-resource", "tool", "file://test.py"]
        ]
        
        for cmd_args in cli_commands:
            try:
                result = await self.flow_cli._handle_resource_command(cmd_args, silent=True)
                print(f"✅ CLI命令 'resource {' '.join(cmd_args)}': 成功")
                if "error" in result:
                    print(f"   错误: {result['error']}")
                else:
                    print(f"   结果类型: {type(result.get('content', 'N/A'))}")
                print()
            except Exception as e:
                print(f"❌ CLI命令 'resource {' '.join(cmd_args)}': 失败 - {e}")
                print()
    
    async def test_protocol_support(self):
        """测试协议支持"""
        print("🔗 测试协议支持...")
        print("-" * 50)
        
        # 获取支持的协议
        protocols = self.resource_manager.get_available_protocols()
        print(f"支持的协议 (总计: {len(protocols)}):")
        for protocol in protocols:
            print(f"  {protocol}")
        print()
        
        # 测试协议支持检查
        test_protocols = ["file", "role", "tool", "manual", "execution", "knowledge", "thought", "prompt", "project", "user", "package", "resource"]
        for protocol in test_protocols:
            supported = self.resource_manager.supports_protocol(protocol)
            status = "✅ 支持" if supported else "❌ 不支持"
            print(f"  {protocol}://: {status}")
        print()
    
    async def generate_summary_report(self):
        """生成总结报告"""
        print("📊 生成总结报告...")
        print("=" * 60)
        
        # 获取最新统计
        stats = self.resource_manager.get_stats()
        all_resources = self.resource_manager.list_resources()
        
        report = {
            "测试时间": str(asyncio.get_event_loop().time()),
            "工作目录": stats['working_directory'],
            "资源管理器状态": {
                "已初始化": stats['initialized'],
                "支持协议数": len(stats['protocols']),
                "总资源数": stats['total_resources']
            },
            "协议支持": stats['protocols'],
            "资源分布": stats['resources_by_type'],
            "资源列表": [
                {
                    "id": r['id'],
                    "type": r['type'], 
                    "reference": r['reference']
                } for r in all_resources
            ]
        }
        
        print(json.dumps(report, indent=2, ensure_ascii=False))
        
        # 保存报告到文件
        report_file = project_root / "resource_management_test_report.json"
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        print(f"\n📄 报告已保存到: {report_file}")
    
    async def run_all_tests(self):
        """运行所有测试"""
        print("🧪 开始完整的资源管理测试")
        print("=" * 60)
        
        try:
            await self.initialize()
            await self.test_resource_discovery()
            await self.test_manual_registration()
            await self.test_resource_listing()
            await self.test_resource_info()
            await self.test_resource_loading()
            await self.test_cli_integration()
            await self.test_protocol_support()
            await self.generate_summary_report()
            
            print("\n🎉 所有测试完成!")
            
        except Exception as e:
            print(f"\n❌ 测试过程中出现错误: {e}")
            import traceback
            traceback.print_exc()


async def main():
    """主函数"""
    tester = ResourceManagementTester()
    await tester.run_all_tests()


if __name__ == "__main__":
    asyncio.run(main())