#!/usr/bin/env python3
"""
资源管理功能演示脚本
展示FlowCLI中集成的资源管理功能
"""

import sys
import os
import asyncio
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from tpp.core.FlowCLI import FlowCLI

async def demo_resource_management():
    """演示资源管理功能"""
    print("🚀 FlowCLI 资源管理功能演示")
    print("=" * 50)
    
    # 初始化FlowCLI
    cli = FlowCLI()
    
    print("\n1. 查看系统状态")
    print("-" * 30)
    status_result = await cli.execute("status")
    print(f"状态: {status_result}")
    
    print("\n2. 查看支持的协议")
    print("-" * 30)
    protocols = cli.resource_manager.get_available_protocols()
    print(f"支持的协议: {protocols}")
    
    print("\n3. 注册一个测试角色资源")
    print("-" * 30)
    register_result = await cli.execute("resource", ["register", "role://test-assistant", "AI助手角色"])
    print(f"注册结果: {register_result}")
    
    print("\n4. 注册一个工具资源")
    print("-" * 30)
    tool_result = await cli.execute("resource", ["register", "tool://calculator", "计算器工具"])
    print(f"工具注册结果: {tool_result}")
    
    print("\n5. 列出所有资源")
    print("-" * 30)
    list_result = await cli.execute("resource", ["list"])
    print(f"资源列表: {list_result}")
    
    print("\n6. 查看资源统计")
    print("-" * 30)
    stats_result = await cli.execute("resource", ["stats"])
    print(f"资源统计: {stats_result}")
    
    print("\n7. 获取特定资源信息")
    print("-" * 30)
    info_result = await cli.execute("resource", ["info", "test-assistant"])
    print(f"资源信息: {info_result}")
    
    print("\n8. 刷新资源")
    print("-" * 30)
    refresh_result = await cli.execute("resource", ["refresh"])
    print(f"刷新结果: {refresh_result}")
    
    print("\n9. 查看帮助信息")
    print("-" * 30)
    help_result = await cli.execute("help")
    print("帮助信息已显示（包含资源管理命令）")
    
    print("\n✨ 演示完成！")
    print("资源管理功能已成功集成到FlowCLI中")

if __name__ == "__main__":
    asyncio.run(demo_resource_management())