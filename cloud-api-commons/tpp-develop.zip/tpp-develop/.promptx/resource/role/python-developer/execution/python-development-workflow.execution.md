<execution>
  <constraint>
    ## Python Development Constraints
    
    ### Technical Constraints
    - **Python Version**: Target Python 3.8+ unless otherwise specified
    - **Dependencies**: Use only well-maintained, widely-adopted libraries
    - **Standards Compliance**: Follow PEP 8 for code style and PEP 257 for docstrings
    - **Testing Requirements**: All code must be accompanied by appropriate tests
    
    ### Project Constraints
    - **Tool Integration**: Work within the TPP Develop MCP framework
    - **Documentation**: Maintain clear, up-to-date documentation
    - **Security**: Follow security best practices and avoid common vulnerabilities
  </constraint>
  
  <rule>
    ## Development Rules
    
    ### Coding Standards
    - Follow PEP 8 style guide for Python code
    - Use type hints for function parameters and return values
    - Write docstrings for all public modules, classes, and functions
    - Name variables and functions descriptively
    
    ### Testing Requirements
    - Write unit tests for all new functionality
    - Use pytest as the testing framework
    - Maintain test coverage above 80%
    - Include both positive and negative test cases
    
    ### Code Review Process
    - All code changes must be reviewed before merging
    - Address all review comments before merging
    - Keep pull requests small and focused
  </rule>
  
  <guideline>
    ## Development Guidelines
    
    ### Best Practices
    - **Keep It Simple**: Prefer simple solutions over complex ones
    - **Fail Fast**: Handle errors early and explicitly
    - **Be Pythonic**: Use Python idioms and patterns appropriately
    - **Think Security**: Consider security implications of code changes
    
    ### Tool Recommendations
    - **Formatting**: Use Black for automatic code formatting
    - **Import Sorting**: Use isort to organize imports
    - **Linting**: Use flake8 or pylint for static analysis
    - **Type Checking**: Use mypy for type validation
    
    ### Documentation Guidelines
    - Document why decisions were made, not just what was done
    - Keep README and other documentation up-to-date with code changes
    - Use examples to illustrate complex functionality
  </guideline>
  
  <process>
    ## Python Development Workflow
    
    ### Initial Setup
    1. Set up virtual environment
    2. Install dependencies
    3. Configure development tools (linters, formatters, etc.)
    4. Verify setup with a simple test
    
    ### Development Cycle
    1. **Plan**: Understand requirements and design approach
    2. **Implement**: Write clean, well-documented code
    3. **Test**: Run tests and ensure all pass
    4. **Review**: Check code quality and address any issues
    5. **Document**: Update documentation as needed
    6. **Commit**: Make focused commits with clear messages
    
    ### Code Quality Checks
    1. Run linter (flake8/pylint)
    2. Run formatter (black)
    3. Run type checker (mypy)
    4. Run security scanner (bandit)
    5. Run tests with coverage report
  </process>
  
  <criteria>
    ## Quality Evaluation Criteria
    
    ### Code Quality Metrics
    - **Style Compliance**: Code follows PEP 8 guidelines
    - **Test Coverage**: Minimum 80% code coverage
    - **Documentation**: Clear docstrings and inline comments
    - **Performance**: No obvious bottlenecks or inefficiencies
    
    ### Review Standards
    - **Correctness**: Code works as intended and handles edge cases
    - **Clarity**: Code is readable and well-structured
    - **Maintainability**: Code is easy to modify and extend
    - **Security**: No obvious security vulnerabilities
    
    ### Acceptance Criteria
    - All tests pass
    - Linter reports no errors
    - Code coverage meets minimum requirements
    - Documentation is updated
    - Peer review is completed
  </criteria>
</execution>