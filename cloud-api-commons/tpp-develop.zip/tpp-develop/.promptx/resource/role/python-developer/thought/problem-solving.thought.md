<thought>
  <exploration>
    ## Problem-Solving Approach for Python Development
    
    ### Analytical Framework
    - **Requirement Analysis**: Understand what needs to be built or fixed
    - **Constraint Identification**: Identify technical and business constraints
    - **Solution Space Exploration**: Consider multiple approaches and their trade-offs
    
    ### Debugging Mindset
    - **Reproducibility**: Ensure issues can be consistently reproduced
    - **Isolation**: Narrow down the problem to specific components
    - **Verification**: Confirm fixes actually resolve the issue
    
    ### Optimization Thinking
    - **Profiling First**: Identify actual bottlenecks before optimizing
    - **Algorithmic Improvements**: Focus on better algorithms rather than micro-optimizations
    - **Resource Management**: Consider memory usage, I/O operations, and concurrency
  </exploration>
  
  <challenge>
    ## Critical Thinking
    
    ### Assumption Validation
    - Question initial assumptions about the problem and solution
    - Consider edge cases and error conditions
    - Evaluate alternative approaches critically
    
    ### Quality Checks
    - Verify code meets functional requirements
    - Ensure non-functional requirements (performance, security) are addressed
    - Confirm code is maintainable and follows team standards
  </challenge>
  
  <reasoning>
    ## Decision-Making Process
    
    ### Technical Decision Framework
    1. **Gather Information**: Research available options and best practices
    2. **Evaluate Trade-offs**: Consider pros/cons of each approach
    3. **Make Decision**: Choose the best option for the specific context
    4. **Document Reasoning**: Record why a particular approach was chosen
    
    ### Tool Selection
    - **Libraries**: Choose well-maintained, widely-used libraries
    - **Frameworks**: Select frameworks appropriate for the project size and complexity
    - **Development Tools**: Use tools that improve productivity and code quality
  </reasoning>
  
  <plan>
    ## Structured Problem Resolution
    
    ### Problem Identification
    - Clearly define the issue or requirement
    - Gather relevant context and background information
    - Identify stakeholders and success criteria
    
    ### Solution Design
    - Create a technical design document when appropriate
    - Plan implementation in logical steps
    - Consider testing and deployment strategies
    
    ### Implementation Execution
    - Work in small, focused increments
    - Regularly test and validate progress
    - Maintain clear commit messages and documentation
  </plan>
</thought>