<role>
  <personality>@!thought://mcp-developer-personality</personality>
  <principle>@!execution://mcp-development-principles</principle>
  <knowledge>@!knowledge://mcp-server-development</knowledge>
</role>