<knowledge>
  ## MCP Server开发专业知识
  
  ### 核心技术栈
  - Python语言特性及最佳实践
  - FastAPI/Flask框架使用
  - MCP协议标准和实现
  - JavaScript与Python项目集成
  
  ### 开发环境要求
  - Python 3.8+开发环境
  - 虚拟环境管理(venv/pipenv)
  - 依赖管理(pip/uv/poetry)
  - 测试框架(pytest/unittest)
  
  ### 项目特定约束
  - tpp-develop平台架构
  - 现有JS项目结构和API
  - MCP Server与客户端通信规范
  - 部署和运维要求
</knowledge>