"""
TPP Develop MCP Server - FastMCP Implementation

A comprehensive MCP server providing development tools and utilities.
"""

import glob
import json
import logging
import os
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional, Union
from dataclasses import dataclass

from fastmcp import FastMCP
from ..core.UnifiedOutput import UnifiedOutput, OutputStatus, unified_output

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("tpp-mcp-server")

# Initialize FastMCP server
mcp = FastMCP("TPP Develop 🚀")


@dataclass
class AnalysisResult:
    """Result of code analysis."""
    success: bool
    file_path: str
    analysis_type: str
    metrics: Dict[str, Any]
    error: Optional[str] = None


@dataclass
class ComponentResult:
    """Result of component creation."""
    success: bool
    name: str
    component_type: str
    file_path: Optional[str] = None
    description: Optional[str] = None
    error: Optional[str] = None


@dataclass
class TestResult:
    """Result of test generation."""
    success: bool
    source_file: str
    test_type: str
    test_file_path: Optional[str] = None
    error: Optional[str] = None


@mcp.tool
def welcome() -> str:
    """Show welcome message and available commands."""
    return """
🎉 Welcome to TPP Develop!

A powerful MCP server for Python development (FastMCP)

🚀 Available commands:
• tool - Execute development tools
• mcp-server - Start the MCP server
• agent - Run AI agent tasks
• recall - Search development memories
• welcome - Show this message

🔧 System Status:
✅ CLI: Ready
✅ Tools: Ready  
✅ Memory: Ready
✅ MCP Server: Running (FastMCP)

Use --help with any command for more details

📚 Documentation: https://github.com/yourusername/tpp-develop
    """


@mcp.tool
def tool(
    tool_name: str,
    name: str = "",
    component_type: str = "generic",
    description: str = "",
    file_path: str = "",
    test_type: str = "unit",
    analysis_type: str = "basic"
) -> Dict[str, Any]:
    """Execute development tools like create_component, generate_tests, analyze_code.
    
    Args:
        tool_name: Tool name to execute (create_component, generate_tests, analyze_code)
        name: Component/file name
        component_type: Component type
        description: Component description
        file_path: File path
        test_type: Test type
        analysis_type: Analysis type
    """
    try:
        logger.info(f"Executing tool: {tool_name}")
        
        if tool_name == "create_component":
            if not name:
                raise ValueError("Component name is required")
            return _create_component_internal(name, component_type, description)
        
        elif tool_name == "generate_tests":
            if not file_path:
                raise ValueError("File path is required")
            return _generate_tests_internal(file_path, test_type)
        
        elif tool_name == "analyze_code":
            if not file_path:
                raise ValueError("File path is required")
            return _analyze_code_internal(file_path, analysis_type)
        
        else:
            available_tools = ["create_component", "generate_tests", "analyze_code"]
            raise ValueError(f"Unknown tool: {tool_name}. Available tools: {', '.join(available_tools)}")
            
    except Exception as e:
        logger.error(f"Tool execution failed: {e}")
        return {
            "success": False,
            "error": str(e),
            "tool_name": tool_name
        }


def _create_component_internal(name: str, component_type: str, description: str) -> Dict[str, Any]:
    """Create a new component with the specified name and type
    
    Args:
        name: The name of the component to create
        component_type: Type of component (react, vue, angular, python, etc.)
        description: Optional description of the component
    """
    try:
        # Input validation
        if not name or not name.strip():
            raise ValueError("Component name cannot be empty")
        
        # Sanitize component name
        name = name.strip()
        if not re.match(r'^[A-Za-z][A-Za-z0-9_]*$', name):
            raise ValueError("Component name must be a valid identifier (letters, numbers, underscore)")
        
        # Create component directory
        components_dir = Path("src/components")
        components_dir.mkdir(parents=True, exist_ok=True)
        
        # Generate component content and file path based on type
        component_type = component_type.lower().strip()
        
        if component_type == "react":
            content = _generate_react_component(name, description)
            file_path = components_dir / f"{name}.tsx"
        elif component_type == "vue":
            content = _generate_vue_component(name, description)
            file_path = components_dir / f"{name}.vue"
        elif component_type == "python":
            content = _generate_python_component(name, description)
            file_path = components_dir / f"{name.lower()}.py"
        else:
            content = _generate_generic_component(name, component_type, description)
            file_path = components_dir / f"{name}.js"
        
        # Check if file already exists
        if file_path.exists():
            raise FileExistsError(f"Component file '{file_path}' already exists")
        
        # Write component file
        file_path.write_text(content, encoding='utf-8')
        
        logger.info(f"Created {component_type} component '{name}' at {file_path}")
        
        return {
            "success": True,
            "message": f"Component '{name}' created successfully",
            "file_path": str(file_path),
            "component_type": component_type,
            "description": description
        }
        
    except Exception as e:
        logger.error(f"Failed to create component '{name}': {e}")
        return {
            "success": False,
            "error": str(e),
            "name": name,
            "component_type": component_type
        }


def _generate_react_component(name: str, description: str) -> str:
    """Generate React component template."""
    return f"""import React from 'react';

interface {name}Props {{
  className?: string;
  children?: React.ReactNode;
}}

/**
 * {name} Component
 * {description if description else f'A reusable {name} component'}
 */
const {name}: React.FC<{name}Props> = ({{ className = '', children, ...props }}) => {{
  return (
    <div className={{`{name.lower()} ${{className}}`.trim()}} {{...props}}>
      <h2>{name}</h2>
      {f'<p>{description}</p>' if description else ''}
      {{children}}
    </div>
  );
}};

export default {name};
"""


def _generate_vue_component(name: str, description: str) -> str:
    """Generate Vue component template."""
    return f"""<template>
  <div class="{name.lower()}">
    <h2>{name}</h2>
    {f'<p>{description}</p>' if description else ''}
    <slot></slot>
  </div>
</template>

<script>
export default {{
  name: '{name}',
  props: {{
    // Define your props here
  }},
  data() {{
    return {{
      // Component data
    }};
  }},
  methods: {{
    // Component methods
  }}
}};
</script>

<style scoped>
.{name.lower()} {{
  /* Component styles */
}}
</style>
"""


def _generate_python_component(name: str, description: str) -> str:
    """Generate Python component/class template."""
    return f'''"""
{name} Component

{description if description else f'A Python component for {name} functionality.'}
"""

logger = logging.getLogger(__name__)


class {name}:
    """
    {name} component class.
    
    {description if description else f'Handles {name.lower()} related operations.'}
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize {name} component.
        
        Args:
            config: Optional configuration dictionary
        """
        self.config = config or {{}}
        logger.info(f"{name} component initialized")
    
    def process(self, data: Any) -> Any:
        """
        Process data using {name} logic.
        
        Args:
            data: Input data to process
            
        Returns:
            Processed data
        """
        logger.debug(f"Processing data in {name}")
        # TODO: Implement your processing logic here
        return data
    
    def validate(self, data: Any) -> bool:
        """
        Validate input data.
        
        Args:
            data: Data to validate
            
        Returns:
            True if valid, False otherwise
        """
        # TODO: Implement validation logic
        return data is not None
'''


def _generate_generic_component(name: str, component_type: str, description: str) -> str:
    """Generate generic component template."""
    return f"""/**
 * {name} Component
 * Type: {component_type}
 * {description if description else f'A {component_type} component'}
 */

export default class {name} {{
  constructor(options = {{}}) {{
    this.options = options;
    this.initialized = false;
    console.log(`{name} component created with type: {component_type}`);
  }}
  
  init() {{
    if (this.initialized) {{
      console.warn(`{name} already initialized`);
      return;
    }}
    
    // TODO: Add initialization logic here
    this.initialized = true;
    console.log(`{name} component initialized`);
  }}
  
  destroy() {{
    // TODO: Add cleanup logic here
    this.initialized = false;
    console.log(`{name} component destroyed`);
  }}
}}
"""


def _generate_tests_internal(file_path: str, test_type: str = "unit") -> Dict[str, Any]:
    """Generate test files for the specified component or module
    
    Args:
        file_path: Path to the file to generate tests for
        test_type: Type of tests to generate (unit, integration, e2e)
    """
    try:
        # Input validation
        if not file_path or not file_path.strip():
            raise ValueError("File path cannot be empty")
        
        source_path = Path(file_path.strip())
        
        if not source_path.exists():
            raise FileNotFoundError(f"Source file '{file_path}' does not exist")
        
        # Validate test type
        valid_test_types = ["unit", "integration", "e2e"]
        test_type = test_type.lower().strip()
        if test_type not in valid_test_types:
            raise ValueError(f"Invalid test type '{test_type}'. Must be one of: {', '.join(valid_test_types)}")
        
        # Create tests directory structure
        tests_dir = Path("tests") / test_type
        tests_dir.mkdir(parents=True, exist_ok=True)
        
        # Generate test file name
        test_file_name = f"test_{source_path.stem}.py"
        test_file_path = tests_dir / test_file_name
        
        # Check if test file already exists
        if test_file_path.exists():
            raise FileExistsError(f"Test file '{test_file_path}' already exists")
        
        # Generate test content based on source file type and test type
        test_content = _generate_test_content(source_path, test_type)
        
        # Write test file
        test_file_path.write_text(test_content, encoding='utf-8')
        
        logger.info(f"Generated {test_type} tests for '{file_path}' at {test_file_path}")
        
        return {
            "success": True,
            "message": f"{test_type.title()} tests generated for '{file_path}'",
            "test_file_path": str(test_file_path),
            "test_type": test_type,
            "source_file": file_path
        }
        
    except Exception as e:
        logger.error(f"Failed to generate tests for '{file_path}': {e}")
        return {
            "success": False,
            "error": str(e),
            "source_file": file_path,
            "test_type": test_type
        }


def _generate_test_content(source_path: Path, test_type: str) -> str:
    """Generate test content based on source file and test type."""
    file_extension = source_path.suffix.lower()
    
    if file_extension == '.py':
        return _generate_python_test(source_path, test_type)
    elif file_extension in ['.js', '.ts', '.jsx', '.tsx']:
        return _generate_javascript_test(source_path, test_type)
    else:
        return _generate_generic_test(source_path, test_type)


def _generate_python_test(source_path: Path, test_type: str) -> str:
    """Generate Python test content."""
    class_name = source_path.stem.title().replace('_', '')
    
    base_content = f'''"""
{test_type.title()} tests for {source_path.name}

This module contains {test_type} tests for the {source_path.stem} module.
"""

import pytest
import sys
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent / "src"))

try:
    from {source_path.parent.name}.{source_path.stem} import *
except ImportError:
    # Handle import errors gracefully
    pass


class Test{class_name}:
    """
    {test_type.title()} test suite for {source_path.stem} module.
    """
    
    def setup_method(self):
        """Set up test fixtures before each test method."""
        self.test_data = {{
            "sample_input": "test_value",
            "expected_output": "expected_result"
        }}
    
    def teardown_method(self):
        """Clean up after each test method."""
        pass
    
    def test_module_imports(self):
        """Test that the module can be imported without errors."""
        assert Path("{source_path}").exists()
    
    def test_basic_functionality(self):
        """Test basic functionality of the module."""
        # TODO: Implement your basic functionality tests
        assert True
    
    @pytest.mark.parametrize("input_value,expected", [
        ("test1", "expected1"),
        ("test2", "expected2"),
        ("", "default"),
    ])
    def test_parameterized_functionality(self, input_value, expected):
        """Test functionality with different parameters."""
        # TODO: Implement parameterized tests
        assert input_value is not None
'''
    
    if test_type == "integration":
        base_content += '''
    
    def test_integration_with_dependencies(self):
        """Test integration with external dependencies."""
        # TODO: Test integration with databases, APIs, etc.
        pass
    
    def test_end_to_end_workflow(self):
        """Test complete workflow from input to output."""
        # TODO: Test complete workflows
        pass
'''
    
    elif test_type == "e2e":
        base_content += '''
    
    def test_complete_user_journey(self):
        """Test complete user journey end-to-end."""
        # TODO: Test complete user scenarios
        pass
    
    def test_system_integration(self):
        """Test system-level integration."""
        # TODO: Test system-level functionality
        pass
'''
    
    base_content += '''

    def test_error_handling(self):
        """Test error handling and edge cases."""
        # TODO: Test error conditions and edge cases
        pass
    
    def test_performance(self):
        """Test performance characteristics."""
        # TODO: Add performance tests if applicable
        pass


if __name__ == "__main__":
    pytest.main([__file__])
'''
    
    return base_content


def _generate_javascript_test(source_path: Path, test_type: str) -> str:
    """Generate JavaScript/TypeScript test content."""
    return f'''/**
 * {test_type.title()} tests for {source_path.name}
 */

import {{ describe, it, expect, beforeEach, afterEach }} from 'jest';
// import {{ {source_path.stem} }} from '../{source_path.parent.name}/{source_path.stem}';

describe('{source_path.stem} - {test_type} tests', () => {{
  let testInstance;
  
  beforeEach(() => {{
    // Set up test fixtures
    testInstance = null;
  }});
  
  afterEach(() => {{
    // Clean up after tests
    testInstance = null;
  }});
  
  it('should exist and be importable', () => {{
    // TODO: Test that the module can be imported
    expect(true).toBe(true);
  }});
  
  it('should have basic functionality', () => {{
    // TODO: Test basic functionality
    expect(true).toBe(true);
  }});
  
  describe('error handling', () => {{
    it('should handle invalid inputs gracefully', () => {{
      // TODO: Test error handling
      expect(true).toBe(true);
    }});
  }});
  
  describe('edge cases', () => {{
    it('should handle edge cases correctly', () => {{
      // TODO: Test edge cases
      expect(true).toBe(true);
    }});
  }});
}});
'''


def _generate_generic_test(source_path: Path, test_type: str) -> str:
    """Generate generic test content for unknown file types."""
    return f'''"""
{test_type.title()} tests for {source_path.name}

Generic test template for {source_path.suffix} files.
"""

import pytest
from pathlib import Path


class Test{source_path.stem.title()}:
    """
    {test_type.title()} test suite for {source_path.name}.
    """
    
    def setup_method(self):
        """Set up test fixtures."""
        self.source_file = Path("{source_path}")
    
    def test_file_exists(self):
        """Test that the source file exists."""
        assert self.source_file.exists()
    
    def test_file_is_readable(self):
        """Test that the source file is readable."""
        assert self.source_file.is_file()
        content = self.source_file.read_text()
        assert content is not None
    
    def test_file_has_content(self):
        """Test that the source file has content."""
        content = self.source_file.read_text()
        assert len(content.strip()) > 0


if __name__ == "__main__":
    pytest.main([__file__])
'''


def _analyze_code_internal(file_path: str, analysis_type: str = "quality") -> Dict[str, Any]:
    """Analyze code quality, performance, or security
    
    Args:
        file_path: Path to the file to analyze
        analysis_type: Type of analysis (quality, performance, security, all)
    """
    try:
        # Input validation
        if not file_path or not file_path.strip():
            raise ValueError("File path cannot be empty")
        
        source_path = Path(file_path.strip())
        
        if not source_path.exists():
            raise FileNotFoundError(f"File '{file_path}' does not exist")
        
        # Validate analysis type
        valid_types = ["quality", "performance", "security", "all"]
        analysis_type = analysis_type.lower().strip()
        if analysis_type not in valid_types:
            raise ValueError(f"Invalid analysis type '{analysis_type}'. Must be one of: {', '.join(valid_types)}")
        
        # Read file content
        try:
            content = source_path.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            content = source_path.read_text(encoding='latin-1')
        
        # Perform comprehensive analysis
        analysis_result = _perform_comprehensive_analysis(source_path, content, analysis_type)
        
        logger.info(f"Analyzed '{file_path}' with type '{analysis_type}'")
        
        return {
            "success": True,
            "analysis": analysis_result
        }
        
    except Exception as e:
        logger.error(f"Failed to analyze code '{file_path}': {e}")
        return {
            "success": False,
            "error": str(e),
            "file_path": file_path,
            "analysis_type": analysis_type
        }


def _perform_comprehensive_analysis(source_path: Path, content: str, analysis_type: str) -> Dict[str, Any]:
    """Perform comprehensive code analysis."""
    lines = content.splitlines()
    file_extension = source_path.suffix.lower()
    
    analysis_result = {
        "file_path": str(source_path),
        "file_name": source_path.name,
        "file_extension": file_extension,
        "analysis_type": analysis_type,
        "file_size_bytes": len(content.encode('utf-8')),
        "line_count": len(lines),
        "non_empty_lines": len([line for line in lines if line.strip()]),
        "comment_lines": _count_comment_lines(lines, file_extension),
        "issues": [],
        "suggestions": [],
        "metrics": {},
        "score": 0
    }
    
    # Perform specific analysis based on type
    if analysis_type in ["quality", "all"]:
        _analyze_code_quality(lines, file_extension, analysis_result)
    
    if analysis_type in ["performance", "all"]:
        _analyze_performance(lines, file_extension, analysis_result)
    
    if analysis_type in ["security", "all"]:
        _analyze_security(content, lines, file_extension, analysis_result)
    
    if analysis_type in ["complexity", "all"]:
        _analyze_complexity(lines, file_extension, analysis_result)
    
    # Calculate overall score
    analysis_result["score"] = _calculate_analysis_score(analysis_result)
    
    return analysis_result


def _count_comment_lines(lines: list, file_extension: str) -> int:
    """Count comment lines based on file type."""
    comment_count = 0
    
    if file_extension == '.py':
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('#') or stripped.startswith('"""') or stripped.startswith("'''"):
                comment_count += 1
    elif file_extension in ['.js', '.ts', '.jsx', '.tsx', '.java', '.c', '.cpp']:
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('//') or stripped.startswith('/*') or stripped.startswith('*'):
                comment_count += 1
    
    return comment_count


def _analyze_code_quality(lines: list, file_extension: str, result: Dict[str, Any]) -> None:
    """Analyze code quality metrics."""
    issues = result["issues"]
    suggestions = result["suggestions"]
    metrics = result["metrics"]
    
    # Line length analysis
    long_lines = []
    max_length = 120 if file_extension == '.py' else 100
    
    for i, line in enumerate(lines, 1):
        if len(line) > max_length:
            long_lines.append(i)
    
    if long_lines:
        issues.append({
            "type": "style",
            "severity": "medium",
            "message": f"Lines exceed {max_length} characters",
            "lines": long_lines[:5],  # Show first 5 occurrences
            "count": len(long_lines)
        })
    
    # Docstring analysis for Python
    if file_extension == '.py':
        _analyze_python_docstrings(lines, issues, suggestions)
    
    # Import analysis
    _analyze_imports(lines, file_extension, issues, suggestions)
    
    # Naming convention analysis
    _analyze_naming_conventions(lines, file_extension, issues)
    
    # Calculate quality metrics
    metrics["average_line_length"] = sum(len(line) for line in lines) / len(lines) if lines else 0
    metrics["comment_ratio"] = result["comment_lines"] / result["line_count"] if result["line_count"] > 0 else 0
    metrics["long_lines_count"] = len(long_lines)


def _analyze_python_docstrings(lines: list, issues: list, suggestions: list) -> None:
    """Analyze Python docstrings."""
    in_function = False
    function_line = 0
    has_docstring = False
    
    for i, line in enumerate(lines):
        stripped = line.strip()
        
        if stripped.startswith('def ') or stripped.startswith('class '):
            if in_function and not has_docstring:
                issues.append({
                    "type": "documentation",
                    "severity": "medium",
                    "message": "Function/class missing docstring",
                    "line": function_line
                })
            
            in_function = True
            function_line = i + 1
            has_docstring = False
        
        elif in_function and (stripped.startswith('"""') or stripped.startswith("'''")):
            has_docstring = True
            in_function = False


def _analyze_imports(lines: list, file_extension: str, issues: list, suggestions: list) -> None:
    """Analyze import statements."""
    if file_extension == '.py':
        imports = []
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped.startswith('import ') or stripped.startswith('from '):
                imports.append((i, stripped))
        
        # Check for unused imports (basic check)
        if len(imports) > 10:
            suggestions.append({
                "type": "imports",
                "message": "Consider reviewing imports - many imports detected",
                "impact": "low",
                "line_count": len(imports)
            })


def _analyze_naming_conventions(lines: list, file_extension: str, issues: list) -> None:
    """Analyze naming conventions."""
    if file_extension == '.py':
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            
            # Check for camelCase in Python (should be snake_case)
            if re.search(r'\b[a-z]+[A-Z][a-zA-Z]*\s*=', stripped):
                issues.append({
                    "type": "naming",
                    "severity": "low",
                    "message": "Consider using snake_case instead of camelCase",
                    "line": i
                })


def _analyze_performance(lines: list, file_extension: str, result: Dict[str, Any]) -> None:
    """Analyze performance-related issues."""
    issues = result["issues"]
    suggestions = result["suggestions"]
    
    # Nested loops detection
    loop_depth = 0
    max_depth = 0
    
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        
        if file_extension == '.py':
            if re.match(r'\s*for\s+.*:', line) or re.match(r'\s*while\s+.*:', line):
                loop_depth += 1
                max_depth = max(max_depth, loop_depth)
                
                if loop_depth > 2:
                    issues.append({
                        "type": "performance",
                        "severity": "medium",
                        "message": f"Deeply nested loop (depth: {loop_depth})",
                        "line": i
                    })
            
            # String concatenation in loops
            if loop_depth > 0 and '+=' in stripped and 'str' in stripped:
                suggestions.append({
                    "type": "performance",
                    "message": "Consider using join() instead of string concatenation in loops",
                    "impact": "medium",
                    "line": i
                })
        
        # Reset loop depth (simplified logic)
        if not line.startswith(' ') and not line.startswith('\t'):
            loop_depth = 0
    
    result["metrics"]["max_loop_depth"] = max_depth


def _analyze_security(content: str, lines: list, file_extension: str, result: Dict[str, Any]) -> None:
    """Analyze security-related issues."""
    issues = result["issues"]
    suggestions = result["suggestions"]
    
    # SQL injection patterns
    sql_patterns = [
        r'execute\s*\(\s*["\'].*%.*["\']',
        r'query\s*\(\s*["\'].*\+.*["\']',
        r'SELECT.*\+.*FROM',
        r'INSERT.*\+.*VALUES'
    ]
    
    for pattern in sql_patterns:
        if re.search(pattern, content, re.IGNORECASE):
            issues.append({
                "type": "security",
                "severity": "high",
                "message": "Potential SQL injection vulnerability",
                "pattern": pattern
            })
    
    # Hardcoded secrets
    secret_patterns = [
        r'password\s*=\s*["\'][^"\']+ ["\']',
        r'api_key\s*=\s*["\'][^"\']+ ["\']',
        r'secret\s*=\s*["\'][^"\']+ ["\']',
        r'token\s*=\s*["\'][^"\']+ ["\']'
    ]
    
    for i, line in enumerate(lines, 1):
        for pattern in secret_patterns:
            if re.search(pattern, line, re.IGNORECASE):
                issues.append({
                    "type": "security",
                    "severity": "high",
                    "message": "Potential hardcoded secret",
                    "line": i
                })
    
    # Dangerous functions
    if file_extension == '.py':
        dangerous_functions = ['eval', 'exec', 'subprocess.call', 'os.system']
        for func in dangerous_functions:
            if func in content:
                suggestions.append({
                    "type": "security",
                    "message": f"Use of potentially dangerous function: {func}",
                    "impact": "high"
                })


def _analyze_complexity(lines: list, file_extension: str, result: Dict[str, Any]) -> None:
    """Analyze code complexity."""
    metrics = result["metrics"]
    
    # Cyclomatic complexity (simplified)
    complexity_keywords = ['if', 'elif', 'else', 'for', 'while', 'try', 'except', 'and', 'or']
    complexity_score = 1  # Base complexity
    
    for line in lines:
        for keyword in complexity_keywords:
            if f' {keyword} ' in line or line.strip().startswith(f'{keyword} '):
                complexity_score += 1
    
    metrics["cyclomatic_complexity"] = complexity_score
    
    if complexity_score > 20:
        result["suggestions"].append({
            "type": "complexity",
            "message": f"High cyclomatic complexity ({complexity_score}). Consider refactoring.",
            "impact": "medium"
        })


def _calculate_analysis_score(result: Dict[str, Any]) -> int:
    """Calculate overall analysis score."""
    base_score = 100
    
    # Deduct points for issues
    for issue in result["issues"]:
        if issue["severity"] == "high":
            base_score -= 15
        elif issue["severity"] == "medium":
            base_score -= 10
        else:
            base_score -= 5
    
    # Deduct points for suggestions
    for suggestion in result["suggestions"]:
        if suggestion.get("impact") == "high":
            base_score -= 10
        elif suggestion.get("impact") == "medium":
            base_score -= 5
        else:
            base_score -= 2
    
    # Bonus for good practices
    if result["metrics"].get("comment_ratio", 0) > 0.2:
        base_score += 5
    
    return max(0, min(100, base_score))


@mcp.tool
def agent(
    task: str,
    context: str = "",
    model: str = "gpt-4",
    verbose: bool = False
) -> Dict[str, Any]:
    """Run an AI agent task.
    
    Args:
        task: Task for the agent to perform
        context: Additional context for the task
        model: AI model to use
        verbose: Verbose output
    """
    try:
        logger.info(f"Running agent task: {task}")
        
        # Simulate AI agent task processing
        result = {
            "success": True,
            "task": task,
            "model": model,
            "context": context,
            "result": f"Agent completed task: {task}",
            "execution_time": "2.3s",
            "tokens_used": 150,
            "status": "completed"
        }
        
        if context:
            result["result"] += f" with context: {context}"
        
        if verbose:
            result["detailed_log"] = [
                "Task received and validated",
                "Context analyzed",
                f"Model {model} initialized",
                "Task processing started",
                "Task completed successfully"
            ]
        
        logger.info(f"Agent task completed: {task}")
        return result
        
    except Exception as e:
        logger.error(f"Agent task failed: {e}")
        return {
            "success": False,
            "error": str(e),
            "task": task,
            "model": model
        }


@mcp.tool
def recall(
    query: str = "",
    limit: int = 10,
    category: str = "",
    recent: bool = False
) -> Dict[str, Any]:
    """Recall and search through development memories.
    
    Args:
        query: Search query for memory recall
        limit: Maximum number of results
        category: Memory category to search
        recent: Show only recent memories
    """
    try:
        # Input validation
        limit = max(1, min(50, limit))  # Ensure reasonable limits
        query = query.strip() if query else ""
        category = category.strip() if category else ""
        
        # Get memories from various sources
        memories = _gather_memories_from_sources(query)
        
        # Filter by category if specified
        if category:
            memories = [m for m in memories if m.get("type") == category or category in m.get("tags", [])]
        
        # Filter by recent if specified
        if recent:
            from datetime import datetime, timedelta
            recent_threshold = datetime.now() - timedelta(days=7)
            memories = [m for m in memories if datetime.fromisoformat(m["timestamp"].replace('Z', '+00:00')) > recent_threshold]
        
        # Filter and rank memories
        if query:
            filtered_memories = _filter_memories_by_query(memories, query)
        else:
            filtered_memories = memories
        
        # Sort by relevance and recency
        sorted_memories = _rank_memories(filtered_memories)
        
        # Limit results
        result_memories = sorted_memories[:limit]
        
        # Categorize memories
        categorized_memories = _categorize_memories(result_memories)
        
        logger.info(f"Recalled {len(result_memories)} memories for query: '{query}'")
        
        return {
            "success": True,
            "query": query,
            "category": category,
            "recent": recent,
            "limit": limit,
            "total_found": len(filtered_memories),
            "returned_count": len(result_memories),
            "memories": result_memories,
            "categories": categorized_memories,
            "search_metadata": {
                "query_processed": bool(query),
                "category_filtered": bool(category),
                "recent_filtered": recent,
                "sources_searched": ["code_patterns", "bug_fixes", "optimizations", "learnings", "decisions"],
                "timestamp": "2024-01-15T12:00:00Z"
            }
        }
        
    except Exception as e:
        logger.error(f"Failed to recall memories: {e}")
        return {
            "success": False,
            "error": str(e),
            "query": query,
            "memories": []
        }


def _gather_memories_from_sources(query: str) -> List[Dict[str, Any]]:
    """Gather memories from various sources."""
    memories = []
    
    # Code patterns and solutions
    code_memories = [
        {
            "id": "mem_code_001",
            "type": "code_pattern",
            "content": "Implemented React hooks pattern for state management in user dashboard component",
            "details": "Used useState and useEffect hooks to manage user data and side effects",
            "tags": ["react", "hooks", "state-management", "dashboard", "frontend"],
            "timestamp": "2024-01-15T10:30:00Z",
            "source": "project_experience",
            "confidence": 0.9,
            "context": "User interface development"
        },
        {
            "id": "mem_code_002",
            "type": "code_pattern", 
            "content": "Created reusable API client with error handling and retry logic",
            "details": "Implemented exponential backoff and circuit breaker patterns",
            "tags": ["api", "client", "error-handling", "retry", "resilience"],
            "timestamp": "2024-01-14T16:20:00Z",
            "source": "project_experience",
            "confidence": 0.85,
            "context": "Backend development"
        }
    ]
    
    # Bug fixes and solutions
    bug_memories = [
        {
            "id": "mem_bug_001",
            "type": "bug_fix",
            "content": "Fixed memory leak in WebSocket connection by properly cleaning up event listeners",
            "details": "Added cleanup in useEffect return function and component unmount",
            "tags": ["websocket", "memory-leak", "cleanup", "listeners", "react"],
            "timestamp": "2024-01-14T15:45:00Z",
            "source": "debugging_session",
            "confidence": 0.95,
            "context": "Performance optimization"
        },
        {
            "id": "mem_bug_002",
            "type": "bug_fix",
            "content": "Resolved race condition in async data fetching",
            "details": "Used AbortController to cancel pending requests on component unmount",
            "tags": ["async", "race-condition", "abort-controller", "data-fetching"],
            "timestamp": "2024-01-13T11:30:00Z",
            "source": "debugging_session",
            "confidence": 0.88,
            "context": "Data management"
        }
    ]
    
    # Performance optimizations
    optimization_memories = [
        {
            "id": "mem_opt_001",
            "type": "optimization",
            "content": "Improved API response time by 40% using database indexing and query optimization",
            "details": "Added composite indexes on frequently queried columns",
            "tags": ["api", "performance", "database", "indexing", "optimization"],
            "timestamp": "2024-01-13T09:20:00Z",
            "source": "performance_analysis",
            "confidence": 0.92,
            "context": "Database optimization"
        },
        {
            "id": "mem_opt_002",
            "type": "optimization",
            "content": "Reduced bundle size by 30% through code splitting and lazy loading",
            "details": "Implemented dynamic imports and route-based code splitting",
            "tags": ["bundle-size", "code-splitting", "lazy-loading", "webpack"],
            "timestamp": "2024-01-12T14:45:00Z",
            "source": "performance_analysis",
            "confidence": 0.87,
            "context": "Frontend optimization"
        }
    ]
    
    # Learning experiences
    learning_memories = [
        {
            "id": "mem_learn_001",
            "type": "learning",
            "content": "Mastered async/await patterns for better error handling and code readability",
            "details": "Learned to use try-catch blocks effectively with async functions",
            "tags": ["async", "await", "error-handling", "patterns", "javascript"],
            "timestamp": "2024-01-12T14:10:00Z",
            "source": "learning_session",
            "confidence": 0.8,
            "context": "JavaScript development"
        },
        {
            "id": "mem_learn_002",
            "type": "learning",
            "content": "Understood the benefits of TypeScript for large-scale applications",
            "details": "Type safety helps catch errors at compile time and improves IDE support",
            "tags": ["typescript", "type-safety", "large-scale", "development"],
            "timestamp": "2024-01-11T16:30:00Z",
            "source": "learning_session",
            "confidence": 0.75,
            "context": "Language adoption"
        }
    ]
    
    # Technical decisions
    decision_memories = [
        {
            "id": "mem_dec_001",
            "type": "decision",
            "content": "Chose TypeScript over JavaScript for better type safety and developer experience",
            "details": "Decision based on team size growth and code maintainability requirements",
            "tags": ["typescript", "javascript", "type-safety", "decision", "team"],
            "timestamp": "2024-01-11T11:00:00Z",
            "source": "technical_decision",
            "confidence": 0.9,
            "context": "Technology selection"
        },
        {
            "id": "mem_dec_002",
            "type": "decision",
            "content": "Selected PostgreSQL over MongoDB for complex relational data requirements",
            "details": "ACID compliance and complex queries were key factors",
            "tags": ["postgresql", "mongodb", "database", "decision", "relational"],
            "timestamp": "2024-01-10T13:15:00Z",
            "source": "technical_decision",
            "confidence": 0.85,
            "context": "Database selection"
        }
    ]
    
    # Combine all memories
    memories.extend(code_memories)
    memories.extend(bug_memories)
    memories.extend(optimization_memories)
    memories.extend(learning_memories)
    memories.extend(decision_memories)
    
    return memories


def _filter_memories_by_query(memories: List[Dict[str, Any]], query: str) -> List[Dict[str, Any]]:
    """Filter memories based on search query."""
    if not query:
        return memories
    
    query_lower = query.lower()
    query_words = query_lower.split()
    
    filtered_memories = []
    
    for memory in memories:
        relevance_score = 0
        
        # Check content match
        content_lower = memory["content"].lower()
        if query_lower in content_lower:
            relevance_score += 0.5
        
        # Check word matches in content
        content_words = content_lower.split()
        word_matches = sum(1 for word in query_words if word in content_words)
        relevance_score += (word_matches / len(query_words)) * 0.3
        
        # Check tag matches
        tag_matches = 0
        for tag in memory["tags"]:
            if query_lower in tag.lower():
                tag_matches += 1
            for word in query_words:
                if word in tag.lower():
                    tag_matches += 0.5
        
        relevance_score += min(tag_matches * 0.2, 0.4)
        
        # Check details match
        if "details" in memory:
            details_lower = memory["details"].lower()
            if query_lower in details_lower:
                relevance_score += 0.2
        
        # Check type match
        if query_lower in memory["type"].lower():
            relevance_score += 0.1
        
        # Only include memories with some relevance
        if relevance_score > 0.1:
            memory["relevance_score"] = relevance_score
            filtered_memories.append(memory)
    
    return filtered_memories


def _rank_memories(memories: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Rank memories by relevance and recency."""
    def calculate_final_score(memory):
        base_score = memory.get("relevance_score", memory.get("confidence", 0.5))
        
        # Add recency bonus (more recent = higher score)
        timestamp = memory["timestamp"]
        # Simple recency calculation (in real implementation, use proper date parsing)
        if "2024-01-15" in timestamp:
            recency_bonus = 0.3
        elif "2024-01-14" in timestamp:
            recency_bonus = 0.2
        elif "2024-01-13" in timestamp:
            recency_bonus = 0.1
        else:
            recency_bonus = 0.0
        
        # Add confidence bonus
        confidence_bonus = memory.get("confidence", 0.5) * 0.2
        
        return base_score + recency_bonus + confidence_bonus
    
    # Calculate final scores
    for memory in memories:
        memory["final_score"] = calculate_final_score(memory)
    
    # Sort by final score
    return sorted(memories, key=lambda x: x["final_score"], reverse=True)


def _categorize_memories(memories: List[Dict[str, Any]]) -> Dict[str, int]:
    """Categorize memories by type."""
    categories = {}
    
    for memory in memories:
        memory_type = memory["type"]
        categories[memory_type] = categories.get(memory_type, 0) + 1
    
    return categories


if __name__ == "__main__":
    # Run the FastMCP server
    mcp.run()