"""TPP Develop MCP Server

This module implements the Model Context Protocol (MCP) server for TPP Develop,
providing tools for code generation, test generation, and code analysis.
"""


def cli_main() -> None:
    """Synchronous entry point for the command line interface."""
    print("TPP Develop MCP Server")
    # asyncio.run(main())


if __name__ == "__main__":
    cli_main()