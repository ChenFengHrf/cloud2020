"""
TPP CLI应用程序

提供命令行接口来访问TPP的各种功能。
集成新的输出系统、状态管理和命令架构。
"""

import typer
import asyncio
import uuid
from typing import Optional, List, Dict, Any
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text

try:
    # 尝试相对导入（当作为模块运行时）
    from .core.CommandManager import command_manager
    from .core.UnifiedOutput import OutputStatus
    from .core.state.StateManager import state_manager
    from .core.UnifiedOutput import (
        unified_output, print_banner, print_success, print_error, print_warning, 
        print_info, create_table, create_unified_panel, status, progress, confirm, prompt
    )
except ImportError:
    # 回退到绝对导入（当直接运行时）
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    
    from core.CommandManager import command_manager
    from core.UnifiedOutput import OutputStatus
    from core.state.StateManager import state_manager
    from core.UnifiedOutput import (
        unified_output, print_banner, print_success, print_error, print_warning, 
        print_info, create_table, create_unified_panel, status, progress, confirm, prompt
    )

app = typer.Typer(
    name="tpp",
    help="🚀 TPP (Tool-Powered Programming) - 现代化开发环境",
    add_completion=False,
    rich_markup_mode="rich"
)

console = unified_output.console
# 使用unified_output替代output_formatter

# 全局会话ID，用于CLI会话
CLI_SESSION_ID = str(uuid.uuid4())


def format_and_display_output(output: 'UnifiedOutput'):
    """格式化并显示输出"""
    try:
        formatted = output.to_human()
        console.print(formatted)
    except Exception as e:
        print_error("输出格式化错误", str(e))
        console.print(f"Raw output: {output}")


@app.command()
def tool(
    name: Optional[str] = typer.Argument(None, help="🔧 工具名称"),
    list_tools: bool = typer.Option(False, "--list", "-l", help="📋 列出可用工具"),
    category: Optional[str] = typer.Option(None, "--category", "-c", help="🏷️ 按类别筛选"),
    args: Optional[List[str]] = typer.Argument(None, help="⚙️ 工具参数")
):
    """🔧 执行开发工具 - 增强输出和状态管理"""
    
    if list_tools:
        with status("正在加载工具列表", "dots"):
            commands = command_manager.list_commands(category)
            stats = command_manager.get_execution_stats()
        
        # 准备表格数据
        columns = [
            {"name": "🔧 工具名称", "key": "name", "style": "bold cyan"},
            {"name": "📝 用途", "key": "purpose", "style": "green"},
            {"name": "🏷️ 类别", "key": "category", "style": "blue"},
            {"name": "📦 版本", "key": "version", "style": "yellow"},
            {"name": "🔄 执行次数", "key": "execution_count", "style": "magenta"},
            {"name": "✅ 成功率", "key": "success_rate", "style": "bright_green", "format": "status"}
        ]
        
        # 格式化数据
        table_data = []
        for cmd in commands:
            success_rate = f"{cmd['success_rate']:.1%}" if cmd['success_rate'] > 0 else "N/A"
            table_data.append({
                "name": cmd['name'],
                "purpose": cmd['purpose'][:50] + "..." if len(cmd['purpose']) > 50 else cmd['purpose'],
                "category": cmd['category'],
                "version": cmd['version'],
                "execution_count": str(cmd['execution_count']),
                "success_rate": success_rate
            })
        
        # 创建统一面板
        panel = unified_output.create_unified_panel(
            title="TPP 开发工具",
            sections=[
                {
                    "type": "table",
                    "title": "可用工具",
                    "columns": columns,
                    "data": table_data
                },
                {
                    "type": "stats",
                    "title": "工具统计",
                    "data": {
                        "总工具数": stats['total_commands'],
                        "总执行次数": stats['total_executions'],
                        "整体成功率": stats['overall_success_rate']
                    }
                },
                {
                    "type": "info",
                    "data": "💡 使用 'tpp tool <工具名> --help' 查看具体工具的使用方法"
                }
            ],
            border_style="cyan",
            emoji="🔧"
        )
        
        console.print(panel)
        return
    
    if not name:
        print_error("缺少工具名称", "请指定要执行的工具名称")
        print_info("提示", "使用 --list 查看可用工具")
        return
    
    try:
        with status(f"正在执行工具 '{name}'", "bouncingBall"):
            # 执行工具
            result = asyncio.run(command_manager.execute_command(
                name, args, CLI_SESSION_ID, silent_mode=False
            ))
        
        if result.status == OutputStatus.SUCCESS:
            print_success(f"工具 '{name}' 执行成功", "所有操作已完成")
        else:
            print_error(f"工具 '{name}' 执行失败", "请检查参数和配置")
        
        format_and_display_output(result)
        
    except Exception as e:
        print_error(f"执行工具 '{name}' 时出错", str(e))


@app.command()
def agent(
    action: Optional[str] = typer.Argument(None, help="🤖 智能体操作 (list, activate, action, info, recall, remember, status)"),
    role_id: Optional[str] = typer.Argument(None, help="👤 角色ID"),
    content: Optional[str] = typer.Argument(None, help="📝 内容 (用于remember操作)"),
    role: Optional[str] = typer.Option(None, "--role", "-r", help="👤 智能体角色 (兼容旧版本)"),
    filter_type: Optional[str] = typer.Option(None, "--filter", "-f", help="🔍 过滤类型 (roles)"),
    query: Optional[str] = typer.Option(None, "--query", "-q", help="🔍 查询内容 (用于recall)")
):
    """🤖 管理AI智能体 - 增强版 (支持角色资源查询、记忆操作)"""
    
    if not action:
        commands = [
            {"name": "list [roles]", "description": "列出所有智能体或角色资源", "usage": "tpp agent list roles"},
            {"name": "activate <role_id>", "description": "激活AI智能体角色", "usage": "tpp agent activate mcp-developer"},
            {"name": "action <role_id>", "description": "激活角色并执行action", "usage": "tpp agent action mcp-developer"},
            {"name": "info <role_id>", "description": "查询角色详细信息", "usage": "tpp agent info mcp-developer"},
            {"name": "recall <role_id> [--query <查询>]", "description": "检索角色记忆", "usage": "tpp agent recall mcp-developer --query 项目"},
            {"name": "remember <role_id> <内容>", "description": "为角色添加记忆", "usage": "tpp agent remember mcp-developer '项目配置已更新'"},
            {"name": "status", "description": "显示智能体状态", "usage": "tpp agent status"}
        ]
        unified_output.print_help_panel(commands, "🤖 智能体操作 (增强版)")
        return
    
    # 构建参数列表
    args = [action]
    
    # 处理role_id参数
    if role_id:
        args.append(role_id)
    elif role:  # 兼容旧版本的--role参数
        args.append(role)
    
    # 处理特殊操作的参数
    if action == "list" and filter_type:
        args.append(filter_type)
    elif action == "recall" and query:
        if len(args) > 1:  # 确保有role_id
            args.append(query)
    elif action == "remember" and content:
        if len(args) > 1:  # 确保有role_id
            args.extend(content.split())
    
    try:
        with status(f"正在执行智能体操作: {action}", "dots"):
            # 使用增强的AgentCommand
            result = asyncio.run(command_manager.execute_command(
                "agent", args, CLI_SESSION_ID, silent_mode=False
            ))
        
        if result.status == OutputStatus.SUCCESS:
            print_success(f"智能体操作 '{action}' 执行成功", "操作已完成")
        else:
            print_error(f"智能体操作 '{action}' 执行失败", "请检查参数和配置")
        
        format_and_display_output(result)
        
    except Exception as e:
        print_error(f"执行智能体操作 '{action}' 时出错", str(e))
        
        # 显示旧版本兼容的模拟数据
        if action == "list":
            with status("正在加载智能体列表", "dots"):
                agents_data = [
                    {"role": "mcp-developer", "description": "MCP开发专家", "status": "available"},
                    {"role": "python-expert", "description": "Python编程专家", "status": "available"},
                    {"role": "architect", "description": "系统架构专家", "status": "available"},
                    {"role": "frontend-dev", "description": "前端开发专家", "status": "available"},
                    {"role": "devops", "description": "DevOps运维专家", "status": "available"}
                ]
            
            columns = [
                {"name": "👤 角色", "key": "role", "style": "bold cyan"},
                {"name": "📝 描述", "key": "description", "style": "green"},
                {"name": "📊 状态", "key": "status", "style": "yellow", "format": "status"}
            ]
            
            # 创建统一Panel
            sections = [
                {
                    "type": "table",
                    "title": "可用智能体角色",
                    "columns": columns,
                    "data": agents_data
                },
                {
                    "type": "stats",
                    "title": "智能体统计",
                    "data": {
                        "可用角色": len(agents_data),
                        "活跃智能体": 0,
                        "集成状态": "开发中"
                    }
                },
                {
                    "type": "info",
                    "data": "PromptX智能体集成即将推出"
                }
            ]
            
            panel = unified_output.create_unified_panel("🤖 AI 智能体管理", sections, "green", "🤖")
            console.print(panel)
        elif action == "status":
            print_info("智能体状态", "当前没有活跃的智能体")
        elif action == "deactivate":
            print_info("停用智能体", "当前没有活跃的智能体需要停用")
        else:
            print_error("未知操作", f"操作 '{action}' 不存在")


@app.command()
def recall(
    query: Optional[str] = typer.Argument(None, help="🧠 记忆查询"),
    list_memories: bool = typer.Option(False, "--list", "-l", help="📋 列出存储的记忆")
):
    """🧠 记忆管理和回忆 - PromptX集成"""
    
    if list_memories:
        with status("正在加载记忆列表", "dots"):
            # 模拟加载记忆
            import time
            time.sleep(0.5)
        
        # 显示示例记忆数据
        memory_data = [
            {"id": "mem_001", "content": "Python项目配置", "timestamp": "2024-01-15", "tags": "python,config"},
            {"id": "mem_002", "content": "MCP服务器设置", "timestamp": "2024-01-14", "tags": "mcp,server"},
            {"id": "mem_003", "content": "CLI优化方案", "timestamp": "2024-01-13", "tags": "cli,ui"}
        ]
        
        columns = [
            {"name": "🆔 ID", "key": "id", "style": "cyan"},
            {"name": "📝 内容", "key": "content", "style": "green"},
            {"name": "📅 时间", "key": "timestamp", "style": "yellow"},
            {"name": "🏷️ 标签", "key": "tags", "style": "blue"}
        ]
        
        # 创建统一Panel
        sections = [
            {
                "type": "table",
                "title": "存储的记忆",
                "columns": columns,
                "data": memory_data
            },
            {
                "type": "stats",
                "title": "记忆统计",
                "data": {
                    "总记忆数": len(memory_data),
                    "最新记忆": "2024-01-15",
                    "存储状态": "正常"
                }
            },
            {
                "type": "info",
                "data": "PromptX记忆集成即将推出"
            }
        ]
        
        panel = unified_output.create_unified_panel("🧠 记忆管理系统", sections, "purple", "🧠")
        console.print(panel)
        return
    
    if not query:
        commands = [
            {"name": "recall <查询>", "description": "搜索记忆", "usage": "tpp recall python配置"},
            {"name": "recall --list", "description": "列出所有记忆", "usage": "tpp recall --list"},
            {"name": "recall --format json <查询>", "description": "JSON格式输出", "usage": "tpp recall --format json 项目"}
        ]
        unified_output.print_help_panel(commands, "🧠 记忆回忆使用")
        return
    
    with status(f"正在搜索记忆: {query}", "dots"):
        # 模拟搜索过程
        import time
        time.sleep(1)
    
    print_success(f"记忆搜索完成", f"查询: {query}")
    print_warning("注意", "PromptX记忆集成即将推出")


@app.command()
def resource(
    action: str = typer.Argument(..., help="资源管理操作 (list, stats, refresh, info, register)"),
    resource_id: Optional[str] = typer.Argument(None, help="资源ID"),
    resource_type: Optional[str] = typer.Option(None, "--type", "-t", help="资源类型 (role, tool, manual)"),
    reference: Optional[str] = typer.Option(None, "--ref", "-r", help="资源引用"),
    format_output: str = typer.Option("human", "--format", "-f", help="输出格式")
):
    """🔧 资源管理命令"""
    
    try:
        output_format = format_output.lower()
    except ValueError:
        print_error("无效格式", f"格式 '{format_output}' 不支持")
        return
    
    # 构建命令参数
    args = [action]
    if resource_id:
        args.append(resource_id)
    if resource_type and action == "list":
        args.append(resource_type)
    elif resource_type and action == "register":
        args.extend([resource_type, reference or ""])
    
    try:
        # 使用FlowCLI执行资源命令
        try:
            from .core.FlowCLI import FlowCLI
        except ImportError:
            # 如果相对导入失败，尝试绝对导入
            import sys
            import os
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from core.FlowCLI import FlowCLI
        
        flow_cli = FlowCLI()
        
        # 确保FlowCLI已初始化
        async def run_resource_command():
            await flow_cli.initialize()
            return await flow_cli._handle_resource_command(
                args, silent=(output_format != "human")
            )
        
        result = asyncio.run(run_resource_command())
        
        if output_format != "human":
            # 将结果转换为UnifiedOutput对象
            try:
                from .core.UnifiedOutput import UnifiedOutput, OutputStatus
            except ImportError:
                from core.UnifiedOutput import UnifiedOutput, OutputStatus
            if "error" in result:
                unified_result = UnifiedOutput(
                    status=OutputStatus.ERROR,
                    message=result["error"],
                    data=result
                )
            else:
                unified_result = UnifiedOutput(
                    status=OutputStatus.SUCCESS,
                    message="Resource command executed successfully",
                    data=result
                )
            format_and_display_output(unified_result)
        
    except Exception as e:
        print_error("资源管理命令执行失败", str(e))


@app.command()
def mcp_server(
    protocol: str = typer.Option("stdio", "--protocol", help="Protocol to use (stdio, sse)"),
    port: int = typer.Option(8000, "--port", "-p", help="Server port"),
    host: str = typer.Option("localhost", "--host", "-h", help="Server host"),
    debug: bool = typer.Option(False, "--debug", help="Enable debug mode")
):
    """Start the MCP server."""
    try:
        console.print(f"[bold blue]🚀 Starting TPP Develop MCP Server...[/bold blue]")
        console.print(f"[dim]Protocol: {protocol}[/dim]")
        console.print(f"[dim]Host: {host}[/dim]")
        console.print(f"[dim]Port: {port}[/dim]")
        
        if protocol == "stdio":
            # Start stdio MCP server
            console.print("[yellow]Starting stdio MCP server...[/yellow]")
            from .mcp.mcp_server import mcp
            console.print("[green]✅ MCP server (stdio) started successfully[/green]")
            console.print("[dim]Use Ctrl+C to stop the server[/dim]")
            mcp.run()
            
        elif protocol == "sse":
            # Start SSE MCP server
            console.print(f"[yellow]Starting SSE MCP server on {host}:{port}...[/yellow]")
            # Import and start SSE server
            import uvicorn
            from .mcp.mcp_server import mcp
            console.print(f"[green]✅ MCP server (SSE) started on http://{host}:{port}[/green]")
            console.print("[dim]Use Ctrl+C to stop the server[/dim]")
            uvicorn.run(mcp.http_app(transport="sse"), host=host, port=port, log_level="info" if debug else "warning")
            
        else:
            console.print(f"[red]❌ Unsupported protocol: {protocol}[/red]")
            console.print("[yellow]Supported protocols: stdio, sse[/yellow]")
            raise typer.Exit(1)
            
    except KeyboardInterrupt:
        console.print("\n[yellow]⏹️ MCP server stopped by user[/yellow]")
    except Exception as e:
        console.print(f"[red]❌ Error starting MCP server: {e}[/red]")
        raise typer.Exit(1)


@app.command()
def welcome(
    format_output: str = typer.Option("human", "--format", "-f", help="📄 输出格式")
):
    """🎉 显示增强的欢迎信息和系统概览"""
    
    try:
        output_format = format_output.lower()
    except ValueError:
        print_error("无效格式", f"格式 '{format_output}' 不支持")
        return
    
    if output_format == "human":
        # 创建统一Panel包含所有欢迎信息
        sections = [
            {
                "type": "banner",
                "data": "TPP 开发环境 - Tool-Powered Programming"
            },
            {
                "type": "stats",
                "title": "系统信息",
                "data": {
                    "版本": "2.0.0",
                    "环境": "开发版",
                    "Python版本": "3.8+",
                    "状态": "运行中"
                }
            },
            {
                "type": "table",
                "title": "快速开始",
                "columns": [
                    {"name": "🔧 命令", "key": "name", "style": "bold cyan"},
                    {"name": "📝 描述", "key": "description", "style": "green"},
                    {"name": "💡 用法", "key": "usage", "style": "yellow"}
                ],
                "data": [
                    {"name": "tool --list", "description": "查看所有可用工具", "usage": "tpp tool --list"},
                    {"name": "agent list", "description": "查看可用智能体", "usage": "tpp agent list"},
                    {"name": "resource stats", "description": "查看资源管理统计", "usage": "tpp resource stats"},
                    {"name": "resource list", "description": "列出所有资源", "usage": "tpp resource list"},
                    {"name": "recall --list", "description": "查看存储的记忆", "usage": "tpp recall --list"},
                    {"name": "help", "description": "获取详细帮助", "usage": "tpp help"}
                ]
            },
            {
                "type": "info",
                "data": "🎉 欢迎使用TPP! 现代化的开发环境已准备就绪"
            }
        ]
        
        panel = unified_output.create_unified_panel("🎉 欢迎使用 TPP", sections, "bright_blue", "🎉")
        console.print(panel)
    
    try:
        result = asyncio.run(command_manager.execute_command(
            "welcome", [], CLI_SESSION_ID, silent_mode=(output_format != "human")
        ))
        
        if output_format != "human":
            format_and_display_output(result, output_format)
        
    except Exception as e:
        print_error("显示欢迎信息时出错", str(e))


@app.command()
def help_cmd(
    command: Optional[str] = typer.Argument(None, help="📖 获取帮助的命令"),
    format_output: str = typer.Option("human", "--format", "-f", help="📄 输出格式")
):
    """📖 获取命令的详细帮助"""
    
    try:
        output_format = format_output.lower()
    except ValueError:
        print_error("无效格式", f"格式 '{format_output}' 不支持")
        return
    
    if not command:
        with status("正在加载命令列表", "dots"):
            # 显示所有命令的概览
            commands = command_manager.list_commands()
        
        if output_format == "human":
            columns = [
                {"name": "🔧 命令", "key": "name", "style": "bold cyan"},
                {"name": "📝 用途", "key": "purpose", "style": "green"},
                {"name": "🏷️ 类别", "key": "category", "style": "blue"}
            ]
            
            table = create_table("📖 TPP 命令帮助", columns, commands)
            console.print(table)
            
            print_info("获取详细帮助", "使用 'tpp help <命令>' 获取特定命令的详细帮助")
        else:
            from .core.UnifiedOutput import UnifiedOutput
            output = UnifiedOutput(
                status=OutputStatus.SUCCESS,
                message="Available commands",
                data={"commands": commands}
            )
            format_and_display_output(output, output_format)
        return
    
    with status(f"正在获取命令 '{command}' 的帮助", "dots"):
        # 获取特定命令的帮助
        help_output = command_manager.get_command_help(command, CLI_SESSION_ID)
    
    if help_output:
        format_and_display_output(help_output, output_format)
    else:
        print_error("命令未找到", f"命令 '{command}' 不存在")


# 集成tpp_core_cli（如果可用）
try:
    from .core.cli_integration import tpp_core_cli
    app.add_typer(tpp_core_cli, name="core")
except ImportError:
    console.print("[yellow]Warning: Core CLI integration not available[/yellow]")


# 添加help命令的别名
app.command("help")(help_cmd)


def main():
    """Main entry point for the CLI."""
    app()


if __name__ == "__main__":
    main()