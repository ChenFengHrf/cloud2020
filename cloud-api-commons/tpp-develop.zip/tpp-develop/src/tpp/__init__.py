"""
TPP Develop - A Model Context Protocol (MCP) server for TPP development.

This package provides MCP tools and resources for TPP development workflows.
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

from .cli import main as cli_main

__all__ = ["cli_main"]