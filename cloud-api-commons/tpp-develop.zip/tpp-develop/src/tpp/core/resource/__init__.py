"""TPP资源管理模块
基于PromptX ResourceManager架构实现
"""

from .resource_manager import ResourceManager
from .protocol_parser import ProtocolParser
from .registry_data import RegistryData, ResourceEntry

__all__ = ['ResourceManager', 'ProtocolParser', 'RegistryData', 'ResourceEntry']