"""
注册表数据管理 - 管理资源的注册、查找和合并
"""

import json
import os
from typing import Dict, List, Any, Optional, Union
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class ResourceEntry:
    """资源条目"""
    
    def __init__(self, resource_id: str, protocol: str, reference: str, 
                 metadata: Optional[Dict] = None):
        self.id = resource_id
        self.protocol = protocol
        self.reference = reference
        self.metadata = metadata or {}
        self.created_at = datetime.now().isoformat()
        self.updated_at = self.created_at
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'id': self.id,
            'protocol': self.protocol,
            'reference': self.reference,
            'metadata': self.metadata,
            'created_at': self.created_at,
            'updated_at': self.updated_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ResourceEntry':
        """从字典创建"""
        entry = cls(
            resource_id=data['id'],
            protocol=data['protocol'],
            reference=data['reference'],
            metadata=data.get('metadata', {})
        )
        entry.created_at = data.get('created_at', entry.created_at)
        entry.updated_at = data.get('updated_at', entry.updated_at)
        return entry
    
    def update(self, reference: Optional[str] = None, metadata: Optional[Dict] = None):
        """更新资源条目"""
        if reference:
            self.reference = reference
        if metadata:
            self.metadata.update(metadata)
        self.updated_at = datetime.now().isoformat()


class RegistryData:
    """注册表数据管理器"""
    
    def __init__(self, source: str = 'unknown', registry_path: Optional[str] = None):
        self.source = source
        self.registry_path = registry_path
        self.resources: Dict[str, ResourceEntry] = {}
        self.metadata = {
            'version': '1.0.0',
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat(),
            'source': source
        }
    
    @classmethod
    def create_empty(cls, source: str = 'merged', registry_path: Optional[str] = None) -> 'RegistryData':
        """创建空的注册表"""
        return cls(source=source, registry_path=registry_path)
    
    @classmethod
    def load_from_file(cls, file_path: str) -> 'RegistryData':
        """从文件加载注册表"""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"注册表文件不存在: {file_path}")
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            registry = cls(
                source=data.get('metadata', {}).get('source', 'file'),
                registry_path=file_path
            )
            registry.metadata = data.get('metadata', registry.metadata)
            
            # 加载资源
            for resource_data in data.get('resources', []):
                entry = ResourceEntry.from_dict(resource_data)
                registry.resources[entry.id] = entry
            
            return registry
            
        except (json.JSONDecodeError, KeyError) as e:
            raise ValueError(f"无效的注册表文件格式: {e}")
    
    def save_to_file(self, file_path: Optional[str] = None) -> None:
        """保存到文件"""
        target_path = file_path or self.registry_path
        if not target_path:
            raise ValueError("未指定保存路径")
        
        # 确保目录存在
        os.makedirs(os.path.dirname(target_path), exist_ok=True)
        
        data = {
            'metadata': self.metadata,
            'resources': [entry.to_dict() for entry in self.resources.values()]
        }
        
        try:
            with open(target_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            self.metadata['updated_at'] = datetime.now().isoformat()
            
        except Exception as e:
            raise IOError(f"保存注册表失败: {e}")
    
    def register_resource(self, resource_id: str, protocol: str, reference: str,
                         metadata: Optional[Dict] = None, allow_override: bool = False) -> bool:
        """
        注册资源
        
        Args:
            resource_id: 资源ID
            protocol: 协议类型
            reference: 资源引用
            metadata: 元数据
            allow_override: 是否允许覆盖
            
        Returns:
            是否成功注册
        """
        if resource_id in self.resources and not allow_override:
            logger.warning(f"资源已存在，跳过注册: {resource_id}")
            return False
        
        entry = ResourceEntry(resource_id, protocol, reference, metadata)
        self.resources[resource_id] = entry
        self.metadata['updated_at'] = datetime.now().isoformat()
        
        return True
    
    def find_resource_by_id(self, resource_id: str, protocol: Optional[str] = None) -> Optional[ResourceEntry]:
        """
        根据ID查找资源
        
        Args:
            resource_id: 资源ID
            protocol: 可选的协议过滤
            
        Returns:
            资源条目或None
        """
        entry = self.resources.get(resource_id)
        if entry and protocol and entry.protocol != protocol:
            return None
        return entry
    
    def find_resources_by_protocol(self, protocol: str) -> List[ResourceEntry]:
        """根据协议查找资源"""
        return [entry for entry in self.resources.values() if entry.protocol == protocol]
    
    def merge(self, other: 'RegistryData', allow_override: bool = False) -> None:
        """
        合并另一个注册表
        
        Args:
            other: 另一个注册表
            allow_override: 是否允许覆盖现有资源
        """
        for resource_id, entry in other.resources.items():
            if resource_id not in self.resources or allow_override:
                self.resources[resource_id] = entry
            else:
                logger.debug(f"跳过已存在的资源: {resource_id}")
        
        self.metadata['updated_at'] = datetime.now().isoformat()
    
    def clear(self) -> None:
        """清空注册表"""
        self.resources.clear()
        self.metadata['updated_at'] = datetime.now().isoformat()
    
    def size(self) -> int:
        """获取资源数量"""
        return len(self.resources)
    
    def list_resources(self) -> List[Dict[str, Any]]:
        """列出所有资源"""
        return [entry.to_dict() for entry in self.resources.values()]
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        protocols = {}
        for entry in self.resources.values():
            protocols[entry.protocol] = protocols.get(entry.protocol, 0) + 1
        
        return {
            'total_resources': len(self.resources),
            'protocols': protocols,
            'source': self.source,
            'metadata': self.metadata
        }
    
    def remove_resource(self, resource_id: str) -> bool:
        """
        移除资源
        
        Args:
            resource_id: 资源ID
            
        Returns:
            是否成功移除
        """
        if resource_id in self.resources:
            del self.resources[resource_id]
            self.metadata['updated_at'] = datetime.now().isoformat()
            return True
        return False
    
    def update_resource(self, resource_id: str, reference: Optional[str] = None,
                       metadata: Optional[Dict] = None) -> bool:
        """
        更新资源
        
        Args:
            resource_id: 资源ID
            reference: 新的引用
            metadata: 新的元数据
            
        Returns:
            是否成功更新
        """
        if resource_id in self.resources:
            self.resources[resource_id].update(reference, metadata)
            self.metadata['updated_at'] = datetime.now().isoformat()
            return True
        return False
    
    def get_resources_by_type(self) -> Dict[str, int]:
        """按类型统计资源数量"""
        type_counts = {}
        for resource in self.resources.values():
            resource_type = resource.protocol
            type_counts[resource_type] = type_counts.get(resource_type, 0) + 1
        return type_counts