"""
协议解析器 - 解析DPML格式的资源引用

支持格式:
- @protocol://path
- @!protocol://path (强制加载)
- @?protocol://path (可选加载)
- protocol://path
"""

import re
from typing import Dict, Any, Optional
from urllib.parse import urlparse, parse_qs


class ProtocolParser:
    """协议解析器，解析DPML格式的资源引用"""
    
    # 支持的协议类型
    SUPPORTED_PROTOCOLS = [
        'package', 'project', 'file', 'user',
        'role', 'thought', 'execution', 'knowledge',
        'manual', 'tool', 'resource', 'prompt'
    ]
    
    # 语义前缀
    SEMANTIC_PREFIXES = {
        '@': 'load',      # 直接加载
        '@!': 'force',    # 强制加载
        '@?': 'optional'  # 可选加载
    }
    
    def __init__(self):
        # 编译正则表达式以提高性能
        self.dpml_pattern = re.compile(r'^(@[!?]?)([a-zA-Z][a-zA-Z0-9_-]*):\/\/(.+)$')
        self.url_pattern = re.compile(r'^([a-zA-Z][a-zA-Z0-9_-]*):\/\/(.+)$')
    
    def parse(self, reference: str) -> Dict[str, Any]:
        """
        解析资源引用
        
        Args:
            reference: 资源引用字符串
            
        Returns:
            解析结果字典
            
        Raises:
            ValueError: 无效的引用格式
        """
        if not reference or not isinstance(reference, str):
            raise ValueError("资源引用不能为空")
        
        reference = reference.strip()
        
        # 尝试解析DPML格式 (@protocol://path)
        dpml_match = self.dpml_pattern.match(reference)
        if dpml_match:
            prefix, protocol, path = dpml_match.groups()
            
            if protocol not in self.SUPPORTED_PROTOCOLS:
                raise ValueError(f"不支持的协议: {protocol}")
            
            # 解析查询参数
            if '?' in path:
                path_part, query_part = path.split('?', 1)
                query_params = parse_qs(query_part)
                # 将单元素列表转换为字符串
                query_params = {k: v[0] if len(v) == 1 else v for k, v in query_params.items()}
            else:
                path_part = path
                query_params = {}
            
            return {
                'prefix': prefix,
                'semantic': self.SEMANTIC_PREFIXES.get(prefix, 'load'),
                'protocol': protocol,
                'path': path_part,
                'query_params': query_params,
                'original': reference
            }
        
        # 尝试解析URL格式 (protocol://path)
        url_match = self.url_pattern.match(reference)
        if url_match:
            protocol, path = url_match.groups()
            
            if protocol not in self.SUPPORTED_PROTOCOLS:
                raise ValueError(f"不支持的协议: {protocol}")
            
            # 解析查询参数
            if '?' in path:
                path_part, query_part = path.split('?', 1)
                query_params = parse_qs(query_part)
                query_params = {k: v[0] if len(v) == 1 else v for k, v in query_params.items()}
            else:
                path_part = path
                query_params = {}
            
            return {
                'prefix': '',
                'semantic': 'load',
                'protocol': protocol,
                'path': path_part,
                'query_params': query_params,
                'original': reference
            }
        
        # 如果都不匹配，抛出异常
        raise ValueError(f"无效的资源引用格式: {reference}")
    
    def is_valid_reference(self, reference: str) -> bool:
        """
        检查引用格式是否有效
        
        Args:
            reference: 资源引用字符串
            
        Returns:
            是否有效
        """
        try:
            self.parse(reference)
            return True
        except ValueError:
            return False
    
    def get_supported_protocols(self) -> list:
        """获取支持的协议列表"""
        return self.SUPPORTED_PROTOCOLS.copy()
    
    def build_reference(self, protocol: str, path: str, 
                       prefix: str = '@', query_params: Optional[Dict] = None) -> str:
        """
        构建资源引用
        
        Args:
            protocol: 协议名称
            path: 资源路径
            prefix: 语义前缀
            query_params: 查询参数
            
        Returns:
            构建的引用字符串
        """
        if protocol not in self.SUPPORTED_PROTOCOLS:
            raise ValueError(f"不支持的协议: {protocol}")
        
        if prefix not in self.SEMANTIC_PREFIXES:
            raise ValueError(f"不支持的前缀: {prefix}")
        
        reference = f"{prefix}{protocol}://{path}"
        
        if query_params:
            query_string = '&'.join([f"{k}={v}" for k, v in query_params.items()])
            reference += f"?{query_string}"
        
        return reference