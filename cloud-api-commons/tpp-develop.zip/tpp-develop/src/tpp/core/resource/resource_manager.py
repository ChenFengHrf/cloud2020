"""
资源管理器 - TPP资源管理核心
基于PromptX ResourceManager架构实现
"""

import os
import asyncio
from typing import Dict, Any, Optional, List
from pathlib import Path

from .protocol_parser import ProtocolParser
from .registry_data import RegistryData, ResourceEntry
from .protocols import (
    BaseProtocol, FileProtocol, RoleProtocol, 
    ToolProtocol, ManualProtocol, ExecutionProtocol,
    KnowledgeProtocol, ThoughtProtocol, PackageProtocol,
    ProjectProtocol, UserProtocol, PromptProtocol,
    ResourceProtocol
)


class ResourceManager:
    """资源管理器主类"""
    
    def __init__(self, working_directory: str = None):
        """
        初始化资源管理器
        
        Args:
            working_directory: 工作目录，默认为当前目录
        """
        self.working_directory = working_directory or os.getcwd()
        self.registryData = RegistryData()
        self.protocols: Dict[str, BaseProtocol] = {}
        self.parser = ProtocolParser()
        self._initialized = False
        
        # 初始化协议处理器
        self._init_protocols()
    
    def _init_protocols(self):
        """初始化协议处理器"""
        # 初始化协议处理器
        self.protocols = {
            'file': FileProtocol(),
            'role': RoleProtocol(),
            'tool': ToolProtocol(),
            'manual': ManualProtocol(),
            'execution': ExecutionProtocol(),
            'knowledge': KnowledgeProtocol(),
            'thought': ThoughtProtocol(),
            'package': PackageProtocol(),
            'project': ProjectProtocol(),
            'user': UserProtocol(),
            'prompt': PromptProtocol(),
            'resource': ResourceProtocol()
        }
        
        # 为每个协议设置注册表管理器
        for protocol in self.protocols.values():
            protocol.set_registry_manager(self)
        
        # 为文件协议设置工作目录
        if 'file' in self.protocols:
            self.protocols['file'].set_working_directory(self.working_directory)
    
    async def initialize(self, registry_path: str = None) -> bool:
        """
        初始化资源管理器
        
        Args:
            registry_path: 注册表文件路径
            
        Returns:
            初始化是否成功
        """
        try:
            # 设置默认注册表路径
            if not registry_path:
                registry_path = os.path.join(self.working_directory, '.tpp', 'resource_registry.json')
            
            # 确保目录存在
            os.makedirs(os.path.dirname(registry_path), exist_ok=True)
            
            # 加载或创建注册表数据
            if os.path.exists(registry_path):
                self.registryData = RegistryData.load_from_file(registry_path)
            else:
                # 创建新的注册表并保存
                self.registryData = RegistryData.create_empty('auto_created', registry_path)
                self.registryData.save_to_file(registry_path)
            
            # 发现和注册资源
            await self._discover_resources()
            
            # 保存更新后的注册表
            self.registryData.save_to_file(registry_path)
            
            self._initialized = True
            return True
            
        except Exception as e:
            print(f"资源管理器初始化失败: {e}")
            return False
    
    async def _discover_resources(self):
        """发现和注册项目中的资源"""
        # 发现角色资源
        await self._discover_roles()
        
        # 发现工具资源
        await self._discover_tools()
        
        # 发现手册资源
        await self._discover_manuals()
    
    async def _discover_roles(self):
        """发现角色资源"""
        roles_dir = os.path.join(self.working_directory, 'src', 'tpp', 'agents')
        if os.path.exists(roles_dir):
            for file_path in Path(roles_dir).rglob('*.py'):
                if file_path.name != '__init__.py':
                    role_id = file_path.stem
                    await self.register_resource(
                        resource_id=role_id,
                        resource_type='role',
                        reference=f'file://{file_path}',
                        metadata={'source': 'auto_discovery', 'language': 'python'}
                    )
    
    async def _discover_tools(self):
        """发现工具资源"""
        tools_dir = os.path.join(self.working_directory, 'src', 'tpp', 'tool')
        if os.path.exists(tools_dir):
            for file_path in Path(tools_dir).rglob('*.py'):
                if file_path.name != '__init__.py':
                    tool_id = file_path.stem
                    await self.register_resource(
                        resource_id=tool_id,
                        resource_type='tool',
                        reference=f'file://{file_path}',
                        metadata={'source': 'auto_discovery', 'language': 'python'}
                    )
    
    async def _discover_manuals(self):
        """发现手册资源"""
        docs_dir = os.path.join(self.working_directory, 'docs')
        if os.path.exists(docs_dir):
            for file_path in Path(docs_dir).rglob('*.md'):
                manual_id = file_path.stem
                await self.register_resource(
                    resource_id=manual_id,
                    resource_type='manual',
                    reference=f'file://{file_path}',
                    metadata={'source': 'auto_discovery', 'format': 'markdown'}
                )
    
    async def load_resource(self, resource_reference: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """
        加载资源内容
        
        Args:
            resource_reference: 资源引用（支持多种格式）
            query_params: 查询参数
            
        Returns:
            资源内容
            
        Raises:
            ValueError: 无效的资源引用
            FileNotFoundError: 资源不存在
        """
        if not self._initialized:
            await self.initialize()
        
        # 解析资源引用
        parsed = self.parser.parse(resource_reference)
        if not parsed:
            raise ValueError(f"无效的资源引用: {resource_reference}")
        
        protocol_name = parsed['protocol']
        path = parsed['path']
        
        # 获取协议处理器
        protocol = self.protocols.get(protocol_name)
        if not protocol:
            raise ValueError(f"不支持的协议: {protocol_name}")
        
        # 加载资源
        return await protocol.resolve(path, query_params)
    
    async def register_resource(self, resource_id: str, resource_type: str, 
                              reference: str, metadata: Optional[Dict[str, Any]] = None) -> bool:
        """
        注册资源
        
        Args:
            resource_id: 资源ID
            resource_type: 资源类型
            reference: 资源引用
            metadata: 元数据
            
        Returns:
            注册是否成功
        """
        try:
            # 使用正确的参数名称
            success = self.registryData.register_resource(
                resource_id=resource_id,
                protocol=resource_type,
                reference=reference,
                metadata=metadata or {}
            )
            
            # 保存到文件
            if success and self.registryData.registry_path:
                self.registryData.save_to_file()
            
            return success
            
        except Exception as e:
            print(f"注册资源失败: {e}")
            return False
    
    def get_available_protocols(self) -> List[str]:
        """获取可用的协议列表"""
        return list(self.protocols.keys())
    
    def supports_protocol(self, protocol: str) -> bool:
        """检查是否支持指定协议"""
        return protocol in self.protocols
    
    def get_stats(self) -> Dict[str, Any]:
        """获取资源管理器统计信息"""
        return {
            'initialized': self._initialized,
            'working_directory': self.working_directory,
            'protocols': list(self.protocols.keys()),
            'total_resources': len(self.registryData.resources),
            'resources_by_type': self.registryData.get_resources_by_type()
        }
    
    async def refresh_resources(self) -> bool:
        """刷新资源发现"""
        try:
            await self._discover_resources()
            return True
        except Exception as e:
            print(f"刷新资源失败: {e}")
            return False
    
    def get_resource_metadata(self, resource_id: str, resource_type: str = None) -> Optional[Dict[str, Any]]:
        """获取资源元数据"""
        entry = self.registryData.find_resource_by_id(resource_id, resource_type)
        if entry:
            return {
                'id': entry.id,
                'type': entry.protocol,
                'reference': entry.reference,
                'created_at': entry.created_at,
                'updated_at': entry.updated_at,
                'metadata': entry.metadata
            }
        return None
    
    def list_resources(self, resource_type: str = None) -> List[Dict[str, Any]]:
        """列出资源"""
        resources = []
        for entry in self.registryData.resources.values():
            if resource_type is None or entry.protocol == resource_type:
                resources.append({
                    'id': entry.id,
                    'type': entry.protocol,
                    'reference': entry.reference,
                    'metadata': entry.metadata
                })
        return resources
    
    @property
    def initialized(self) -> bool:
        """检查是否已初始化"""
        return self._initialized