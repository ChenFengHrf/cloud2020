"""
思维协议处理器 - 实现@thought://协议
用于访问专业思维模式和认知框架资源
"""

import os
import json
from typing import Dict, Any, Optional, List
from .base_protocol import BaseProtocol


class ThoughtProtocol(BaseProtocol):
    """思维协议处理器"""
    
    def __init__(self):
        super().__init__()
        self.protocol_name = "thought"
        
        # 内置思维模式注册表
        self.registry = {
            # 创新思维
            "creativity": "resource/thought/creativity.md",
            "brainstorming": "resource/thought/brainstorming.md",
            "lateral-thinking": "resource/thought/lateral-thinking.md",
            "design-thinking": "resource/thought/design-thinking.md",
            
            # 分析思维
            "critical-thinking": "resource/thought/critical-thinking.md",
            "logical-reasoning": "resource/thought/logical-reasoning.md",
            "problem-solving": "resource/thought/problem-solving.md",
            "root-cause-analysis": "resource/thought/root-cause-analysis.md",
            
            # 系统思维
            "systems-thinking": "resource/thought/systems-thinking.md",
            "holistic-view": "resource/thought/holistic-view.md",
            "complexity-thinking": "resource/thought/complexity-thinking.md",
            
            # 决策思维
            "decision-making": "resource/thought/decision-making.md",
            "risk-assessment": "resource/thought/risk-assessment.md",
            "strategic-thinking": "resource/thought/strategic-thinking.md",
            
            # 学习思维
            "growth-mindset": "resource/thought/growth-mindset.md",
            "metacognition": "resource/thought/metacognition.md",
            "reflective-thinking": "resource/thought/reflective-thinking.md",
            
            # 协作思维
            "collaborative-thinking": "resource/thought/collaborative-thinking.md",
            "empathy": "resource/thought/empathy.md",
            "communication": "resource/thought/communication.md"
        }
    
    def get_protocol_name(self) -> str:
        """获取协议名称"""
        return self.protocol_name
    
    def get_protocol_info(self) -> Dict[str, Any]:
        """获取协议信息"""
        return {
            "name": self.protocol_name,
            "description": "思维协议 - 访问专业思维模式和认知框架资源",
            "location": "thought://{thinking_mode}",
            "examples": [
                "thought://creativity",
                "thought://critical-thinking",
                "thought://systems-thinking",
                "thought://decision-making",
                "thought://design-thinking"
            ],
            "available_modes": list(self.registry.keys()),
            "categories": {
                "创新思维": ["creativity", "brainstorming", "lateral-thinking", "design-thinking"],
                "分析思维": ["critical-thinking", "logical-reasoning", "problem-solving", "root-cause-analysis"],
                "系统思维": ["systems-thinking", "holistic-view", "complexity-thinking"],
                "决策思维": ["decision-making", "risk-assessment", "strategic-thinking"],
                "学习思维": ["growth-mindset", "metacognition", "reflective-thinking"],
                "协作思维": ["collaborative-thinking", "empathy", "communication"]
            },
            "params": self.get_supported_params()
        }
    
    def get_supported_params(self) -> Dict[str, str]:
        """支持的查询参数"""
        return {
            "format": "string - 输出格式 (text|json|markdown)",
            "aspect": "string - 指定思维方面",
            "context": "string - 应用场景",
            "cache": "boolean - 是否缓存"
        }
    
    def validate_path(self, path: str) -> bool:
        """验证资源路径"""
        if not super().validate_path(path):
            return False
        
        # 检查是否在注册表中
        return path in self.registry
    
    async def resolve(self, path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """
        解析思维资源路径并返回内容
        
        Args:
            path: 资源路径，如 "creativity"
            query_params: 查询参数
            
        Returns:
            资源内容
            
        Raises:
            FileNotFoundError: 资源不存在
            ValueError: 参数错误
        """
        if not self.validate_path(path):
            available = ", ".join(self.registry.keys())
            raise ValueError(f"未找到 thought 资源: {path}。可用资源: {available}")
        
        # 获取资源路径
        resource_path = self.registry[path]
        
        try:
            # 尝试从包资源加载
            content = await self._load_from_package(resource_path)
            
            # 应用查询参数
            if query_params:
                content = self._apply_query_params(content, query_params)
            
            return content
            
        except Exception as e:
            # 如果包资源不存在，返回默认内容
            return self._get_default_content(path)
    
    async def _load_from_package(self, resource_path: str) -> str:
        """从包资源加载内容"""
        # 这里应该集成包协议来加载资源
        # 暂时返回模拟内容
        raise FileNotFoundError(f"Package resource not found: {resource_path}")
    
    def _get_default_content(self, thinking_mode: str) -> str:
        """获取默认内容"""
        default_contents = {
            "creativity": """# 创新思维

## 核心原则
- 打破常规思维
- 鼓励多元化想法
- 延迟判断
- 建立在他人想法基础上

## 创新技巧
- 头脑风暴
- 思维导图
- 六顶思考帽
- SCAMPER技法

## 创新环境
- 心理安全
- 多样性团队
- 开放沟通
- 实验文化

## 创新流程
1. 问题定义
2. 想法生成
3. 想法评估
4. 原型制作
5. 测试验证
""",
            "critical-thinking": """# 批判性思维

## 核心要素
- 分析能力
- 评估能力
- 推理能力
- 解释能力

## 思维技能
- 识别假设
- 评估证据
- 检验逻辑
- 考虑替代方案

## 认知偏见
- 确认偏见
- 锚定效应
- 可得性启发
- 代表性启发

## 批判性问题
- 这个信息可靠吗？
- 有什么证据支持？
- 还有其他解释吗？
- 这个结论合理吗？
""",
            "systems-thinking": """# 系统思维

## 系统原理
- 整体性
- 关联性
- 层次性
- 动态性

## 系统要素
- 系统边界
- 系统结构
- 系统功能
- 系统环境

## 系统行为
- 反馈循环
- 延迟效应
- 非线性关系
- 涌现特性

## 系统工具
- 因果循环图
- 系统地图
- 杠杆点分析
- 情景规划
""",
            "decision-making": """# 决策思维

## 决策过程
1. 问题识别
2. 信息收集
3. 方案生成
4. 方案评估
5. 决策执行
6. 结果评价

## 决策工具
- 决策树
- 成本效益分析
- SWOT分析
- 风险评估矩阵

## 决策偏见
- 过度自信
- 沉没成本谬误
- 框架效应
- 群体思维

## 决策质量
- 决策速度
- 决策准确性
- 决策接受度
- 决策执行力
""",
            "design-thinking": """# 设计思维

## 设计思维流程
1. 共情 (Empathize)
2. 定义 (Define)
3. 构思 (Ideate)
4. 原型 (Prototype)
5. 测试 (Test)

## 核心原则
- 以人为中心
- 协作共创
- 实验学习
- 视觉化思考

## 设计工具
- 用户画像
- 用户旅程图
- 故事板
- 原型制作

## 设计心态
- 好奇心
- 乐观主义
- 实验精神
- 协作态度
"""
        }
        
        return default_contents.get(thinking_mode, f"# {thinking_mode}\n\n思维模式: {thinking_mode}")
    
    def _apply_query_params(self, content: str, query_params: Dict[str, Any]) -> str:
        """应用查询参数"""
        result = content
        
        # 格式化处理
        format_type = query_params.get("format", "text")
        if format_type == "json":
            result = json.dumps({"content": result}, ensure_ascii=False, indent=2)
        elif format_type == "markdown":
            # 确保是markdown格式
            if not result.startswith("#"):
                result = f"# 思维模式\n\n{result}"
        
        # 方面过滤
        aspect = query_params.get("aspect")
        if aspect:
            result = self._extract_aspect(result, aspect)
        
        # 场景过滤
        context = query_params.get("context")
        if context:
            result = self._apply_context(result, context)
        
        return result
    
    def _extract_aspect(self, content: str, aspect: str) -> str:
        """提取指定方面"""
        lines = content.split('\n')
        aspect_lines = []
        in_aspect = False
        
        for line in lines:
            if line.startswith('#') and aspect.lower() in line.lower():
                in_aspect = True
                aspect_lines.append(line)
            elif line.startswith('#') and in_aspect:
                break
            elif in_aspect:
                aspect_lines.append(line)
        
        return '\n'.join(aspect_lines) if aspect_lines else content
    
    def _apply_context(self, content: str, context: str) -> str:
        """应用特定场景"""
        # 根据场景调整内容
        context_prefix = f"\n## 在{context}场景中的应用\n\n"
        
        if context == "团队协作":
            context_content = "- 促进团队成员间的思维碰撞\n- 建立共同的思维框架\n- 提升集体决策质量\n"
        elif context == "产品开发":
            context_content = "- 深入理解用户需求\n- 创新产品解决方案\n- 优化产品设计流程\n"
        elif context == "问题解决":
            context_content = "- 系统分析问题根因\n- 生成多样化解决方案\n- 评估方案可行性\n"
        else:
            context_content = f"- 在{context}中的具体应用\n- 相关注意事项\n- 实践建议\n"
        
        return content + context_prefix + context_content