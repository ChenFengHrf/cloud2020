"""
文件协议处理器 - 处理 file:// 协议
"""

import os
import asyncio
from pathlib import Path
from typing import Dict, Any, Optional
from .base_protocol import BaseProtocol


class FileProtocol(BaseProtocol):
    """文件协议处理器"""
    
    def get_protocol_name(self) -> str:
        return 'file'
    
    async def resolve(self, path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """
        解析文件路径并返回内容
        
        Args:
            path: 文件路径
            query_params: 查询参数（可包含encoding等）
            
        Returns:
            文件内容
            
        Raises:
            FileNotFoundError: 文件不存在
            ValueError: 参数错误
        """
        if not self.validate_path(path):
            raise ValueError(f"无效的文件路径: {path}")
        
        # 标准化路径
        normalized_path = self.normalize_path(path)
        
        # 处理相对路径
        if not os.path.isabs(normalized_path):
            # 如果有工作目录上下文，使用工作目录
            if hasattr(self, 'working_directory') and self.working_directory:
                normalized_path = os.path.join(self.working_directory, normalized_path)
            else:
                normalized_path = os.path.abspath(normalized_path)
        
        # 检查文件是否存在
        if not os.path.exists(normalized_path):
            raise FileNotFoundError(f"文件不存在: {normalized_path}")
        
        if not os.path.isfile(normalized_path):
            raise ValueError(f"路径不是文件: {normalized_path}")
        
        # 获取编码设置
        encoding = 'utf-8'
        if query_params and 'encoding' in query_params:
            encoding = query_params['encoding']
        
        try:
            # 使用标准库读取文件内容
            with open(normalized_path, 'r', encoding=encoding) as f:
                content = f.read()
            return content
            
        except UnicodeDecodeError as e:
            raise ValueError(f"文件编码错误: {e}")
        except Exception as e:
            raise IOError(f"读取文件失败: {e}")
    
    def validate_path(self, path: str) -> bool:
        """验证文件路径格式"""
        if not super().validate_path(path):
            return False
        
        # 检查是否包含危险字符
        dangerous_patterns = ['..', '~', '$']
        for pattern in dangerous_patterns:
            if pattern in path:
                return False
        
        return True
    
    def set_working_directory(self, working_dir: str):
        """设置工作目录"""
        self.working_directory = working_dir
    
    def get_metadata(self, path: str) -> Dict[str, Any]:
        """获取文件元数据"""
        metadata = super().get_metadata(path)
        
        normalized_path = self.normalize_path(path)
        if not os.path.isabs(normalized_path):
            if hasattr(self, 'working_directory') and self.working_directory:
                normalized_path = os.path.join(self.working_directory, normalized_path)
            else:
                normalized_path = os.path.abspath(normalized_path)
        
        if os.path.exists(normalized_path):
            stat = os.stat(normalized_path)
            metadata.update({
                'size': stat.st_size,
                'modified': stat.st_mtime,
                'exists': True,
                'absolute_path': normalized_path
            })
        else:
            metadata.update({
                'exists': False,
                'absolute_path': normalized_path
            })
        
        return metadata