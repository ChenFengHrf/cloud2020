"""
执行协议处理器 - 实现@execution://协议
用于访问执行技能和最佳实践资源
"""

import os
import json
from typing import Dict, Any, Optional, List
from .base_protocol import BaseProtocol


class ExecutionProtocol(BaseProtocol):
    """执行协议处理器"""
    
    def __init__(self):
        super().__init__()
        self.protocol_name = "execution"
        
        # 内置执行技能注册表
        self.registry = {
            "best-practice": "resource/execution/best-practice.md",
            "workflow": "resource/execution/workflow.md",
            "debugging": "resource/execution/debugging.md",
            "testing": "resource/execution/testing.md",
            "optimization": "resource/execution/optimization.md",
            "deployment": "resource/execution/deployment.md",
            "monitoring": "resource/execution/monitoring.md",
            "troubleshooting": "resource/execution/troubleshooting.md"
        }
    
    def get_protocol_name(self) -> str:
        """获取协议名称"""
        return self.protocol_name
    
    def get_protocol_info(self) -> Dict[str, Any]:
        """获取协议信息"""
        return {
            "name": self.protocol_name,
            "description": "执行协议 - 访问执行技能和最佳实践资源",
            "location": "execution://{resource_id}",
            "examples": [
                "execution://best-practice",
                "execution://workflow",
                "execution://debugging",
                "execution://testing"
            ],
            "available_resources": list(self.registry.keys()),
            "params": self.get_supported_params()
        }
    
    def get_supported_params(self) -> Dict[str, str]:
        """支持的查询参数"""
        return {
            "format": "string - 输出格式 (text|json|markdown)",
            "section": "string - 指定章节",
            "cache": "boolean - 是否缓存"
        }
    
    def validate_path(self, path: str) -> bool:
        """验证资源路径"""
        if not super().validate_path(path):
            return False
        
        # 检查是否在注册表中
        return path in self.registry
    
    async def resolve(self, path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """
        解析执行资源路径并返回内容
        
        Args:
            path: 资源路径，如 "best-practice"
            query_params: 查询参数
            
        Returns:
            资源内容
            
        Raises:
            FileNotFoundError: 资源不存在
            ValueError: 参数错误
        """
        if not self.validate_path(path):
            available = ", ".join(self.registry.keys())
            raise ValueError(f"未找到 execution 资源: {path}。可用资源: {available}")
        
        # 获取资源路径
        resource_path = self.registry[path]
        
        try:
            # 尝试从包资源加载
            content = await self._load_from_package(resource_path)
            
            # 应用查询参数
            if query_params:
                content = self._apply_query_params(content, query_params)
            
            return content
            
        except Exception as e:
            # 如果包资源不存在，返回默认内容
            return self._get_default_content(path)
    
    async def _load_from_package(self, resource_path: str) -> str:
        """从包资源加载内容"""
        # 这里应该集成包协议来加载资源
        # 暂时返回模拟内容
        raise FileNotFoundError(f"Package resource not found: {resource_path}")
    
    def _get_default_content(self, resource_id: str) -> str:
        """获取默认内容"""
        default_contents = {
            "best-practice": """# 执行最佳实践

## 代码质量
- 遵循编码规范
- 编写清晰的注释
- 使用有意义的变量名

## 测试策略
- 单元测试覆盖核心逻辑
- 集成测试验证系统交互
- 端到端测试确保用户体验

## 性能优化
- 识别性能瓶颈
- 优化算法复杂度
- 合理使用缓存

## 错误处理
- 优雅的错误处理
- 详细的错误日志
- 用户友好的错误信息
""",
            "workflow": """# 开发工作流程

## 需求分析
1. 理解业务需求
2. 技术可行性评估
3. 设计方案制定

## 开发阶段
1. 环境搭建
2. 核心功能开发
3. 单元测试编写

## 测试阶段
1. 功能测试
2. 性能测试
3. 安全测试

## 部署阶段
1. 环境准备
2. 代码部署
3. 监控配置
""",
            "debugging": """# 调试技巧

## 问题定位
- 复现问题
- 分析日志
- 使用调试工具

## 调试策略
- 二分法定位
- 添加调试信息
- 单步调试

## 常见问题
- 空指针异常
- 内存泄漏
- 并发问题
""",
            "testing": """# 测试策略

## 测试类型
- 单元测试
- 集成测试
- 端到端测试

## 测试原则
- 测试驱动开发
- 测试覆盖率
- 测试自动化

## 测试工具
- 单元测试框架
- 模拟工具
- 性能测试工具
"""
        }
        
        return default_contents.get(resource_id, f"# {resource_id}\n\n执行技能资源: {resource_id}")
    
    def _apply_query_params(self, content: str, query_params: Dict[str, Any]) -> str:
        """应用查询参数"""
        result = content
        
        # 格式化处理
        format_type = query_params.get("format", "text")
        if format_type == "json":
            result = json.dumps({"content": result}, ensure_ascii=False, indent=2)
        elif format_type == "markdown":
            # 确保是markdown格式
            if not result.startswith("#"):
                result = f"# 执行技能\n\n{result}"
        
        # 章节过滤
        section = query_params.get("section")
        if section:
            result = self._extract_section(result, section)
        
        return result
    
    def _extract_section(self, content: str, section: str) -> str:
        """提取指定章节"""
        lines = content.split('\n')
        section_lines = []
        in_section = False
        
        for line in lines:
            if line.startswith('#') and section.lower() in line.lower():
                in_section = True
                section_lines.append(line)
            elif line.startswith('#') and in_section:
                break
            elif in_section:
                section_lines.append(line)
        
        return '\n'.join(section_lines) if section_lines else content