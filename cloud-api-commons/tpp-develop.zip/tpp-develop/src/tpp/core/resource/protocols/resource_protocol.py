"""
资源协议处理器 - 实现@resource://协议
所有DPML资源协议的抽象基类
"""

import os
import json
import re
from typing import Dict, Any, Optional, List, Union
from .base_protocol import BaseProtocol


class ResourceProtocol(BaseProtocol):
    """资源协议处理器 - 抽象基类"""
    
    def __init__(self):
        super().__init__()
        self.protocol_name = "resource"
        self.cache = {}
        self.cache_enabled = True
        
        # 通用查询参数处理器
        self.query_processors = {
            'lines': self._process_lines_filter,
            'format': self._process_format,
            'encoding': self._process_encoding,
            'cache': self._process_cache,
            'merge': self._process_merge,
            'separator': self._process_separator
        }
    
    def get_protocol_name(self) -> str:
        """获取协议名称"""
        return self.protocol_name
    
    def get_protocol_info(self) -> Dict[str, Any]:
        """获取协议信息"""
        return {
            "name": self.protocol_name,
            "description": "通用资源协议，所有DPML资源协议的基类",
            "location": "resource://{resource_id}",
            "examples": [
                "resource://example-resource",
                "resource://config/settings",
                "resource://data/sample"
            ],
            "params": self.get_supported_params(),
            "cache_enabled": self.cache_enabled
        }
    
    def get_supported_params(self) -> Dict[str, str]:
        """支持的查询参数"""
        return {
            "lines": "string - 行过滤 (1-10, 5-, -20, 1,3,5)",
            "format": "string - 输出格式 (text|json|yaml|xml)",
            "encoding": "string - 文件编码 (utf-8|gbk|latin1)",
            "cache": "boolean - 是否使用缓存",
            "merge": "boolean - 是否合并多个资源",
            "separator": "string - 合并时的分隔符",
            "include_metadata": "boolean - 是否包含元数据",
            "validate": "boolean - 是否验证资源格式"
        }
    
    def validate_path(self, path: str) -> bool:
        """验证资源协议路径"""
        if not super().validate_path(path):
            return False
        
        # 基本路径验证
        if not path or path.startswith('/') or '..' in path:
            return False
        
        return True
    
    async def resolve(self, path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """
        解析资源路径并返回内容
        
        Args:
            path: 资源路径
            query_params: 查询参数
            
        Returns:
            资源内容
            
        Raises:
            NotImplementedError: 子类必须实现此方法
        """
        raise NotImplementedError("子类必须实现resolve方法")
    
    def get_cache_key(self, path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """生成缓存键"""
        params_str = json.dumps(query_params or {}, sort_keys=True)
        return f"{self.protocol_name}:{path}:{hash(params_str)}"
    
    def get_from_cache(self, cache_key: str) -> Optional[str]:
        """从缓存获取内容"""
        if not self.cache_enabled:
            return None
        return self.cache.get(cache_key)
    
    def set_cache(self, cache_key: str, content: str) -> None:
        """设置缓存内容"""
        if self.cache_enabled:
            self.cache[cache_key] = content
    
    def clear_cache(self) -> None:
        """清空缓存"""
        self.cache.clear()
    
    def apply_common_query_params(self, content: str, query_params: Dict[str, Any]) -> str:
        """应用通用查询参数"""
        result = content
        
        # 按顺序应用查询参数处理器
        for param_name, processor in self.query_processors.items():
            if param_name in query_params:
                result = processor(result, query_params[param_name], query_params)
        
        return result
    
    def _process_lines_filter(self, content: str, lines_param: str, query_params: Dict[str, Any]) -> str:
        """处理行过滤参数"""
        if not lines_param:
            return content
        
        lines = content.split('\n')
        total_lines = len(lines)
        
        try:
            # 解析行号规则
            if ',' in lines_param:
                # 逗号分隔的行号列表: "1,3,5"
                line_numbers = [int(x.strip()) for x in lines_param.split(',')]
                selected_lines = []
                for line_num in line_numbers:
                    if 1 <= line_num <= total_lines:
                        selected_lines.append(lines[line_num - 1])
                return '\n'.join(selected_lines)
            
            elif '-' in lines_param:
                if lines_param.endswith('-'):
                    # 从指定行到末尾: "5-"
                    start = int(lines_param[:-1])
                    return '\n'.join(lines[start-1:])
                elif lines_param.startswith('-'):
                    # 从开头到指定行: "-20"
                    end = int(lines_param[1:])
                    return '\n'.join(lines[:end])
                else:
                    # 行号范围: "1-10"
                    start, end = map(int, lines_param.split('-'))
                    return '\n'.join(lines[start-1:end])
            
            else:
                # 单个行号: "5"
                line_num = int(lines_param)
                if 1 <= line_num <= total_lines:
                    return lines[line_num - 1]
                return ""
        
        except (ValueError, IndexError):
            # 如果解析失败，返回原内容
            return content
    
    def _process_format(self, content: str, format_type: str, query_params: Dict[str, Any]) -> str:
        """处理格式化参数"""
        if format_type == "json":
            try:
                # 尝试解析为JSON并格式化
                parsed = json.loads(content)
                return json.dumps(parsed, ensure_ascii=False, indent=2)
            except json.JSONDecodeError:
                # 如果不是JSON，包装为JSON
                return json.dumps({"content": content}, ensure_ascii=False, indent=2)
        
        elif format_type == "yaml":
            # 简单的YAML格式化
            lines = content.split('\n')
            yaml_content = []
            for line in lines:
                if line.strip():
                    yaml_content.append(f"  {line}")
            return f"content: |\n" + '\n'.join(yaml_content)
        
        elif format_type == "xml":
            # 简单的XML包装
            escaped_content = content.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
            return f"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<content><![CDATA[{escaped_content}]]></content>"
        
        return content
    
    def _process_encoding(self, content: str, encoding: str, query_params: Dict[str, Any]) -> str:
        """处理编码参数"""
        # 在实际文件读取时处理编码，这里只是标记
        return content
    
    def _process_cache(self, content: str, use_cache: bool, query_params: Dict[str, Any]) -> str:
        """处理缓存参数"""
        # 缓存控制在resolve方法中处理
        return content
    
    def _process_merge(self, content: str, should_merge: bool, query_params: Dict[str, Any]) -> str:
        """处理合并参数"""
        # 合并逻辑在具体协议中实现
        return content
    
    def _process_separator(self, content: str, separator: str, query_params: Dict[str, Any]) -> str:
        """处理分隔符参数"""
        # 分隔符在合并时使用
        return content
    
    def validate_resource_format(self, content: str, expected_format: str = None) -> bool:
        """验证资源格式"""
        if not expected_format:
            return True
        
        if expected_format == "json":
            try:
                json.loads(content)
                return True
            except json.JSONDecodeError:
                return False
        
        elif expected_format == "yaml":
            # 简单的YAML格式检查
            return ':' in content or '- ' in content
        
        elif expected_format == "xml":
            return content.strip().startswith('<') and content.strip().endswith('>')
        
        elif expected_format == "markdown":
            return '#' in content or '*' in content or '[' in content
        
        return True
    
    def extract_metadata(self, content: str) -> Dict[str, Any]:
        """提取资源元数据"""
        metadata = {
            'size': len(content),
            'lines': len(content.split('\n')),
            'encoding': 'utf-8',
            'format': self._detect_format(content)
        }
        
        # 提取YAML front matter
        if content.startswith('---\n'):
            try:
                end_index = content.find('\n---\n', 4)
                if end_index > 0:
                    front_matter = content[4:end_index]
                    # 简单解析YAML front matter
                    for line in front_matter.split('\n'):
                        if ':' in line:
                            key, value = line.split(':', 1)
                            metadata[key.strip()] = value.strip()
            except Exception:
                pass
        
        return metadata
    
    def _detect_format(self, content: str) -> str:
        """检测内容格式"""
        content_stripped = content.strip()
        
        if content_stripped.startswith('{') and content_stripped.endswith('}'):
            return 'json'
        elif content_stripped.startswith('<') and content_stripped.endswith('>'):
            return 'xml'
        elif '---' in content or ':' in content:
            return 'yaml'
        elif '#' in content or '*' in content:
            return 'markdown'
        else:
            return 'text'
    
    def get_resource_info(self, path: str) -> Dict[str, Any]:
        """获取资源信息"""
        return {
            'protocol': self.protocol_name,
            'path': path,
            'supported_params': self.get_supported_params(),
            'cache_enabled': self.cache_enabled
        }