"""
知识协议处理器 - 实现@knowledge://协议
用于访问领域专业知识资源
"""

import os
import json
from typing import Dict, Any, Optional, List
from .base_protocol import BaseProtocol


class KnowledgeProtocol(BaseProtocol):
    """知识协议处理器"""
    
    def __init__(self):
        super().__init__()
        self.protocol_name = "knowledge"
        
        # 内置知识资源注册表
        self.registry = {
            # 技术领域
            "programming": "resource/knowledge/programming.md",
            "algorithms": "resource/knowledge/algorithms.md",
            "data-structures": "resource/knowledge/data-structures.md",
            "design-patterns": "resource/knowledge/design-patterns.md",
            "architecture": "resource/knowledge/architecture.md",
            
            # 开发方法论
            "agile": "resource/knowledge/agile.md",
            "scrum": "resource/knowledge/scrum.md",
            "devops": "resource/knowledge/devops.md",
            "ci-cd": "resource/knowledge/ci-cd.md",
            
            # 技术栈
            "frontend": "resource/knowledge/frontend.md",
            "backend": "resource/knowledge/backend.md",
            "database": "resource/knowledge/database.md",
            "cloud": "resource/knowledge/cloud.md",
            "security": "resource/knowledge/security.md",
            
            # 业务领域
            "product-management": "resource/knowledge/product-management.md",
            "user-experience": "resource/knowledge/user-experience.md",
            "marketing": "resource/knowledge/marketing.md",
            "business-analysis": "resource/knowledge/business-analysis.md"
        }
    
    def get_protocol_name(self) -> str:
        """获取协议名称"""
        return self.protocol_name
    
    def get_protocol_info(self) -> Dict[str, Any]:
        """获取协议信息"""
        return {
            "name": self.protocol_name,
            "description": "知识协议 - 访问领域专业知识资源",
            "location": "knowledge://{domain}",
            "examples": [
                "knowledge://programming",
                "knowledge://algorithms",
                "knowledge://design-patterns",
                "knowledge://agile",
                "knowledge://security"
            ],
            "available_domains": list(self.registry.keys()),
            "categories": {
                "技术领域": ["programming", "algorithms", "data-structures", "design-patterns", "architecture"],
                "开发方法论": ["agile", "scrum", "devops", "ci-cd"],
                "技术栈": ["frontend", "backend", "database", "cloud", "security"],
                "业务领域": ["product-management", "user-experience", "marketing", "business-analysis"]
            },
            "params": self.get_supported_params()
        }
    
    def get_supported_params(self) -> Dict[str, str]:
        """支持的查询参数"""
        return {
            "format": "string - 输出格式 (text|json|markdown)",
            "topic": "string - 指定主题",
            "level": "string - 知识级别 (basic|intermediate|advanced)",
            "cache": "boolean - 是否缓存"
        }
    
    def validate_path(self, path: str) -> bool:
        """验证资源路径"""
        if not super().validate_path(path):
            return False
        
        # 检查是否在注册表中
        return path in self.registry
    
    async def resolve(self, path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """
        解析知识资源路径并返回内容
        
        Args:
            path: 资源路径，如 "programming"
            query_params: 查询参数
            
        Returns:
            资源内容
            
        Raises:
            FileNotFoundError: 资源不存在
            ValueError: 参数错误
        """
        if not self.validate_path(path):
            available = ", ".join(self.registry.keys())
            raise ValueError(f"未找到 knowledge 资源: {path}。可用资源: {available}")
        
        # 获取资源路径
        resource_path = self.registry[path]
        
        try:
            # 尝试从包资源加载
            content = await self._load_from_package(resource_path)
            
            # 应用查询参数
            if query_params:
                content = self._apply_query_params(content, query_params)
            
            return content
            
        except Exception as e:
            # 如果包资源不存在，返回默认内容
            return self._get_default_content(path)
    
    async def _load_from_package(self, resource_path: str) -> str:
        """从包资源加载内容"""
        # 这里应该集成包协议来加载资源
        # 暂时返回模拟内容
        raise FileNotFoundError(f"Package resource not found: {resource_path}")
    
    def _get_default_content(self, domain: str) -> str:
        """获取默认内容"""
        default_contents = {
            "programming": """# 编程知识

## 基础概念
- 变量和数据类型
- 控制结构（条件、循环）
- 函数和模块
- 面向对象编程

## 编程原则
- DRY (Don't Repeat Yourself)
- SOLID 原则
- 单一职责原则
- 开闭原则

## 最佳实践
- 代码可读性
- 错误处理
- 性能优化
- 安全编程

## 常用模式
- 设计模式
- 架构模式
- 编程范式
""",
            "algorithms": """# 算法知识

## 基础算法
- 排序算法
- 搜索算法
- 递归算法
- 动态规划

## 数据结构
- 数组和链表
- 栈和队列
- 树和图
- 哈希表

## 复杂度分析
- 时间复杂度
- 空间复杂度
- 大O表示法

## 算法设计
- 分治法
- 贪心算法
- 回溯法
- 动态规划
""",
            "design-patterns": """# 设计模式

## 创建型模式
- 单例模式
- 工厂模式
- 建造者模式
- 原型模式

## 结构型模式
- 适配器模式
- 装饰器模式
- 外观模式
- 代理模式

## 行为型模式
- 观察者模式
- 策略模式
- 命令模式
- 状态模式

## 应用场景
- 何时使用
- 优缺点分析
- 实现要点
""",
            "agile": """# 敏捷开发

## 敏捷宣言
- 个体和互动胜过流程和工具
- 工作的软件胜过详尽的文档
- 客户合作胜过合同谈判
- 响应变化胜过遵循计划

## 敏捷原则
- 客户满意度优先
- 拥抱变化
- 频繁交付
- 团队协作

## 敏捷实践
- 迭代开发
- 持续集成
- 测试驱动开发
- 重构

## 敏捷框架
- Scrum
- Kanban
- XP (极限编程)
- SAFe
""",
            "security": """# 安全知识

## 安全原则
- 最小权限原则
- 深度防御
- 失败安全
- 安全设计

## 常见威胁
- SQL注入
- XSS攻击
- CSRF攻击
- 身份验证绕过

## 安全措施
- 输入验证
- 输出编码
- 访问控制
- 加密保护

## 安全测试
- 渗透测试
- 代码审计
- 漏洞扫描
- 安全评估
"""
        }
        
        return default_contents.get(domain, f"# {domain}\n\n专业知识领域: {domain}")
    
    def _apply_query_params(self, content: str, query_params: Dict[str, Any]) -> str:
        """应用查询参数"""
        result = content
        
        # 格式化处理
        format_type = query_params.get("format", "text")
        if format_type == "json":
            result = json.dumps({"content": result}, ensure_ascii=False, indent=2)
        elif format_type == "markdown":
            # 确保是markdown格式
            if not result.startswith("#"):
                result = f"# 专业知识\n\n{result}"
        
        # 主题过滤
        topic = query_params.get("topic")
        if topic:
            result = self._extract_topic(result, topic)
        
        # 级别过滤
        level = query_params.get("level")
        if level:
            result = self._filter_by_level(result, level)
        
        return result
    
    def _extract_topic(self, content: str, topic: str) -> str:
        """提取指定主题"""
        lines = content.split('\n')
        topic_lines = []
        in_topic = False
        
        for line in lines:
            if line.startswith('#') and topic.lower() in line.lower():
                in_topic = True
                topic_lines.append(line)
            elif line.startswith('#') and in_topic:
                break
            elif in_topic:
                topic_lines.append(line)
        
        return '\n'.join(topic_lines) if topic_lines else content
    
    def _filter_by_level(self, content: str, level: str) -> str:
        """根据级别过滤内容"""
        # 简单的级别过滤实现
        if level == "basic":
            # 返回基础部分
            lines = content.split('\n')
            basic_lines = []
            for line in lines:
                if any(keyword in line.lower() for keyword in ['基础', '入门', '简介', '概念']):
                    basic_lines.extend([line])
                elif line.startswith('#'):
                    basic_lines.append(line)
            return '\n'.join(basic_lines) if basic_lines else content
        
        return content