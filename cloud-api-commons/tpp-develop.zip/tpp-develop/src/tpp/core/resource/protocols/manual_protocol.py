"""
手册协议处理器 - 处理 manual:// 协议
"""

from typing import Dict, Any, Optional
from .base_protocol import BaseProtocol


class ManualProtocol(BaseProtocol):
    """手册协议处理器"""
    
    def get_protocol_name(self) -> str:
        return 'manual'
    
    async def resolve(self, path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """
        解析手册资源并返回内容
        
        Args:
            path: 手册名称（通常对应工具名称）
            query_params: 查询参数
            
        Returns:
            手册内容
            
        Raises:
            FileNotFoundError: 手册不存在
            ValueError: 参数错误
        """
        if not self.validate_path(path):
            raise ValueError(f"无效的手册名称: {path}")
        
        # 从注册表查找手册资源
        if not self.registry_manager:
            raise RuntimeError("未设置注册表管理器")
        
        resource_entry = self.registry_manager.registryData.find_resource_by_id(path, 'manual')
        if not resource_entry:
            raise FileNotFoundError(f"手册不存在: {path}")
        
        # 通过文件协议加载实际内容
        file_protocol = self.registry_manager.protocols.get('file')
        if not file_protocol:
            raise RuntimeError("文件协议处理器未初始化")
        
        # 解析引用并加载内容
        if resource_entry.reference.startswith('file://'):
            file_path = resource_entry.reference[7:]  # 移除 'file://' 前缀
            return await file_protocol.resolve(file_path, query_params)
        else:
            raise ValueError(f"不支持的手册引用格式: {resource_entry.reference}")
    
    def validate_path(self, path: str) -> bool:
        """验证手册名称格式"""
        if not super().validate_path(path):
            return False
        
        # 手册名称应该是有效的标识符
        import re
        return bool(re.match(r'^[a-zA-Z][a-zA-Z0-9_-]*$', path))
    
    def get_metadata(self, path: str) -> Dict[str, Any]:
        """获取手册元数据"""
        metadata = super().get_metadata(path)
        metadata.update({
            'type': 'manual',
            'manual_name': path
        })
        
        # 如果有注册表管理器，获取更多信息
        if self.registry_manager:
            resource_entry = self.registry_manager.registryData.find_resource_by_id(path, 'manual')
            if resource_entry:
                metadata.update({
                    'reference': resource_entry.reference,
                    'created_at': resource_entry.created_at,
                    'updated_at': resource_entry.updated_at,
                    'exists': True
                })
                metadata.update(resource_entry.metadata)
            else:
                metadata['exists'] = False
        
        return metadata