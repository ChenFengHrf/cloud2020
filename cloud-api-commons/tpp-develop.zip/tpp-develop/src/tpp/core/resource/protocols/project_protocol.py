"""
项目协议处理器 - 实现@project://协议
基于当前项目状态的高性能路径解析
"""

import os
import json
import hashlib
from pathlib import Path
from typing import Dict, Any, Optional, List
from .base_protocol import BaseProtocol


class ProjectProtocol(BaseProtocol):
    """项目协议处理器"""
    
    def __init__(self):
        super().__init__()
        self.protocol_name = "project"
        self.path_resolver = None
        
        # 支持的目录类型
        self.supported_directories = {
            'src': '源代码目录',
            'lib': '库文件目录',
            'docs': '文档目录',
            'test': '测试目录',
            'tests': '测试目录',
            'config': '配置目录',
            'scripts': '脚本目录',
            'assets': '资源目录',
            'public': '公共资源目录',
            'build': '构建输出目录',
            'dist': '分发目录',
            'root': '项目根目录',
            '.promptx': 'PromptX配置目录'
        }
    
    def get_protocol_name(self) -> str:
        """获取协议名称"""
        return self.protocol_name
    
    def get_protocol_info(self) -> Dict[str, Any]:
        """获取协议信息"""
        return {
            "name": self.protocol_name,
            "description": "项目协议，基于当前项目状态的高性能路径解析",
            "location": "project://{directory}/{path}",
            "examples": [
                "project://src/index.js",
                "project://lib/utils.js",
                "project://docs/README.md",
                "project://root/package.json",
                "project://test/unit/"
            ],
            "supported_directories": self.supported_directories,
            "architecture": "state-based",
            "params": self.get_supported_params()
        }
    
    def get_supported_params(self) -> Dict[str, str]:
        """支持的查询参数"""
        return {
            "from": "string - 指定搜索起始目录",
            "create": "boolean - 如果目录不存在是否创建",
            "exists": "boolean - 仅返回存在的文件/目录",
            "type": "string - 过滤类型 (file|dir|both)",
            "format": "string - 输出格式",
            "cache": "boolean - 是否缓存"
        }
    
    def validate_path(self, path: str) -> bool:
        """验证项目协议路径"""
        if not super().validate_path(path):
            return False
        
        # 特殊处理：允许.promptx开头的路径
        if path.startswith('.promptx/'):
            return True
        
        # 解析路径的第一部分（目录类型）
        parts = path.split('/')
        if not parts:
            return False
        
        dir_type = parts[0]
        return dir_type in self.supported_directories
    
    async def get_project_root(self) -> str:
        """获取项目根目录"""
        current_dir = Path.cwd()
        
        # 向上查找项目标识文件
        project_markers = [
            'package.json',
            'pyproject.toml',
            'requirements.txt',
            'Cargo.toml',
            'go.mod',
            '.git',
            '.promptx'
        ]
        
        for parent in [current_dir] + list(current_dir.parents):
            for marker in project_markers:
                if (parent / marker).exists():
                    return str(parent)
        
        # 如果找不到项目标识，返回当前目录
        return str(current_dir)
    
    def generate_project_hash(self, project_path: str) -> str:
        """生成项目路径的Hash值"""
        resolved_path = os.path.abspath(project_path)
        return hashlib.md5(resolved_path.encode()).hexdigest()[:8]
    
    async def resolve_local_path(self, resource_path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """本地模式路径解析"""
        project_root = await self.get_project_root()
        
        # 解析路径
        if resource_path.startswith('.promptx/'):
            # .promptx路径直接映射到项目根目录
            relative_path = resource_path
        else:
            # 其他路径需要解析目录类型
            parts = resource_path.split('/', 1)
            dir_type = parts[0]
            sub_path = parts[1] if len(parts) > 1 else ''
            
            if dir_type == 'root':
                # root目录映射到项目根目录
                relative_path = sub_path
            else:
                # 其他目录直接使用原路径
                relative_path = resource_path
        
        full_path = os.path.join(project_root, relative_path)
        return os.path.abspath(full_path)
    
    async def resolve_http_path(self, resource_path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """HTTP模式路径解析（映射到用户目录）"""
        # 获取项目信息
        project_root = await self.get_project_root()
        project_hash = self.generate_project_hash(project_root)
        
        # HTTP模式专用路径转换
        if resource_path == '.promptx':
            mapped_path = 'data'
        elif resource_path.startswith('.promptx/'):
            mapped_path = resource_path.replace('.promptx/', 'data/', 1)
        else:
            mapped_path = f'data/{resource_path}'
        
        # 映射到用户目录的项目空间
        user_home = os.path.expanduser('~')
        full_path = os.path.join(user_home, '.promptx', 'project', project_hash, mapped_path)
        
        return os.path.abspath(full_path)
    
    async def resolve(self, path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """
        解析项目资源路径并返回内容
        
        Args:
            path: 资源路径，如 "src/index.js"
            query_params: 查询参数
            
        Returns:
            资源内容
            
        Raises:
            FileNotFoundError: 资源不存在
            ValueError: 参数错误
        """
        if not self.validate_path(path):
            raise ValueError(f"无效的项目资源路径: {path}")
        
        try:
            # 检测transport模式（这里简化为本地模式）
            transport = 'local'  # 可以从配置或环境变量获取
            
            if transport == 'http':
                resolved_path = await self.resolve_http_path(path, query_params)
            else:
                resolved_path = await self.resolve_local_path(path, query_params)
            
            # 加载内容
            return await self._load_content(resolved_path, query_params)
            
        except Exception as e:
            raise FileNotFoundError(f"解析@project://路径失败: {e}")
    
    async def _load_content(self, resolved_path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """加载内容"""
        if not os.path.exists(resolved_path):
            # 检查是否需要创建
            if query_params and query_params.get('create'):
                os.makedirs(os.path.dirname(resolved_path), exist_ok=True)
                if not resolved_path.endswith('/'):
                    # 创建空文件
                    with open(resolved_path, 'w', encoding='utf-8') as f:
                        f.write('')
                return ''
            else:
                raise FileNotFoundError(f"项目资源不存在: {resolved_path}")
        
        # 检查是否只返回存在的资源
        if query_params and query_params.get('exists') and not os.path.exists(resolved_path):
            return ''
        
        # 检查类型过滤
        type_filter = query_params.get('type') if query_params else None
        if type_filter:
            is_file = os.path.isfile(resolved_path)
            is_dir = os.path.isdir(resolved_path)
            
            if type_filter == 'file' and not is_file:
                return ''
            elif type_filter == 'dir' and not is_dir:
                return ''
        
        # 加载内容
        if os.path.isdir(resolved_path):
            return await self._load_directory_content(resolved_path, query_params)
        else:
            return await self._load_file_content(resolved_path, query_params)
    
    async def _load_file_content(self, file_path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """加载文件内容"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # 应用查询参数
            if query_params:
                content = self._apply_query_params(content, query_params)
            
            return content
            
        except UnicodeDecodeError:
            # 尝试其他编码
            for encoding in ['gbk', 'latin1']:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        return f.read()
                except UnicodeDecodeError:
                    continue
            
            # 如果都失败，返回文件信息
            return f"Binary file: {os.path.basename(file_path)}"
    
    async def _load_directory_content(self, dir_path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """加载目录内容"""
        try:
            items = []
            for item in sorted(os.listdir(dir_path)):
                item_path = os.path.join(dir_path, item)
                if os.path.isdir(item_path):
                    items.append(f"{item}/")
                else:
                    items.append(item)
            
            content = '\n'.join(items)
            
            # 应用查询参数
            if query_params:
                format_type = query_params.get('format', 'text')
                if format_type == 'json':
                    content = json.dumps(items, ensure_ascii=False, indent=2)
            
            return content
            
        except Exception as e:
            return f"Error reading directory: {e}"
    
    def _apply_query_params(self, content: str, query_params: Dict[str, Any]) -> str:
        """应用查询参数"""
        result = content
        
        # 格式化处理
        format_type = query_params.get("format", "text")
        if format_type == "json":
            try:
                # 尝试解析为JSON并格式化
                parsed = json.loads(result)
                result = json.dumps(parsed, ensure_ascii=False, indent=2)
            except json.JSONDecodeError:
                # 如果不是JSON，包装为JSON
                result = json.dumps({"content": result}, ensure_ascii=False, indent=2)
        
        return result