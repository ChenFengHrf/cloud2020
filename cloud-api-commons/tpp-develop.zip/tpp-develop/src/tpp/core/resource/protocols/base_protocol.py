"""
基础协议处理器 - 所有协议处理器的基类
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional


class BaseProtocol(ABC):
    """协议处理器基类"""
    
    def __init__(self):
        self.registry_manager = None
    
    def set_registry_manager(self, manager):
        """设置注册表管理器"""
        self.registry_manager = manager
    
    @abstractmethod
    async def resolve(self, path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """
        解析资源路径并返回内容
        
        Args:
            path: 资源路径
            query_params: 查询参数
            
        Returns:
            资源内容
            
        Raises:
            FileNotFoundError: 资源不存在
            ValueError: 参数错误
        """
        pass
    
    @abstractmethod
    def get_protocol_name(self) -> str:
        """获取协议名称"""
        pass
    
    def validate_path(self, path: str) -> bool:
        """
        验证路径格式
        
        Args:
            path: 资源路径
            
        Returns:
            是否有效
        """
        return bool(path and isinstance(path, str))
    
    def normalize_path(self, path: str) -> str:
        """
        标准化路径
        
        Args:
            path: 原始路径
            
        Returns:
            标准化后的路径
        """
        return path.strip().replace('\\', '/')
    
    def get_metadata(self, path: str) -> Dict[str, Any]:
        """
        获取资源元数据
        
        Args:
            path: 资源路径
            
        Returns:
            元数据字典
        """
        return {
            'protocol': self.get_protocol_name(),
            'path': path,
            'type': 'resource'
        }