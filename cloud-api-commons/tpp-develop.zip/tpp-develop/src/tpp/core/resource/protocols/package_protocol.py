"""
包协议处理器 - 实现@package://协议
智能检测并访问NPM包资源，支持多种安装模式
"""

import os
import sys
import json
import hashlib
import platform
from pathlib import Path
from typing import Dict, Any, Optional, List
from .base_protocol import BaseProtocol


class PackageProtocol(BaseProtocol):
    """包协议处理器"""
    
    def __init__(self):
        super().__init__()
        self.protocol_name = "package"
        self.install_mode_cache = {}
        
        # 支持的安装模式
        self.install_modes = [
            'development',  # 开发模式
            'local',       # 本地npm install
            'global',      # 全局npm install -g
            'npx',         # npx执行
            'monorepo',    # monorepo workspace
            'link'         # npm link
        ]
    
    def get_protocol_name(self) -> str:
        """获取协议名称"""
        return self.protocol_name
    
    def get_protocol_info(self) -> Dict[str, Any]:
        """获取协议信息"""
        return {
            "name": self.protocol_name,
            "description": "包协议 - 智能访问NPM包资源，支持多种安装模式",
            "examples": [
                "package://package.json",
                "package://src/index.js",
                "package://docs/README.md",
                "package://resource/core/thought.md",
                "package://templates/basic/template.md"
            ],
            "install_modes": self.install_modes,
            "params": self.get_supported_params()
        }
    
    def get_supported_params(self) -> Dict[str, str]:
        """支持的查询参数"""
        return {
            "format": "string - 输出格式 (text|json|binary)",
            "encoding": "string - 文件编码 (utf-8|gbk|ascii)",
            "cache": "boolean - 是否缓存"
        }
    
    async def detect_install_mode(self) -> str:
        """检测当前包安装模式"""
        cache_key = 'current_install_mode'
        if cache_key in self.install_mode_cache:
            return self.install_mode_cache[cache_key]
        
        mode = await self._perform_install_mode_detection()
        self.install_mode_cache[cache_key] = mode
        return mode
    
    async def _perform_install_mode_detection(self) -> str:
        """执行安装模式检测"""
        try:
            cwd = os.getcwd()
            
            # 检测npx执行
            if self._is_npx_execution():
                return 'npx'
            
            # 检测全局安装
            if self._is_global_install():
                return 'global'
            
            # 检测开发模式
            if self._is_development_mode():
                return 'development'
            
            # 检测monorepo
            if self._is_monorepo_workspace():
                return 'monorepo'
            
            # 检测npm link
            if self._is_npm_link():
                return 'link'
            
            # 默认为本地安装
            return 'local'
            
        except Exception:
            return 'local'
    
    def _is_npx_execution(self) -> bool:
        """检测是否是npx执行"""
        # 检查环境变量
        if os.environ.get('npm_execpath'):
            exec_path = os.environ['npm_execpath'].lower()
            if 'npx' in exec_path:
                return True
        
        # 检查npm_config_cache路径
        if os.environ.get('npm_config_cache'):
            cache_path = os.environ['npm_config_cache'].lower()
            if '_npx' in cache_path:
                return True
        
        # 检查执行路径
        if len(sys.argv) > 1:
            script_path = sys.argv[1].lower()
            if '_npx' in script_path:
                return True
        
        # Windows特定检查
        if platform.system() == 'Windows':
            if os.environ.get('npm_execpath'):
                exec_path = os.environ['npm_execpath']
                if exec_path.endswith(('npx.cmd', 'npx.bat')):
                    return True
        
        return False
    
    def _is_global_install(self) -> bool:
        """检测是否是全局安装"""
        current_path = os.path.abspath(__file__)
        
        # 常见全局安装路径
        global_paths = [
            '/usr/lib/node_modules',
            '/usr/local/lib/node_modules',
            '/opt/homebrew/lib/node_modules',
        ]
        
        # 添加用户相关的全局路径
        home = os.path.expanduser('~')
        global_paths.extend([
            os.path.join(home, '.npm-global'),
            os.path.join(home, 'AppData', 'Roaming', 'npm', 'node_modules'),  # Windows
        ])
        
        # 检查PREFIX环境变量
        if os.environ.get('PREFIX'):
            global_paths.append(os.path.join(os.environ['PREFIX'], 'lib', 'node_modules'))
        
        return any(current_path.startswith(global_path) for global_path in global_paths)
    
    def _is_development_mode(self) -> bool:
        """检测是否是开发模式"""
        current_dir = Path(__file__).parent
        
        # 向上查找package.json
        for parent in current_dir.parents:
            package_json = parent / 'package.json'
            if package_json.exists():
                try:
                    with open(package_json, 'r', encoding='utf-8') as f:
                        package_data = json.load(f)
                    
                    # 检查是否有开发依赖或脚本
                    if ('devDependencies' in package_data or 
                        'scripts' in package_data or
                        package_data.get('name') == 'tpp'):  # 项目名称匹配
                        return True
                except Exception:
                    continue
        
        return False
    
    def _is_monorepo_workspace(self) -> bool:
        """检测是否是monorepo工作空间"""
        current_dir = Path(__file__).parent
        
        # 向上查找workspace配置
        for parent in current_dir.parents:
            # 检查package.json中的workspaces
            package_json = parent / 'package.json'
            if package_json.exists():
                try:
                    with open(package_json, 'r', encoding='utf-8') as f:
                        package_data = json.load(f)
                    
                    if 'workspaces' in package_data:
                        return True
                except Exception:
                    continue
            
            # 检查lerna.json
            lerna_json = parent / 'lerna.json'
            if lerna_json.exists():
                return True
            
            # 检查nx.json
            nx_json = parent / 'nx.json'
            if nx_json.exists():
                return True
        
        return False
    
    def _is_npm_link(self) -> bool:
        """检测是否是npm link"""
        current_path = Path(__file__).parent
        
        # 检查是否是符号链接
        try:
            if current_path.is_symlink():
                return True
            
            # 检查父目录是否有符号链接
            for parent in current_path.parents:
                if parent.is_symlink():
                    return True
        except Exception:
            pass
        
        return False
    
    async def get_package_root(self) -> str:
        """获取包根目录"""
        current_dir = Path(__file__).parent
        
        # 向上查找package.json
        for parent in [current_dir] + list(current_dir.parents):
            package_json = parent / 'package.json'
            if package_json.exists():
                return str(parent)
        
        # 如果找不到package.json，返回当前目录
        return str(current_dir)
    
    async def resolve(self, path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """
        解析包资源路径并返回内容
        
        Args:
            path: 资源路径，如 "src/index.js"
            query_params: 查询参数
            
        Returns:
            资源内容
            
        Raises:
            FileNotFoundError: 资源不存在
            ValueError: 参数错误
        """
        if not self.validate_path(path):
            raise ValueError(f"无效的包资源路径: {path}")
        
        # 获取包根目录
        package_root = await self.get_package_root()
        
        # 构建完整路径
        full_path = os.path.join(package_root, path)
        
        # 检查文件是否存在
        if not os.path.exists(full_path):
            raise FileNotFoundError(f"包资源不存在: {path}")
        
        # 加载内容
        return await self._load_file_content(full_path, query_params)
    
    async def _load_file_content(self, file_path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """加载文件内容"""
        try:
            # 确定编码
            encoding = 'utf-8'
            if query_params and 'encoding' in query_params:
                encoding = query_params['encoding']
            
            # 检查是否是二进制文件
            if self._is_binary_file(file_path):
                if query_params and query_params.get('format') == 'binary':
                    with open(file_path, 'rb') as f:
                        content = f.read()
                    return f"Binary file: {len(content)} bytes"
                else:
                    return f"Binary file: {os.path.basename(file_path)}"
            
            # 读取文本文件
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            
            # 应用查询参数
            if query_params:
                content = self._apply_query_params(content, query_params)
            
            return content
            
        except UnicodeDecodeError:
            # 尝试其他编码
            for fallback_encoding in ['gbk', 'latin1', 'ascii']:
                try:
                    with open(file_path, 'r', encoding=fallback_encoding) as f:
                        return f.read()
                except UnicodeDecodeError:
                    continue
            
            # 如果所有编码都失败，作为二进制处理
            return f"Binary file (encoding detection failed): {os.path.basename(file_path)}"
    
    def _is_binary_file(self, file_path: str) -> bool:
        """检测是否是二进制文件"""
        binary_extensions = {
            '.exe', '.dll', '.so', '.dylib', '.bin', '.dat',
            '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.ico',
            '.mp3', '.mp4', '.avi', '.mov', '.wav',
            '.zip', '.tar', '.gz', '.rar', '.7z',
            '.pdf', '.doc', '.docx', '.xls', '.xlsx'
        }
        
        ext = os.path.splitext(file_path)[1].lower()
        return ext in binary_extensions
    
    def _apply_query_params(self, content: str, query_params: Dict[str, Any]) -> str:
        """应用查询参数"""
        result = content
        
        # 格式化处理
        format_type = query_params.get("format", "text")
        if format_type == "json":
            try:
                # 尝试解析为JSON并格式化
                parsed = json.loads(result)
                result = json.dumps(parsed, ensure_ascii=False, indent=2)
            except json.JSONDecodeError:
                # 如果不是JSON，包装为JSON
                result = json.dumps({"content": result}, ensure_ascii=False, indent=2)
        
        return result