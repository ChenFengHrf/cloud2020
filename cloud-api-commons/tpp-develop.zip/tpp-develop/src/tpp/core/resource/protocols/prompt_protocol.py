"""
提示词协议处理器 - 实现@prompt://协议
访问PromptX内置提示词资源
"""

import os
import json
from typing import Dict, Any, Optional
from .base_protocol import BaseProtocol


class PromptProtocol(BaseProtocol):
    """提示词协议处理器"""
    
    def __init__(self):
        super().__init__()
        self.protocol_name = "prompt"
        
        # 内置提示词资源注册表
        self.prompt_registry = {
            'system': {
                'description': '系统级提示词模板',
                'content': self._get_system_prompt_content
            },
            'role-activation': {
                'description': '角色激活提示词模板',
                'content': self._get_role_activation_content
            },
            'memory-recall': {
                'description': '记忆检索提示词模板',
                'content': self._get_memory_recall_content
            },
            'tool-usage': {
                'description': '工具使用提示词模板',
                'content': self._get_tool_usage_content
            },
            'error-handling': {
                'description': '错误处理提示词模板',
                'content': self._get_error_handling_content
            },
            'context-analysis': {
                'description': '上下文分析提示词模板',
                'content': self._get_context_analysis_content
            }
        }
    
    def get_protocol_name(self) -> str:
        """获取协议名称"""
        return self.protocol_name
    
    def get_protocol_info(self) -> Dict[str, Any]:
        """获取协议信息"""
        return {
            "name": self.protocol_name,
            "description": "提示词协议，访问PromptX内置提示词资源",
            "location": "prompt://{prompt_id}",
            "examples": [
                "prompt://system",
                "prompt://role-activation",
                "prompt://memory-recall",
                "prompt://tool-usage"
            ],
            "available_prompts": list(self.prompt_registry.keys()),
            "params": self.get_supported_params()
        }
    
    def get_supported_params(self) -> Dict[str, str]:
        """支持的查询参数"""
        return {
            "merge": "boolean - 是否合并多个提示词",
            "separator": "string - 合并时的分隔符",
            "include_filename": "boolean - 是否包含文件名",
            "format": "string - 输出格式 (text|json|yaml)",
            "variables": "object - 模板变量替换"
        }
    
    def validate_path(self, path: str) -> bool:
        """验证提示词协议路径"""
        if not super().validate_path(path):
            return False
        
        # 检查是否为已注册的提示词
        prompt_id = path.split('/')[0] if '/' in path else path
        return prompt_id in self.prompt_registry
    
    async def resolve(self, path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """
        解析提示词资源路径并返回内容
        
        Args:
            path: 资源路径，如 "system" 或 "role-activation"
            query_params: 查询参数
            
        Returns:
            提示词内容
            
        Raises:
            FileNotFoundError: 提示词不存在
            ValueError: 参数错误
        """
        if not self.validate_path(path):
            raise ValueError(f"无效的提示词资源路径: {path}")
        
        try:
            # 解析路径
            prompt_id = path.split('/')[0] if '/' in path else path
            
            # 获取提示词内容
            prompt_info = self.prompt_registry[prompt_id]
            content = prompt_info['content']()
            
            # 应用查询参数
            if query_params:
                content = self._apply_query_params(content, query_params)
            
            return content
            
        except Exception as e:
            raise FileNotFoundError(f"解析@prompt://路径失败: {e}")
    
    def _get_system_prompt_content(self) -> str:
        """获取系统提示词内容"""
        return """# 系统提示词模板

## 角色定义
你是一个专业的AI助手，具备以下能力：
- 深度理解用户需求
- 提供准确的技术建议
- 遵循最佳实践原则

## 行为准则
1. 始终保持专业和友好的态度
2. 提供准确、有用的信息
3. 承认不确定性，避免猜测
4. 遵循安全和伦理准则

## 响应格式
- 使用清晰、结构化的回答
- 提供具体的示例和解释
- 包含相关的参考资料
"""
    
    def _get_role_activation_content(self) -> str:
        """获取角色激活提示词内容"""
        return """# 角色激活提示词模板

## 激活指令
现在你将扮演 {role_name} 角色，具备以下特征：

### 专业背景
{professional_background}

### 核心技能
{core_skills}

### 思维模式
{thinking_patterns}

### 工作原则
{working_principles}

## 激活确认
请确认你已经完全理解并准备以 {role_name} 的身份为用户提供专业服务。
"""
    
    def _get_memory_recall_content(self) -> str:
        """获取记忆检索提示词内容"""
        return """# 记忆检索提示词模板

## 检索指令
基于当前上下文，检索相关的记忆和经验：

### 检索范围
- 相关的专业知识
- 类似问题的解决方案
- 用户的历史偏好
- 项目特定信息

### 检索策略
1. 关键词匹配
2. 语义相似性分析
3. 上下文关联度评估
4. 时间相关性考虑

### 输出格式
- 按相关性排序
- 包含置信度评分
- 提供记忆来源
"""
    
    def _get_tool_usage_content(self) -> str:
        """获取工具使用提示词内容"""
        return """# 工具使用提示词模板

## 工具调用指南
在使用工具时，请遵循以下原则：

### 调用前检查
1. 确认工具的适用性
2. 验证必需参数
3. 评估预期结果
4. 考虑替代方案

### 调用过程
1. 准确传递参数
2. 监控执行状态
3. 处理异常情况
4. 验证输出结果

### 调用后处理
1. 解释执行结果
2. 提供后续建议
3. 记录重要信息
4. 更新相关状态
"""
    
    def _get_error_handling_content(self) -> str:
        """获取错误处理提示词内容"""
        return """# 错误处理提示词模板

## 错误处理策略
当遇到错误时，请按以下步骤处理：

### 错误识别
1. 分析错误类型
2. 确定错误来源
3. 评估影响范围
4. 记录错误信息

### 错误处理
1. 提供友好的错误说明
2. 建议可能的解决方案
3. 指导用户进行修复
4. 预防类似错误

### 恢复策略
1. 尝试自动恢复
2. 提供手动修复步骤
3. 建议替代方案
4. 确保系统稳定性
"""
    
    def _get_context_analysis_content(self) -> str:
        """获取上下文分析提示词内容"""
        return """# 上下文分析提示词模板

## 上下文分析框架
对当前情况进行全面分析：

### 环境分析
- 技术环境和约束
- 业务背景和目标
- 用户需求和期望
- 资源可用性

### 问题分析
- 核心问题识别
- 问题复杂度评估
- 依赖关系分析
- 风险因素评估

### 解决方案分析
- 可行性评估
- 成本效益分析
- 实施难度评估
- 预期效果分析
"""
    
    def _apply_query_params(self, content: str, query_params: Dict[str, Any]) -> str:
        """应用查询参数"""
        result = content
        
        # 变量替换
        variables = query_params.get("variables", {})
        if variables and isinstance(variables, dict):
            for key, value in variables.items():
                result = result.replace(f"{{{key}}}", str(value))
        
        # 格式化处理
        format_type = query_params.get("format", "text")
        if format_type == "json":
            result = json.dumps({"content": result}, ensure_ascii=False, indent=2)
        elif format_type == "yaml":
            # 简单的YAML格式化
            lines = result.split('\n')
            yaml_lines = []
            for line in lines:
                if line.startswith('#'):
                    yaml_lines.append(f"# {line[1:].strip()}")
                elif line.strip():
                    yaml_lines.append(f"content: |")
                    yaml_lines.append(f"  {line}")
            result = '\n'.join(yaml_lines)
        
        # 包含文件名
        if query_params.get("include_filename"):
            result = f"# Prompt: {query_params.get('prompt_id', 'unknown')}\n\n{result}"
        
        return result