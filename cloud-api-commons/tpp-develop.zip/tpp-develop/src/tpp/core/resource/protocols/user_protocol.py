"""
用户协议处理器 - 实现@user://协议
映射到用户主目录的协议
"""

import os
import json
from pathlib import Path
from typing import Dict, Any, Optional
from .base_protocol import BaseProtocol


class UserProtocol(BaseProtocol):
    """用户协议处理器"""
    
    def __init__(self):
        super().__init__()
        self.protocol_name = "user"
        
        # 支持的用户目录
        self.user_directories = {
            'desktop': '桌面目录',
            'documents': '文档目录',
            'downloads': '下载目录',
            'pictures': '图片目录',
            'music': '音乐目录',
            'videos': '视频目录',
            'home': '用户主目录',
            'data': '数据目录',
            'config': '配置目录',
            'cache': '缓存目录',
            'log': '日志目录',
            'temp': '临时目录'
        }
        
        # env-paths标准目录映射
        self.env_paths_mapping = {
            'data': self._get_data_dir,
            'config': self._get_config_dir,
            'cache': self._get_cache_dir,
            'log': self._get_log_dir,
            'temp': self._get_temp_dir
        }
    
    def get_protocol_name(self) -> str:
        """获取协议名称"""
        return self.protocol_name
    
    def get_protocol_info(self) -> Dict[str, Any]:
        """获取协议信息"""
        return {
            "name": self.protocol_name,
            "description": "用户目录协议，映射到用户主目录",
            "location": "user://{directory}/{path}",
            "examples": [
                "user://desktop/file.txt",
                "user://documents/project/",
                "user://downloads/archive.zip",
                "user://data/app/settings.json",
                "user://config/app.conf"
            ],
            "supported_directories": self.user_directories,
            "env_paths_support": True,
            "params": self.get_supported_params()
        }
    
    def get_supported_params(self) -> Dict[str, str]:
        """支持的查询参数"""
        return {
            "create": "boolean - 如果目录不存在是否创建",
            "exists": "boolean - 仅返回存在的文件/目录",
            "type": "string - 过滤类型 (file|dir|both)",
            "format": "string - 输出格式",
            "encoding": "string - 文件编码"
        }
    
    def validate_path(self, path: str) -> bool:
        """验证用户协议路径"""
        if not super().validate_path(path):
            return False
        
        # 解析路径的第一部分（目录类型）
        parts = path.split('/')
        if not parts:
            return False
        
        dir_type = parts[0]
        return dir_type in self.user_directories
    
    def _get_user_home(self) -> str:
        """获取用户主目录"""
        return os.path.expanduser('~')
    
    def _get_data_dir(self) -> str:
        """获取数据目录"""
        if os.name == 'nt':  # Windows
            return os.path.join(os.environ.get('APPDATA', self._get_user_home()), 'Local')
        elif os.name == 'posix':  # Unix/Linux/macOS
            if 'darwin' in os.uname().sysname.lower():  # macOS
                return os.path.join(self._get_user_home(), 'Library', 'Application Support')
            else:  # Linux
                return os.environ.get('XDG_DATA_HOME', os.path.join(self._get_user_home(), '.local', 'share'))
        return self._get_user_home()
    
    def _get_config_dir(self) -> str:
        """获取配置目录"""
        if os.name == 'nt':  # Windows
            return os.environ.get('APPDATA', self._get_user_home())
        elif os.name == 'posix':  # Unix/Linux/macOS
            if 'darwin' in os.uname().sysname.lower():  # macOS
                return os.path.join(self._get_user_home(), 'Library', 'Preferences')
            else:  # Linux
                return os.environ.get('XDG_CONFIG_HOME', os.path.join(self._get_user_home(), '.config'))
        return self._get_user_home()
    
    def _get_cache_dir(self) -> str:
        """获取缓存目录"""
        if os.name == 'nt':  # Windows
            return os.path.join(os.environ.get('LOCALAPPDATA', self._get_user_home()), 'Temp')
        elif os.name == 'posix':  # Unix/Linux/macOS
            if 'darwin' in os.uname().sysname.lower():  # macOS
                return os.path.join(self._get_user_home(), 'Library', 'Caches')
            else:  # Linux
                return os.environ.get('XDG_CACHE_HOME', os.path.join(self._get_user_home(), '.cache'))
        return self._get_user_home()
    
    def _get_log_dir(self) -> str:
        """获取日志目录"""
        if os.name == 'nt':  # Windows
            return os.path.join(os.environ.get('LOCALAPPDATA', self._get_user_home()), 'Logs')
        elif os.name == 'posix':  # Unix/Linux/macOS
            if 'darwin' in os.uname().sysname.lower():  # macOS
                return os.path.join(self._get_user_home(), 'Library', 'Logs')
            else:  # Linux
                return os.path.join(self._get_user_home(), '.local', 'share', 'logs')
        return self._get_user_home()
    
    def _get_temp_dir(self) -> str:
        """获取临时目录"""
        import tempfile
        return tempfile.gettempdir()
    
    def _resolve_user_directory(self, dir_type: str) -> str:
        """解析用户目录类型到实际路径"""
        user_home = self._get_user_home()
        
        # env-paths标准目录
        if dir_type in self.env_paths_mapping:
            return self.env_paths_mapping[dir_type]()
        
        # 常见用户目录
        directory_mapping = {
            'home': user_home,
            'desktop': os.path.join(user_home, 'Desktop'),
            'documents': os.path.join(user_home, 'Documents'),
            'downloads': os.path.join(user_home, 'Downloads'),
            'pictures': os.path.join(user_home, 'Pictures'),
            'music': os.path.join(user_home, 'Music'),
            'videos': os.path.join(user_home, 'Videos')
        }
        
        return directory_mapping.get(dir_type, user_home)
    
    async def resolve(self, path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """
        解析用户资源路径并返回内容
        
        Args:
            path: 资源路径，如 "desktop/file.txt"
            query_params: 查询参数
            
        Returns:
            资源内容
            
        Raises:
            FileNotFoundError: 资源不存在
            ValueError: 参数错误
        """
        if not self.validate_path(path):
            raise ValueError(f"无效的用户资源路径: {path}")
        
        try:
            # 解析路径
            parts = path.split('/', 1)
            dir_type = parts[0]
            sub_path = parts[1] if len(parts) > 1 else ''
            
            # 获取基础目录
            base_dir = self._resolve_user_directory(dir_type)
            
            # 构建完整路径
            if sub_path:
                full_path = os.path.join(base_dir, sub_path)
            else:
                full_path = base_dir
            
            full_path = os.path.abspath(full_path)
            
            # 加载内容
            return await self._load_content(full_path, query_params)
            
        except Exception as e:
            raise FileNotFoundError(f"解析@user://路径失败: {e}")
    
    async def _load_content(self, resolved_path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """加载内容"""
        if not os.path.exists(resolved_path):
            # 检查是否需要创建
            if query_params and query_params.get('create'):
                os.makedirs(os.path.dirname(resolved_path), exist_ok=True)
                if not resolved_path.endswith('/'):
                    # 创建空文件
                    with open(resolved_path, 'w', encoding='utf-8') as f:
                        f.write('')
                return ''
            else:
                raise FileNotFoundError(f"用户资源不存在: {resolved_path}")
        
        # 检查是否只返回存在的资源
        if query_params and query_params.get('exists') and not os.path.exists(resolved_path):
            return ''
        
        # 检查类型过滤
        type_filter = query_params.get('type') if query_params else None
        if type_filter:
            is_file = os.path.isfile(resolved_path)
            is_dir = os.path.isdir(resolved_path)
            
            if type_filter == 'file' and not is_file:
                return ''
            elif type_filter == 'dir' and not is_dir:
                return ''
        
        # 加载内容
        if os.path.isdir(resolved_path):
            return await self._load_directory_content(resolved_path, query_params)
        else:
            return await self._load_file_content(resolved_path, query_params)
    
    async def _load_file_content(self, file_path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """加载文件内容"""
        try:
            # 获取编码设置
            encoding = query_params.get('encoding', 'utf-8') if query_params else 'utf-8'
            
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            
            # 应用查询参数
            if query_params:
                content = self._apply_query_params(content, query_params)
            
            return content
            
        except UnicodeDecodeError:
            # 尝试其他编码
            for encoding in ['gbk', 'latin1']:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        return f.read()
                except UnicodeDecodeError:
                    continue
            
            # 如果都失败，返回文件信息
            return f"Binary file: {os.path.basename(file_path)}"
    
    async def _load_directory_content(self, dir_path: str, query_params: Optional[Dict[str, Any]] = None) -> str:
        """加载目录内容"""
        try:
            items = []
            for item in sorted(os.listdir(dir_path)):
                item_path = os.path.join(dir_path, item)
                if os.path.isdir(item_path):
                    items.append(f"{item}/")
                else:
                    items.append(item)
            
            content = '\n'.join(items)
            
            # 应用查询参数
            if query_params:
                format_type = query_params.get('format', 'text')
                if format_type == 'json':
                    content = json.dumps(items, ensure_ascii=False, indent=2)
            
            return content
            
        except Exception as e:
            return f"Error reading directory: {e}"
    
    def _apply_query_params(self, content: str, query_params: Dict[str, Any]) -> str:
        """应用查询参数"""
        result = content
        
        # 格式化处理
        format_type = query_params.get("format", "text")
        if format_type == "json":
            try:
                # 尝试解析为JSON并格式化
                parsed = json.loads(result)
                result = json.dumps(parsed, ensure_ascii=False, indent=2)
            except json.JSONDecodeError:
                # 如果不是JSON，包装为JSON
                result = json.dumps({"content": result}, ensure_ascii=False, indent=2)
        
        return result