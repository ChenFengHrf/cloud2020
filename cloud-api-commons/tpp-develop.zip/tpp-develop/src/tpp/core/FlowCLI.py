import asyncio
import sys
from typing import Dict, List, Any, Optional
from .FlowStateMachine import FlowStateMachine
from .CommandManager import CommandManager
from .BaseCommand import BaseCommand
from .resource import ResourceManager


class FlowCLI:
    """
    流程CLI主入口
    提供命令行接口和统一的执行入口
    """
    
    def __init__(self, working_directory: str = None):
        self.state_machine = FlowStateMachine()
        self.command_manager = CommandManager()
        self.resource_manager = ResourceManager(working_directory)
        self.initialized = False
    
    async def initialize(self):
        """初始化CLI"""
        if self.initialized:
            return
        
        # 初始化资源管理器
        await self.resource_manager.initialize()
        
        # 批量注册所有命令
        # 这里可以根据需要注册具体的命令实现
        # self.command_manager.register_batch({
        #     "init": InitCommand,
        #     "welcome": WelcomeCommand,
        #     "action": ActionCommand,
        #     "learn": LearnCommand,
        #     "recall": RecallCommand,
        #     "remember": RememberCommand,
        #     "tool": ToolCommand
        # })
        
        # 将命令注册到状态机
        for name in self.command_manager.registry.list_commands():
            command_class = self.command_manager.registry.get_command_class(name)
            if command_class:
                self.state_machine.register_command(name, command_class)
        
        # 加载历史状态
        await self.state_machine.load_state()
        
        self.initialized = True
    
    async def execute(self, command_name: str, args: List[str] = None, silent: bool = False) -> Any:
        """
        执行命令
        
        Args:
            command_name: 命令名称
            args: 命令参数
            silent: 静默模式，不输出到console（用于MCP）
            
        Returns:
            执行结果
        """
        if args is None:
            args = []
            
        # 确保已初始化
        if not self.initialized:
            await self.initialize()
        
        # 处理内置命令
        if command_name == "help":
            help_text = self.get_help()
            if not silent:
                print(help_text)
            return {"content": help_text}
        
        elif command_name == "status":
            status = self.get_status()
            if not silent:
                import json
                print(json.dumps(status, indent=2, ensure_ascii=False))
            return {"content": status}
        
        # 处理资源管理命令
        elif command_name == "resource":
            return await self._handle_resource_command(args, silent)
        
        elif command_name == "load":
            return await self._handle_load_command(args, silent)
        
        # 解析复合命令（如 "action python-expert"）
        if args and len(args) > 0:
            full_command = f"{command_name} {' '.join(args)}"
            parsed = self.parse_command(full_command)
            command_name = parsed["command"]
            args = parsed["args"]
        
        # 验证命令是否存在
        if command_name not in self.command_manager.registry.list_commands():
            raise ValueError(f"未知命令: {command_name}\n使用 'help' 查看可用命令")
        
        try:
            # 通过状态机执行命令
            result = await self.state_machine.transition(command_name, args)
            
            # 只在非静默模式下输出（避免干扰MCP协议）
            if not silent:
                # 如果结果有 __str__ 方法，打印人类可读格式
                if result and hasattr(result, '__str__'):
                    print(str(result))
                else:
                    import json
                    print(json.dumps(result, indent=2, ensure_ascii=False))
            
            return result
            
        except Exception as error:
            # 错误输出始终使用stderr，不干扰MCP协议
            if not silent:
                print(f"执行命令出错: {error}", file=sys.stderr)
            raise error
    
    def get_help(self) -> str:
        """
        获取帮助信息
        
        Returns:
            帮助文本
        """
        commands = self.command_manager.list_commands()
        current_state = self.state_machine.get_current_state()
        available_transitions = self.state_machine.get_available_transitions()
        
        help_text = f"""
🎯 PromptX 流程系统帮助
========================

当前状态: {current_state}
可用转换: {', '.join(available_transitions)}

📋 可用命令:
"""
        
        for cmd in commands:
            help_text += f"\n  {cmd['name']:<12} - {cmd['purpose']}"
        
        help_text += """

💡 使用示例:
        init              # 初始化工作环境
        welcome           # 发现可用角色
        action copywriter # 激活文案专家
        learn scrum       # 学习敏捷知识
        recall frontend   # 检索前端记忆
        resource list     # 列出所有资源
        load role://assistant # 加载角色资源

🔄 PATEOAS 导航:
每个命令执行后都会提供下一步的建议操作，
按照提示即可完成完整的工作流程。

📚 更多信息请访问: https://github.com/yourusername/promptx
"""
        
        return help_text
    
    def get_status(self) -> Dict[str, Any]:
        """
        获取当前状态信息
        
        Returns:
            状态上下文
        """
        return {
            "current_state": self.state_machine.get_current_state(),
            "available_commands": self.command_manager.registry.list_commands(),
            "available_transitions": self.state_machine.get_available_transitions(),
            "context": self.state_machine.context,
            "initialized": self.initialized,
            "resource_manager": self.resource_manager.get_stats()
        }
    
    def parse_command(self, input_text: str) -> Dict[str, Any]:
        """
        解析命令行输入
        
        Args:
            input_text: 用户输入
            
        Returns:
            解析结果
        """
        parts = input_text.strip().split()
        command = parts[0] if parts else ""
        args = parts[1:] if len(parts) > 1 else []
        
        return {
            "command": command,
            "args": args
        }
    
    async def run_interactive(self):
        """运行交互式CLI"""
        print("🎯 欢迎使用 PromptX 流程系统！")
        print('输入 "help" 查看帮助，"exit" 退出\n')
        
        try:
            while True:
                try:
                    user_input = input("promptx> ").strip()
                    
                    if user_input in ["exit", "quit"]:
                        print("再见！")
                        break
                    
                    if user_input == "help":
                        print(self.get_help())
                    elif user_input == "status":
                        import json
                        print(json.dumps(self.get_status(), indent=2, ensure_ascii=False))
                    elif user_input:
                        parsed = self.parse_command(user_input)
                        command = parsed["command"]
                        args = parsed["args"]
                        
                        try:
                            await self.execute(command, args)
                        except Exception as error:
                            print(f"错误: {error}", file=sys.stderr)
                    
                except KeyboardInterrupt:
                    print("\n再见！")
                    break
                except EOFError:
                    print("\n再见！")
                    break
                    
        except Exception as error:
            print(f"CLI运行出错: {error}", file=sys.stderr)
    
    async def _handle_resource_command(self, args: List[str], silent: bool = False) -> Dict[str, Any]:
        """
        处理资源管理命令
        
        Args:
            args: 命令参数
            silent: 静默模式
            
        Returns:
            执行结果
        """
        if not args:
            # 显示资源管理帮助
            help_text = """
🔧 资源管理命令帮助
==================

resource list [type]     - 列出资源（可选择类型：role, tool, manual）
resource stats           - 显示资源统计信息
resource refresh         - 刷新资源发现
resource info <id>       - 显示资源详细信息
resource register <id> <type> <reference> - 注册新资源

💡 使用示例:
resource list role       # 列出所有角色资源
resource info assistant  # 显示assistant资源信息
resource refresh         # 重新扫描项目资源
"""
            if not silent:
                print(help_text)
            return {"content": help_text}
        
        subcommand = args[0]
        
        if subcommand == "list":
            resource_type = args[1] if len(args) > 1 else None
            resources = self.resource_manager.list_resources(resource_type)
            
            if not silent:
                print(f"\n📋 资源列表 ({resource_type or '全部'}):")
                print("=" * 40)
                for resource in resources:
                    print(f"  {resource['id']:<15} [{resource['type']}] - {resource['reference']}")
                print(f"\n总计: {len(resources)} 个资源")
            
            return {"content": resources}
        
        elif subcommand == "stats":
            stats = self.resource_manager.get_stats()
            
            if not silent:
                print("\n📊 资源管理器统计:")
                print("=" * 30)
                print(f"  工作目录: {stats['working_directory']}")
                print(f"  已初始化: {stats['initialized']}")
                print(f"  支持协议: {', '.join(stats['protocols'])}")
                print(f"  总资源数: {stats['total_resources']}")
                print("\n  按类型分布:")
                for res_type, count in stats['resources_by_type'].items():
                    print(f"    {res_type}: {count}")
            
            return {"content": stats}
        
        elif subcommand == "refresh":
            success = await self.resource_manager.refresh_resources()
            message = "资源刷新成功" if success else "资源刷新失败"
            
            if not silent:
                print(f"🔄 {message}")
            
            return {"content": {"success": success, "message": message}}
        
        elif subcommand == "info":
            if len(args) < 2:
                error_msg = "请提供资源ID"
                if not silent:
                    print(f"❌ {error_msg}")
                return {"error": error_msg}
            
            resource_id = args[1]
            metadata = self.resource_manager.get_resource_metadata(resource_id)
            
            if not metadata:
                error_msg = f"资源不存在: {resource_id}"
                if not silent:
                    print(f"❌ {error_msg}")
                return {"error": error_msg}
            
            if not silent:
                print(f"\n📄 资源信息: {resource_id}")
                print("=" * 30)
                print(f"  ID: {metadata['id']}")
                print(f"  类型: {metadata['type']}")
                print(f"  引用: {metadata['reference']}")
                print(f"  创建时间: {metadata['created_at']}")
                print(f"  更新时间: {metadata['updated_at']}")
                if metadata['metadata']:
                    print("  元数据:")
                    for key, value in metadata['metadata'].items():
                        print(f"    {key}: {value}")
            
            return {"content": metadata}
        
        elif subcommand == "register":
            if len(args) < 4:
                error_msg = "用法: resource register <id> <type> <reference>"
                if not silent:
                    print(f"❌ {error_msg}")
                return {"error": error_msg}
            
            resource_id, resource_type, reference = args[1], args[2], args[3]
            success = await self.resource_manager.register_resource(
                resource_id, resource_type, reference
            )
            
            message = f"资源注册{'成功' if success else '失败'}: {resource_id}"
            if not silent:
                print(f"{'✅' if success else '❌'} {message}")
            
            return {"content": {"success": success, "message": message}}
        
        else:
            error_msg = f"未知的资源命令: {subcommand}"
            if not silent:
                print(f"❌ {error_msg}")
            return {"error": error_msg}
    
    async def _handle_load_command(self, args: List[str], silent: bool = False) -> Dict[str, Any]:
        """
        处理资源加载命令
        
        Args:
            args: 命令参数
            silent: 静默模式
            
        Returns:
            执行结果
        """
        if not args:
            error_msg = "请提供资源引用，例如: load role://assistant"
            if not silent:
                print(f"❌ {error_msg}")
            return {"error": error_msg}
        
        resource_reference = args[0]
        
        try:
            content = await self.resource_manager.load_resource(resource_reference)
            
            if not silent:
                print(f"✅ 成功加载资源: {resource_reference}")
                print("=" * 50)
                print(content[:500] + "..." if len(content) > 500 else content)
            
            return {"content": content, "reference": resource_reference}
            
        except Exception as e:
            error_msg = f"加载资源失败: {e}"
            if not silent:
                print(f"❌ {error_msg}")
            return {"error": error_msg}