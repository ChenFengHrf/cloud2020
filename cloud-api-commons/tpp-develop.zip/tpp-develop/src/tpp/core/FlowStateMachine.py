


import json
import os
from datetime import datetime
from typing import Dict, List, Any, Optional
import asyncio


class FlowStateMachine:
    """
    流程状态机管理器
    负责管理命令之间的状态转换
    """
    
    def __init__(self):
        self.current_state = "initial"
        self.state_history = []
        self.context = {
            "current_pouch": "",
            "history": [],
            "user_profile": {},
            "session_data": {},
            "domain_context": {}
        }
        self.commands = {}
    
    def register_command(self, name: str, command):
        """
        注册命令
        
        Args:
            name: 命令名称
            command: 命令实例
        """
        self.commands[name] = command
    
    async def transition(self, command_name: str, args: List[str] = None) -> Any:
        """
        执行状态转换
        
        Args:
            command_name: 命令名称
            args: 命令参数
            
        Returns:
            执行结果
        """
        if args is None:
            args = []
            
        # 获取命令对应的实例
        command = self.commands.get(command_name)
        if not command:
            raise ValueError(f"未找到命令: {command_name}")
        
        # 记录历史
        self.state_history.append({
            "from": self.current_state,
            "command": command_name,
            "timestamp": datetime.now().isoformat(),
            "args": args
        })
        
        # 更新上下文
        self.context["current_pouch"] = command_name
        self.context["history"] = [h.get("command", h.get("to", "")) for h in self.state_history]
        
        # 设置命令上下文
        if hasattr(command, 'set_context'):
            command.set_context(self.context)
        
        # 执行命令
        result = await command.execute(args)
        
        # 根据PATEOAS导航更新状态
        if result and isinstance(result, dict) and "pateoas" in result:
            pateoas = result["pateoas"]
            if isinstance(pateoas, dict) and "current_state" in pateoas:
                self.current_state = pateoas["current_state"]
        
        # 保存状态
        await self.save_state()
        
        return result
    
    def get_current_state(self) -> str:
        """获取当前状态"""
        return self.current_state
    
    def get_available_transitions(self) -> List[str]:
        """
        获取可用的状态转换
        
        Returns:
            可转换的状态列表
        """
        transitions = {
            "initial": ["init", "welcome"],
            "initialized": ["welcome", "action", "learn"],
            "discovering": ["action", "learn", "init"],
            "activated": ["learn", "recall", "welcome"],
            "learned": ["action", "recall", "welcome"],
            "recalled": ["action", "learn", "remember"]
        }
        
        # 根据当前状态的前缀匹配
        for state_prefix, available_states in transitions.items():
            if self.current_state.startswith(state_prefix):
                return available_states
        
        # 默认可转换状态
        return ["welcome", "init"]
    
    async def save_state(self):
        """保存状态到文件"""
        try:
            # 检查项目是否已初始化
            if not self._is_project_initialized():
                # 项目未初始化，只保存在内存中，不持久化到文件
                return
            
            # 获取.promptx目录
            promptx_dir = self._get_promptx_dir()
            config_path = os.path.join(promptx_dir, "pouch.json")
            
            # 确保.promptx目录存在
            os.makedirs(promptx_dir, exist_ok=True)
            
            config = {}
            if os.path.exists(config_path):
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
            
            config["current_state"] = self.current_state
            config["state_history"] = self.state_history[-50:]  # 只保留最近50条记录
            config["last_updated"] = datetime.now().isoformat()
            
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
                
        except Exception as error:
            print(f"保存状态失败: {error}")
    
    async def load_state(self):
        """从文件加载状态"""
        try:
            # 检查项目是否已初始化
            if not self._is_project_initialized():
                # 项目未初始化，使用默认内存状态
                return
            
            # 获取.promptx目录
            promptx_dir = self._get_promptx_dir()
            config_path = os.path.join(promptx_dir, "pouch.json")
            
            if os.path.exists(config_path):
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                
                if "current_state" in config:
                    self.current_state = config["current_state"]
                
                if "state_history" in config:
                    self.state_history = config["state_history"]
                    
        except Exception as error:
            print(f"加载状态失败: {error}")
    
    def reset(self):
        """重置状态机"""
        self.current_state = "initial"
        self.state_history = []
        self.context = {
            "current_pouch": "",
            "history": [],
            "user_profile": {},
            "session_data": {},
            "domain_context": {}
        }
    
    def _is_project_initialized(self) -> bool:
        """检查项目是否已初始化"""
        # 简单检查当前目录或父目录是否有.promptx目录
        current_dir = os.getcwd()
        while current_dir != os.path.dirname(current_dir):  # 直到根目录
            if os.path.exists(os.path.join(current_dir, ".promptx")):
                return True
            current_dir = os.path.dirname(current_dir)
        return False
    
    def _get_promptx_dir(self) -> str:
        """获取.promptx目录路径"""
        current_dir = os.getcwd()
        while current_dir != os.path.dirname(current_dir):  # 直到根目录
            promptx_path = os.path.join(current_dir, ".promptx")
            if os.path.exists(promptx_path):
                return promptx_path
            current_dir = os.path.dirname(current_dir)
        
        # 如果没找到，在当前目录创建
        return os.path.join(os.getcwd(), ".promptx")