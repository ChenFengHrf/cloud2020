"""
状态管理器

提供全局状态管理功能，协调多个状态机实例。
"""

from typing import Dict, Optional, Any
import threading
from .TPPStateMachine import TPPStateMachine, TPPState, ExecutionContext


class StateManager:
    """
    状态管理器
    
    管理多个状态机实例，提供全局状态协调功能。
    支持会话级别的状态隔离。
    """
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if not hasattr(self, 'initialized'):
            self.state_machines: Dict[str, TPPStateMachine] = {}
            self.default_session = "default"
            self._lock = threading.Lock()
            self.initialized = True
    
    def get_state_machine(self, session_id: Optional[str] = None) -> TPPStateMachine:
        """
        获取状态机实例
        
        Args:
            session_id: 会话ID，如果为None则使用默认会话
            
        Returns:
            状态机实例
        """
        session_id = session_id or self.default_session
        
        with self._lock:
            if session_id not in self.state_machines:
                self.state_machines[session_id] = TPPStateMachine()
            
            return self.state_machines[session_id]
    
    def create_session(self, session_id: str, initial_state: TPPState = TPPState.IDLE) -> TPPStateMachine:
        """
        创建新的会话状态机
        
        Args:
            session_id: 会话ID
            initial_state: 初始状态
            
        Returns:
            新创建的状态机实例
        """
        with self._lock:
            if session_id in self.state_machines:
                # 如果会话已存在，重置状态机
                self.state_machines[session_id].reset()
            else:
                self.state_machines[session_id] = TPPStateMachine(initial_state)
            
            return self.state_machines[session_id]
    
    def remove_session(self, session_id: str) -> bool:
        """
        移除会话状态机
        
        Args:
            session_id: 会话ID
            
        Returns:
            是否成功移除
        """
        with self._lock:
            if session_id in self.state_machines:
                del self.state_machines[session_id]
                return True
            return False
    
    def get_all_sessions(self) -> Dict[str, Dict[str, Any]]:
        """获取所有会话的状态信息"""
        with self._lock:
            return {
                session_id: state_machine.get_state_info()
                for session_id, state_machine in self.state_machines.items()
            }
    
    def execute_command(
        self,
        command: str,
        args: Dict[str, Any],
        session_id: Optional[str] = None,
        user_id: Optional[str] = None
    ) -> TPPStateMachine:
        """
        执行命令并管理状态
        
        Args:
            command: 命令名称
            args: 命令参数
            session_id: 会话ID
            user_id: 用户ID
            
        Returns:
            状态机实例
        """
        state_machine = self.get_state_machine(session_id)
        
        # 设置执行上下文
        context = ExecutionContext(
            command=command,
            args=args,
            user_id=user_id,
            session_id=session_id or self.default_session
        )
        state_machine.set_context(context)
        
        # 触发执行状态转换
        if state_machine.current_state == TPPState.IDLE:
            state_machine.trigger("execute", {"command": command, "args": args})
        
        return state_machine
    
    def complete_command(
        self,
        session_id: Optional[str] = None,
        result: Optional[Any] = None
    ) -> bool:
        """
        完成命令执行
        
        Args:
            session_id: 会话ID
            result: 执行结果
            
        Returns:
            是否成功完成
        """
        state_machine = self.get_state_machine(session_id)
        
        if result is not None:
            state_machine.set_state_data("result", result)
        
        return state_machine.trigger("complete", {"result": result})
    
    def error_command(
        self,
        error: str,
        session_id: Optional[str] = None,
        error_data: Optional[Any] = None
    ) -> bool:
        """
        标记命令执行错误
        
        Args:
            error: 错误信息
            session_id: 会话ID
            error_data: 错误数据
            
        Returns:
            是否成功标记错误
        """
        state_machine = self.get_state_machine(session_id)
        
        state_machine.set_state_data("error", error)
        if error_data is not None:
            state_machine.set_state_data("error_data", error_data)
        
        return state_machine.trigger("error", {"error": error, "error_data": error_data})
    
    def reset_session(self, session_id: Optional[str] = None) -> bool:
        """
        重置会话状态
        
        Args:
            session_id: 会话ID
            
        Returns:
            是否成功重置
        """
        state_machine = self.get_state_machine(session_id)
        state_machine.reset()
        return True
    
    def get_session_status(self, session_id: Optional[str] = None) -> Dict[str, Any]:
        """
        获取会话状态
        
        Args:
            session_id: 会话ID
            
        Returns:
            会话状态信息
        """
        state_machine = self.get_state_machine(session_id)
        return state_machine.get_state_info()
    
    def cleanup_inactive_sessions(self, max_sessions: int = 100):
        """
        清理非活跃会话
        
        Args:
            max_sessions: 最大会话数量
        """
        with self._lock:
            if len(self.state_machines) > max_sessions:
                # 保留最近使用的会话
                sessions_by_activity = sorted(
                    self.state_machines.items(),
                    key=lambda x: len(x[1].history),
                    reverse=True
                )
                
                # 保留活跃的会话
                to_keep = sessions_by_activity[:max_sessions]
                self.state_machines = dict(to_keep)


# 全局状态管理器实例
state_manager = StateManager()