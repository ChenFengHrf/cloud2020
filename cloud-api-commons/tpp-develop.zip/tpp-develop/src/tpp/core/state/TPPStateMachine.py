"""
TPP状态机

参考PouchCLI的状态机设计，提供命令执行状态管理和转换功能。
"""

from typing import Dict, List, Optional, Any, Callable
from enum import Enum
from dataclasses import dataclass, field
from datetime import datetime
import json


class TPPState(Enum):
    """TPP状态枚举"""
    IDLE = "idle"
    INITIALIZING = "initializing"
    EXECUTING = "executing"
    COMPLETED = "completed"
    ERROR = "error"
    WAITING_INPUT = "waiting_input"
    PROCESSING = "processing"


@dataclass
class StateTransition:
    """状态转换定义"""
    from_state: TPPState
    to_state: TPPState
    trigger: str
    condition: Optional[Callable[[], bool]] = None
    action: Optional[Callable[[], None]] = None
    description: str = ""


@dataclass
class StateHistory:
    """状态历史记录"""
    timestamp: datetime
    from_state: Optional[TPPState]
    to_state: TPPState
    trigger: str
    context: Optional[Dict[str, Any]] = None
    duration: Optional[float] = None


@dataclass
class ExecutionContext:
    """执行上下文"""
    command: str = ""
    args: Dict[str, Any] = field(default_factory=dict)
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


class TPPStateMachine:
    """
    TPP状态机
    
    管理命令执行的状态转换，提供状态历史记录和上下文管理功能。
    参考PouchCLI的状态机设计模式。
    """
    
    def __init__(self, initial_state: TPPState = TPPState.IDLE):
        self.current_state = initial_state
        self.transitions: Dict[str, StateTransition] = {}
        self.history: List[StateHistory] = []
        self.context = ExecutionContext()
        self.state_data: Dict[str, Any] = {}
        self.listeners: Dict[TPPState, List[Callable]] = {}
        
        # 初始化默认转换
        self._setup_default_transitions()
    
    def _setup_default_transitions(self):
        """设置默认状态转换"""
        default_transitions = [
            # 从空闲状态开始
            StateTransition(
                TPPState.IDLE, TPPState.INITIALIZING, "initialize",
                description="开始初始化"
            ),
            StateTransition(
                TPPState.IDLE, TPPState.EXECUTING, "execute",
                description="直接执行命令"
            ),
            
            # 初始化状态
            StateTransition(
                TPPState.INITIALIZING, TPPState.IDLE, "cancel",
                description="取消初始化"
            ),
            StateTransition(
                TPPState.INITIALIZING, TPPState.EXECUTING, "start_execution",
                description="开始执行"
            ),
            StateTransition(
                TPPState.INITIALIZING, TPPState.ERROR, "initialization_failed",
                description="初始化失败"
            ),
            
            # 执行状态
            StateTransition(
                TPPState.EXECUTING, TPPState.COMPLETED, "complete",
                description="执行完成"
            ),
            StateTransition(
                TPPState.EXECUTING, TPPState.ERROR, "error",
                description="执行出错"
            ),
            StateTransition(
                TPPState.EXECUTING, TPPState.WAITING_INPUT, "wait_input",
                description="等待用户输入"
            ),
            StateTransition(
                TPPState.EXECUTING, TPPState.PROCESSING, "start_processing",
                description="开始处理"
            ),
            
            # 等待输入状态
            StateTransition(
                TPPState.WAITING_INPUT, TPPState.EXECUTING, "input_received",
                description="收到用户输入"
            ),
            StateTransition(
                TPPState.WAITING_INPUT, TPPState.ERROR, "input_timeout",
                description="输入超时"
            ),
            
            # 处理状态
            StateTransition(
                TPPState.PROCESSING, TPPState.COMPLETED, "processing_complete",
                description="处理完成"
            ),
            StateTransition(
                TPPState.PROCESSING, TPPState.ERROR, "processing_error",
                description="处理出错"
            ),
            
            # 通用重置转换
            StateTransition(
                TPPState.COMPLETED, TPPState.IDLE, "reset",
                description="重置到空闲状态"
            ),
            StateTransition(
                TPPState.ERROR, TPPState.IDLE, "reset",
                description="从错误状态重置"
            ),
        ]
        
        for transition in default_transitions:
            self.add_transition(transition)
    
    def add_transition(self, transition: StateTransition):
        """添加状态转换"""
        key = f"{transition.from_state.value}:{transition.trigger}"
        self.transitions[key] = transition
    
    def trigger(self, trigger_name: str, context: Optional[Dict[str, Any]] = None) -> bool:
        """
        触发状态转换
        
        Args:
            trigger_name: 触发器名称
            context: 转换上下文
            
        Returns:
            是否成功转换
        """
        key = f"{self.current_state.value}:{trigger_name}"
        transition = self.transitions.get(key)
        
        if not transition:
            return False
        
        # 检查转换条件
        if transition.condition and not transition.condition():
            return False
        
        # 记录转换开始时间
        start_time = datetime.now()
        old_state = self.current_state
        
        # 执行转换动作
        if transition.action:
            try:
                transition.action()
            except Exception as e:
                # 转换动作失败，记录错误但继续转换
                print(f"Transition action failed: {e}")
        
        # 更新状态
        self.current_state = transition.to_state
        
        # 记录历史
        duration = (datetime.now() - start_time).total_seconds()
        history_entry = StateHistory(
            timestamp=start_time,
            from_state=old_state,
            to_state=self.current_state,
            trigger=trigger_name,
            context=context,
            duration=duration
        )
        self.history.append(history_entry)
        
        # 通知监听器
        self._notify_listeners(self.current_state, context)
        
        return True
    
    def can_trigger(self, trigger_name: str) -> bool:
        """检查是否可以触发指定转换"""
        key = f"{self.current_state.value}:{trigger_name}"
        transition = self.transitions.get(key)
        
        if not transition:
            return False
        
        if transition.condition:
            return transition.condition()
        
        return True
    
    def get_available_transitions(self) -> List[StateTransition]:
        """获取当前状态可用的转换"""
        available = []
        for key, transition in self.transitions.items():
            if transition.from_state == self.current_state:
                if not transition.condition or transition.condition():
                    available.append(transition)
        return available
    
    def get_state_info(self) -> Dict[str, Any]:
        """获取当前状态信息"""
        available_transitions = self.get_available_transitions()
        
        return {
            "current_state": self.current_state.value,
            "available_transitions": [
                {
                    "trigger": t.trigger,
                    "to_state": t.to_state.value,
                    "description": t.description
                }
                for t in available_transitions
            ],
            "context": {
                "command": self.context.command,
                "args": self.context.args,
                "metadata": self.context.metadata
            },
            "state_data": self.state_data,
            "history_count": len(self.history)
        }
    
    def set_context(self, context: ExecutionContext):
        """设置执行上下文"""
        self.context = context
    
    def update_context(self, **kwargs):
        """更新执行上下文"""
        for key, value in kwargs.items():
            if hasattr(self.context, key):
                setattr(self.context, key, value)
            else:
                self.context.metadata[key] = value
    
    def set_state_data(self, key: str, value: Any):
        """设置状态数据"""
        self.state_data[key] = value
    
    def get_state_data(self, key: str, default: Any = None) -> Any:
        """获取状态数据"""
        return self.state_data.get(key, default)
    
    def add_state_listener(self, state: TPPState, callback: Callable):
        """添加状态监听器"""
        if state not in self.listeners:
            self.listeners[state] = []
        self.listeners[state].append(callback)
    
    def _notify_listeners(self, state: TPPState, context: Optional[Dict[str, Any]]):
        """通知状态监听器"""
        if state in self.listeners:
            for callback in self.listeners[state]:
                try:
                    callback(state, context)
                except Exception as e:
                    print(f"State listener error: {e}")
    
    def get_history(self, limit: Optional[int] = None) -> List[StateHistory]:
        """获取状态历史"""
        if limit:
            return self.history[-limit:]
        return self.history.copy()
    
    def reset(self):
        """重置状态机到初始状态"""
        self.trigger("reset")
        self.state_data.clear()
        self.context = ExecutionContext()
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        return {
            "current_state": self.current_state.value,
            "context": {
                "command": self.context.command,
                "args": self.context.args,
                "user_id": self.context.user_id,
                "session_id": self.context.session_id,
                "metadata": self.context.metadata
            },
            "state_data": self.state_data,
            "available_transitions": [
                {
                    "trigger": t.trigger,
                    "to_state": t.to_state.value,
                    "description": t.description
                }
                for t in self.get_available_transitions()
            ],
            "history": [
                {
                    "timestamp": h.timestamp.isoformat(),
                    "from_state": h.from_state.value if h.from_state else None,
                    "to_state": h.to_state.value,
                    "trigger": h.trigger,
                    "duration": h.duration
                }
                for h in self.history[-10:]  # 只返回最近10条历史
            ]
        }
    
    def to_json(self) -> str:
        """转换为JSON格式"""
        return json.dumps(self.to_dict(), indent=2, ensure_ascii=False)