"""
输出格式化器

提供统一的输出格式化功能，支持不同的输出格式和样式。
集成 cli_enhanced 组件以提供一致的视觉体验。
"""

from typing import Any, Optional
import json

from .TPPOutput import TPPOutput, OutputFormat, OutputStatus

# 导入增强的CLI组件
try:
    from ..cli_enhanced import enhanced_cli, create_table, print_success, print_error, print_warning, print_info
    CLI_ENHANCED_AVAILABLE = True
except ImportError:
    # 回退到基础Rich组件
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich.syntax import Syntax
    CLI_ENHANCED_AVAILABLE = False


class OutputFormatter:
    """
    输出格式化器
    
    负责将TPPOutput对象格式化为不同的输出格式，
    特别是为human格式提供丰富的视觉效果。
    现在集成了 cli_enhanced 组件以提供一致的用户体验。
    """
    
    def __init__(self, console: Optional[Any] = None):
        if CLI_ENHANCED_AVAILABLE:
            self.console = enhanced_cli.console
            self.use_enhanced = True
        else:
            from rich.console import Console
            self.console = console or Console()
            self.use_enhanced = False
    
    def format(self, output: 'TPPOutput') -> str:
        """格式化输出为人类可读格式"""
        if self.use_enhanced:
            return self._format_human_enhanced(output)
        else:
            return self._format_human_basic(output)
    

    
    def _format_human_enhanced(self, output: TPPOutput) -> str:
        """使用增强CLI组件格式化输出"""
        # 使用增强的消息函数
        if output.status == OutputStatus.SUCCESS:
            message = f"✅ {output.message or 'Operation completed successfully'}"
        elif output.status == OutputStatus.ERROR:
            message = f"❌ {output.message or 'Operation failed'}"
        elif output.status == OutputStatus.WARNING:
            message = f"⚠️ {output.message or 'Warning occurred'}"
        else:  # INFO
            message = f"ℹ️ {output.message or 'Information'}"
        
        # 捕获输出
        with self.console.capture() as capture:
            self.console.print(f"[bold]{message}[/bold]")
            
            # 显示数据
            if output.data is not None:
                self.console.print("\n[bold cyan]📊 Data:[/bold cyan]")
                if isinstance(output.data, dict) and len(output.data) <= 10:
                    # 使用增强的表格显示
                    columns = [
                        {"name": "Key", "key": "key", "style": "cyan"},
                        {"name": "Value", "key": "value", "style": "white"}
                    ]
                    table_data = [{"key": k, "value": str(v)} for k, v in output.data.items()]
                    table = create_table("Data", columns, table_data)
                    self.console.print(table)
                else:
                    # JSON格式显示
                    from rich.syntax import Syntax
                    json_str = json.dumps(output.data, indent=2, ensure_ascii=False)
                    syntax = Syntax(json_str, "json", theme="monokai", line_numbers=True)
                    self.console.print(syntax)
            
            # 显示PATEOAS导航
            if output.pateoas:
                self.console.print("\n[bold magenta]🔗 Available Actions:[/bold magenta]")
                for link in output.pateoas:
                    title = link.title or link.rel
                    self.console.print(f"[cyan]• {title}:[/cyan] {link.href}")
                    if link.description:
                        self.console.print(f"  [dim]{link.description}[/dim]")
            
            # 显示元数据
            metadata_text = f"⏰ {output.metadata.timestamp}"
            if output.metadata.execution_time:
                metadata_text += f" | ⚡ {output.metadata.execution_time:.3f}s"
            self.console.print(f"\n[dim]{metadata_text}[/dim]")
        
        return capture.get()
    
    def _format_human_basic(self, output: TPPOutput) -> str:
        """基础Rich组件格式化输出（回退方案）"""
        from rich.console import Console
        from rich.panel import Panel
        from rich.text import Text
        
        console = Console(file=None, width=80)
        
        # 状态样式映射
        status_styles = {
            OutputStatus.SUCCESS: ("✅ SUCCESS", "green"),
            OutputStatus.ERROR: ("❌ ERROR", "red"),
            OutputStatus.WARNING: ("⚠️  WARNING", "yellow"),
            OutputStatus.INFO: ("ℹ️  INFO", "blue")
        }
        
        status_text, status_color = status_styles.get(
            output.status, ("• UNKNOWN", "white")
        )
        
        # 创建主面板
        content = []
        
        # 添加消息
        if output.message:
            content.append(Text(output.message, style="bold"))
            content.append("")
        
        # 添加数据
        if output.data is not None:
            content.append(Text("📊 Data:", style="bold cyan"))
            data_content = self._format_data_basic(output.data)
            content.extend(data_content)
            content.append("")
        
        # 添加PATEOAS导航
        if output.pateoas:
            content.append(Text("🔗 Available Actions:", style="bold magenta"))
            for link in output.pateoas:
                title = link.title or link.rel
                action_text = f"• {title}: {link.href}"
                content.append(Text(action_text, style="cyan"))
                if link.description:
                    content.append(Text(f"  {link.description}", style="dim"))
            content.append("")
        
        # 添加元数据
        metadata_text = f"⏰ {output.metadata.timestamp}"
        if output.metadata.execution_time:
            metadata_text += f" | ⚡ {output.metadata.execution_time:.3f}s"
        content.append(Text(metadata_text, style="dim"))
        
        # 创建面板
        panel_content = "\n".join(str(item) for item in content)
        panel = Panel(
            panel_content,
            title=status_text,
            title_align="left",
            border_style=status_color,
            padding=(1, 2)
        )
        
        # 渲染到字符串
        with console.capture() as capture:
            console.print(panel)
        
        return capture.get()
    
    def _format_data_basic(self, data: Any) -> list:
        """格式化数据内容"""
        content = []
        
        if isinstance(data, dict):
            # 创建表格显示字典数据
            if len(data) <= 10:  # 小数据量用表格
                table = Table(show_header=True, header_style="bold blue")
                table.add_column("Key", style="cyan")
                table.add_column("Value", style="white")
                
                for key, value in data.items():
                    table.add_row(str(key), str(value))
                
                with Console(file=None, width=60).capture() as capture:
                    Console(file=None, width=60).print(table)
                content.append(capture.get())
            else:  # 大数据量用JSON格式
                json_str = json.dumps(data, indent=2, ensure_ascii=False)
                syntax = Syntax(json_str, "json", theme="monokai", line_numbers=True)
                with Console(file=None, width=60).capture() as capture:
                    Console(file=None, width=60).print(syntax)
                content.append(capture.get())
                
        elif isinstance(data, list):
            # 列表数据
            if all(isinstance(item, (str, int, float)) for item in data):
                # 简单列表
                for i, item in enumerate(data, 1):
                    content.append(Text(f"  {i}. {item}"))
            else:
                # 复杂列表，使用JSON格式
                json_str = json.dumps(data, indent=2, ensure_ascii=False)
                syntax = Syntax(json_str, "json", theme="monokai", line_numbers=True)
                with Console(file=None, width=60).capture() as capture:
                    Console(file=None, width=60).print(syntax)
                content.append(capture.get())
        else:
            # 其他类型直接显示
            content.append(Text(f"  {data}"))
        
        return content
    
    def format_table(self, data: list, headers: Optional[list] = None) -> str:
        """格式化表格数据"""
        if not data:
            return "No data to display"
        
        if self.use_enhanced:
            # 使用增强的表格组件
            if headers:
                columns = [{"name": str(h), "key": str(h).lower().replace(" ", "_"), "style": "cyan"} for h in headers]
            elif isinstance(data[0], dict):
                columns = [{"name": str(k), "key": str(k), "style": "cyan"} for k in data[0].keys()]
            else:
                columns = [{"name": "Value", "key": "value", "style": "cyan"}]
            
            # 转换数据格式
            if isinstance(data[0], dict):
                table_data = data
            else:
                table_data = [{"value": str(item)} for item in data]
            
            table = create_table("Data Table", columns, table_data)
            with self.console.capture() as capture:
                self.console.print(table)
            return capture.get()
        else:
            # 使用基础Rich表格
            from rich.table import Table
            table = Table(show_header=bool(headers), header_style="bold blue")
            
            # 添加列
            if headers:
                for header in headers:
                    table.add_column(str(header), style="cyan")
            elif isinstance(data[0], dict):
                for key in data[0].keys():
                    table.add_column(str(key), style="cyan")
            else:
                table.add_column("Value", style="cyan")
            
            # 添加行
            for row in data:
                if isinstance(row, dict):
                    table.add_row(*[str(value) for value in row.values()])
                elif isinstance(row, (list, tuple)):
                    table.add_row(*[str(item) for item in row])
                else:
                    table.add_row(str(row))
            
            with self.console.capture() as capture:
                self.console.print(table)
            
            return capture.get()
    
    def format_tree(self, data: dict, title: str = "Data Tree") -> str:
        """格式化树形数据"""
        tree = Tree(title, style="bold blue")
        self._add_tree_nodes(tree, data)
        
        with self.console.capture() as capture:
            self.console.print(tree)
        
        return capture.get()
    
    def _add_tree_nodes(self, parent, data):
        """递归添加树节点"""
        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, (dict, list)):
                    branch = parent.add(f"[cyan]{key}[/cyan]")
                    self._add_tree_nodes(branch, value)
                else:
                    parent.add(f"[cyan]{key}[/cyan]: {value}")
        elif isinstance(data, list):
            for i, item in enumerate(data):
                if isinstance(item, (dict, list)):
                    branch = parent.add(f"[yellow]Item {i+1}[/yellow]")
                    self._add_tree_nodes(branch, item)
                else:
                    parent.add(f"[yellow]Item {i+1}[/yellow]: {item}")
    
    def format_code(self, code: str, language: str = "python") -> str:
        """格式化代码"""
        syntax = Syntax(code, language, theme="monokai", line_numbers=True)
        
        with self.console.capture() as capture:
            self.console.print(syntax)
        
        return capture.get()