"""
TPP统一输出类

参考PouchCLI的输出设计，提供标准化的输出格式和PATEOAS导航支持。
"""

from typing import Any, Dict, List, Optional, Union
from enum import Enum
from dataclasses import dataclass, asdict
from datetime import datetime


class OutputFormat(Enum):
    """输出格式枚举"""
    HUMAN = "human"


class OutputStatus(Enum):
    """输出状态枚举"""
    SUCCESS = "success"
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class PATEOASLink:
    """PATEOAS导航链接"""
    rel: str  # 关系类型
    href: str  # 链接地址
    method: str = "GET"  # HTTP方法
    title: Optional[str] = None  # 链接标题
    description: Optional[str] = None  # 链接描述


@dataclass
class TPPMetadata:
    """输出元数据"""
    timestamp: str
    command: str
    execution_time: Optional[float] = None
    version: str = "0.1.0"
    context: Optional[Dict[str, Any]] = None


class TPPOutput:
    """
    TPP统一输出类
    
    提供标准化的输出格式，支持human、json、xml三种格式，
    并集成PATEOAS导航系统。
    """
    
    def __init__(
        self,
        status: OutputStatus,
        data: Any = None,
        message: Optional[str] = None,
        command: str = "",
        pateoas: Optional[List[PATEOASLink]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ):
        self.status = status
        self.data = data
        self.message = message
        self.command = command
        self.pateoas = pateoas or []
        self.metadata = TPPMetadata(
            timestamp=datetime.now().isoformat(),
            command=command,
            context=metadata
        )
    
    def add_pateoas_link(
        self,
        rel: str,
        href: str,
        method: str = "GET",
        title: Optional[str] = None,
        description: Optional[str] = None
    ) -> None:
        """添加PATEOAS导航链接"""
        link = PATEOASLink(
            rel=rel,
            href=href,
            method=method,
            title=title,
            description=description
        )
        self.pateoas.append(link)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式"""
        result = {
            "status": self.status.value,
            "message": self.message,
            "data": self.data,
            "metadata": asdict(self.metadata),
            "pateoas": [asdict(link) for link in self.pateoas]
        }
        return result
    
    def to_human(self) -> str:
        """转换为人类可读格式"""
        lines = []
        
        # 状态标题
        status_symbols = {
            OutputStatus.SUCCESS: "✅",
            OutputStatus.ERROR: "❌",
            OutputStatus.WARNING: "⚠️",
            OutputStatus.INFO: "ℹ️"
        }
        
        symbol = status_symbols.get(self.status, "•")
        lines.append(f"{symbol} {self.status.value.upper()}")
        
        # 消息
        if self.message:
            lines.append(f"\n{self.message}")
        
        # 数据
        if self.data is not None:
            lines.append("\n📊 Data:")
            if isinstance(self.data, dict):
                for key, value in self.data.items():
                    lines.append(f"  {key}: {value}")
            elif isinstance(self.data, list):
                for i, item in enumerate(self.data):
                    lines.append(f"  {i+1}. {item}")
            else:
                lines.append(f"  {self.data}")
        
        # PATEOAS导航
        if self.pateoas:
            lines.append("\n🔗 Available Actions:")
            for link in self.pateoas:
                title = link.title or link.rel
                lines.append(f"  • {title}: {link.href}")
                if link.description:
                    lines.append(f"    {link.description}")
        
        # 元数据
        lines.append(f"\n⏰ Executed at: {self.metadata.timestamp}")
        if self.metadata.execution_time:
            lines.append(f"⚡ Execution time: {self.metadata.execution_time:.3f}s")
        
        return "\n".join(lines)
    
    @classmethod
    def success(
        cls,
        data: Any = None,
        message: str = "Operation completed successfully",
        command: str = "",
        pateoas: Optional[List[PATEOASLink]] = None
    ) -> "TPPOutput":
        """创建成功输出"""
        return cls(
            status=OutputStatus.SUCCESS,
            data=data,
            message=message,
            command=command,
            pateoas=pateoas
        )
    
    @classmethod
    def error(
        cls,
        message: str,
        data: Any = None,
        command: str = "",
        error_code: Optional[str] = None
    ) -> "TPPOutput":
        """创建错误输出"""
        error_data = {"error_code": error_code} if error_code else None
        if data:
            error_data = {**(error_data or {}), "details": data}
        
        return cls(
            status=OutputStatus.ERROR,
            data=error_data,
            message=message,
            command=command
        )
    
    @classmethod
    def warning(
        cls,
        message: str,
        data: Any = None,
        command: str = "",
        pateoas: Optional[List[PATEOASLink]] = None
    ) -> "TPPOutput":
        """创建警告输出"""
        return cls(
            status=OutputStatus.WARNING,
            data=data,
            message=message,
            command=command,
            pateoas=pateoas
        )
    
    @classmethod
    def info(
        cls,
        message: str,
        data: Any = None,
        command: str = "",
        pateoas: Optional[List[PATEOASLink]] = None
    ) -> "TPPOutput":
        """创建信息输出"""
        return cls(
            status=OutputStatus.INFO,
            data=data,
            message=message,
            command=command,
            pateoas=pateoas
        )