"""
TPP Core CLI Integration
将TPP Core系统集成到主CLI中
"""

import asyncio
from typing import Optional, List
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.json import JSON

from .FlowManager import FlowManager
from src.tpp.core.commands.WelcomeCommand import WelcomeCommand
from src.tpp.core.commands.ActionCommand import ActionCommand
from src.tpp.core.commands.ToolCommand import ToolCommand
from src.tpp.core.commands.RecallCommand import RecallCommand

console = Console()


class TPPCoreCLI:
    """TPP Core CLI集成类"""
    
    def __init__(self):
        self.flow_manager = None
        self._initialized = False
    
    async def initialize(self):
        """初始化TPP Core系统"""
        if self._initialized:
            return
        
        try:
            # 创建FlowManager实例
            self.flow_manager = FlowManager()
            
            # 注册核心命令 - 使用正确的命令名称
            commands = {
                "welcome": WelcomeCommand(),
                "action": ActionCommand(), 
                "tool": ToolCommand(),
                "recall": RecallCommand()
            }
            
            self.flow_manager.register_batch_commands(commands)
            self._initialized = True
            
        except Exception as e:
            console.print(f"[red]❌ TPP Core初始化失败: {e}[/red]")
            raise
    
    async def execute_welcome(self) -> None:
        """执行welcome命令"""
        await self._ensure_initialized()
        
        try:
            result = await self.flow_manager.execute_command("welcome", [])
            self._display_welcome_result(result)
        except Exception as e:
            console.print(f"[red]❌ Welcome命令执行失败: {e}[/red]")
    
    async def execute_action(self, role_id: str) -> None:
        """执行action命令"""
        await self._ensure_initialized()
        
        try:
            result = await self.flow_manager.execute_command("action", [role_id])
            self._display_action_result(result)
        except Exception as e:
            console.print(f"[red]❌ Action命令执行失败: {e}[/red]")
    
    async def execute_tool(self, name: str, target: Optional[str] = None, config: Optional[str] = None, output: Optional[str] = None) -> None:
        """执行tool命令"""
        await self._ensure_initialized()
        
        try:
            args = [name]
            if target:
                args.extend(["--target", target])
            if config:
                args.extend(["--config", config])
            if output:
                args.extend(["--output", output])
            
            result = await self.flow_manager.execute_command("tool", args)
            self._display_tool_result(result)
        except Exception as e:
            console.print(f"[red]❌ Tool命令执行失败: {e}[/red]")
    
    async def execute_recall(self, query: Optional[str] = None, limit: int = 10, category: Optional[str] = None) -> None:
        """执行recall命令"""
        await self._ensure_initialized()
        
        try:
            args = []
            if query:
                args.append(query)
            if limit != 10:
                args.append(str(limit))
            if category:
                args.append(category)
            
            result = await self.flow_manager.execute_command("recall", args)
            self._display_recall_result(result)
        except Exception as e:
            console.print(f"[red]❌ Recall命令执行失败: {e}[/red]")
    
    async def _ensure_initialized(self):
        """确保系统已初始化"""
        if not self._initialized:
            await self.initialize()
    
    def _display_welcome_result(self, result: dict):
        """显示welcome命令结果"""
        # 获取内容，支持两种结构：直接的content或嵌套的content
        content = result.get("content", result)
        
        if content.get("status") == "success":
            # 显示欢迎信息
            console.print(Panel.fit(
                f"[bold blue]🎉 {content.get('message', 'Welcome to TPP!')}[/bold blue]\n\n"
                f"[white]可用角色: {content.get('total_roles', 0)} 个[/white]\n"
                f"[white]可用工具: {content.get('total_tools', 0)} 个[/white]",
                title="TPP Core System",
                border_style="blue"
            ))
            
            # 显示可用角色
            if content.get("available_roles"):
                roles_table = Table(title="可用AI角色", show_header=True, header_style="bold green")
                roles_table.add_column("ID", style="cyan")
                roles_table.add_column("名称", style="white")
                roles_table.add_column("描述", style="dim")
                roles_table.add_column("分类", style="yellow")
                
                for role in content["available_roles"]:
                    roles_table.add_row(
                        role["id"],
                        role["name"],
                        role["description"],
                        role["category"]
                    )
                
                console.print(roles_table)
            
            # 显示可用工具
            if content.get("available_tools"):
                tools_table = Table(title="可用开发工具", show_header=True, header_style="bold green")
                tools_table.add_column("名称", style="cyan")
                tools_table.add_column("描述", style="white")
                tools_table.add_column("分类", style="yellow")
                
                for tool in content["available_tools"]:
                    tools_table.add_row(
                        tool["name"],
                        tool["description"],
                        tool["category"]
                    )
                
                console.print(tools_table)
        else:
            console.print(f"[red]❌ {content.get('message', 'Unknown error')}[/red]")
    
    def _display_action_result(self, result: dict):
        """显示action命令结果"""
        # 获取内容，支持两种结构：直接的content或嵌套的content
        content = result.get("content", result)
        
        if content.get("status") == "success":
            activated_role = content.get("activated_role", {})
            
            console.print(Panel.fit(
                f"[bold green]✅ {content.get('message')}[/bold green]\n\n"
                f"[white]角色ID: {activated_role.get('id')}[/white]\n"
                f"[white]角色名称: {activated_role.get('name')}[/white]\n"
                f"[white]描述: {activated_role.get('description')}[/white]\n"
                f"[white]个性: {activated_role.get('personality')}[/white]",
                title="角色激活成功",
                border_style="green"
            ))
            
            # 显示能力列表
            if activated_role.get("capabilities"):
                console.print("\n[bold yellow]专业能力:[/bold yellow]")
                for capability in activated_role["capabilities"]:
                    console.print(f"  • {capability}")
            
            # 显示工作原则
            if activated_role.get("principles"):
                console.print("\n[bold yellow]工作原则:[/bold yellow]")
                for principle in activated_role["principles"]:
                    console.print(f"  • {principle}")
        else:
            console.print(f"[red]❌ {content.get('message', 'Unknown error')}[/red]")
    
    def _display_tool_result(self, result: dict):
        """显示tool命令结果"""
        # 获取内容，支持两种结构：直接的content或嵌套的content
        content = result.get("content", result)
        
        if content.get("status") == "success":
            tool_info = content.get("tool_info", {})
            execution_result = content.get("execution_result", {})
            
            console.print(Panel.fit(
                f"[bold green]✅ {content.get('message')}[/bold green]\n\n"
                f"[white]工具名称: {tool_info.get('name')}[/white]\n"
                f"[white]工具描述: {tool_info.get('description')}[/white]\n"
                f"[white]工具分类: {tool_info.get('category')}[/white]",
                title="工具执行完成",
                border_style="green"
            ))
            
            # 显示执行结果
            if execution_result:
                console.print("\n[bold yellow]执行结果:[/bold yellow]")
                console.print(JSON.from_data(execution_result))
        else:
            console.print(f"[red]❌ {content.get('message', 'Unknown error')}[/red]")
    
    def _display_recall_result(self, result: dict):
        """显示recall命令结果"""
        # 获取内容，支持两种结构：直接的content或嵌套的content
        content = result.get("content", result)
        
        if content.get("status") == "success":
            memories = content.get("memories", [])
            
            console.print(Panel.fit(
                f"[bold green]✅ {content.get('message')}[/bold green]\n\n"
                f"[white]查询关键词: {content.get('query', 'N/A')}[/white]\n"
                f"[white]分类过滤: {content.get('category', 'N/A')}[/white]\n"
                f"[white]结果限制: {content.get('limit')}[/white]",
                title="记忆检索完成",
                border_style="green"
            ))
            
            # 显示记忆列表
            if memories:
                memories_table = Table(title="检索到的记忆", show_header=True, header_style="bold green")
                memories_table.add_column("类型", style="cyan")
                memories_table.add_column("标题", style="white")
                memories_table.add_column("分类", style="yellow")
                memories_table.add_column("相关性", style="green")
                
                for memory in memories:
                    memories_table.add_row(
                        memory.get("type", ""),
                        memory.get("title", ""),
                        memory.get("category", ""),
                        f"{memory.get('relevance', 0):.2f}"
                    )
                
                console.print(memories_table)
                
                # 显示详细内容
                console.print("\n[bold yellow]记忆详情:[/bold yellow]")
                for i, memory in enumerate(memories[:3]):  # 只显示前3条详情
                    console.print(f"\n[cyan]{i+1}. {memory.get('title')}[/cyan]")
                    console.print(f"   {memory.get('content', '')}")
                    if memory.get('tags'):
                        console.print(f"   标签: {', '.join(memory['tags'])}")
            else:
                console.print("\n[yellow]未找到相关记忆[/yellow]")
        else:
            console.print(f"[red]❌ {content.get('message', 'Unknown error')}[/red]")


# 创建全局实例
tpp_core_cli = TPPCoreCLI()