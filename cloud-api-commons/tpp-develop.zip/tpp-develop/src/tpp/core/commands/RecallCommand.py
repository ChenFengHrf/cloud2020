from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from ..CommandManager import BaseCommand


class RecallCommand(BaseCommand):
    """
    回忆命令
    检索开发记忆和项目历史
    """
    
    def __init__(self):
        super().__init__()
    
    async def execute(self, args: List[str] = None) -> Dict[str, Any]:
        """
        执行回忆命令
        
        Args:
            args: 命令参数，第一个参数为查询关键词
            
        Returns:
            执行结果
        """
        if args is None:
            args = []
        
        query = args[0] if len(args) > 0 else None
        limit = int(args[1]) if len(args) > 1 and args[1].isdigit() else 10
        category = args[2] if len(args) > 2 else None
        
        # 搜索记忆
        memories = self._search_memories(query, limit, category)
        
        result = {
            "status": "success",
            "message": f"找到 {len(memories)} 条相关记忆",
            "query": query,
            "category": category,
            "limit": limit,
            "memories": memories,
            "search_time": datetime.now().isoformat()
        }
        
        return {
            "content": result,
            "pateoas": self.get_pateoas(args)
        }
    
    def _search_memories(self, query: Optional[str], limit: int, category: Optional[str]) -> List[Dict[str, Any]]:
        """
        搜索记忆数据
        
        Args:
            query: 查询关键词
            limit: 结果限制
            category: 分类过滤
            
        Returns:
            记忆列表
        """
        # 模拟记忆数据
        all_memories = [
            {
                "id": "mem_001",
                "type": "code_solution",
                "category": "bug_fix",
                "title": "修复异步函数调用问题",
                "content": "在FlowManager中添加await关键字解决异步调用问题",
                "tags": ["async", "await", "FlowManager"],
                "created_at": (datetime.now() - timedelta(days=1)).isoformat(),
                "relevance": 0.95
            },
            {
                "id": "mem_002", 
                "type": "design_decision",
                "category": "architecture",
                "title": "采用PATEOAS设计模式",
                "content": "为命令系统实现PATEOAS导航，提供状态转换指导",
                "tags": ["PATEOAS", "REST", "navigation"],
                "created_at": (datetime.now() - timedelta(days=2)).isoformat(),
                "relevance": 0.88
            },
            {
                "id": "mem_003",
                "type": "code_pattern",
                "category": "implementation",
                "title": "命令注册批处理模式",
                "content": "实现批量命令注册，支持列表和字典两种格式",
                "tags": ["command", "registration", "batch"],
                "created_at": (datetime.now() - timedelta(days=3)).isoformat(),
                "relevance": 0.82
            },
            {
                "id": "mem_004",
                "type": "testing_insight",
                "category": "testing",
                "title": "测试脚本参数类型检查",
                "content": "在测试中发现list和dict类型混用问题，需要类型检查",
                "tags": ["testing", "type_check", "debugging"],
                "created_at": (datetime.now() - timedelta(days=4)).isoformat(),
                "relevance": 0.75
            },
            {
                "id": "mem_005",
                "type": "performance_tip",
                "category": "optimization",
                "title": "状态机性能优化",
                "content": "使用字典查找替代线性搜索，提升状态转换性能",
                "tags": ["performance", "state_machine", "optimization"],
                "created_at": (datetime.now() - timedelta(days=5)).isoformat(),
                "relevance": 0.70
            }
        ]
        
        # 过滤记忆
        filtered_memories = []
        
        for memory in all_memories:
            # 分类过滤
            if category and memory["category"] != category:
                continue
            
            # 查询过滤
            if query:
                query_lower = query.lower()
                if not any([
                    query_lower in memory["title"].lower(),
                    query_lower in memory["content"].lower(),
                    any(query_lower in tag.lower() for tag in memory["tags"])
                ]):
                    continue
            
            filtered_memories.append(memory)
        
        # 按相关性排序并限制结果
        filtered_memories.sort(key=lambda x: x["relevance"], reverse=True)
        return filtered_memories[:limit]
    
    def get_purpose(self) -> str:
        """获取命令用途"""
        return "检索开发记忆和项目历史"
    
    def get_content(self) -> str:
        """获取命令内容"""
        return "搜索代码解决方案、设计决策、测试洞察等开发记忆"
    
    def get_pateoas(self, args: List[str] = None) -> Dict[str, Any]:
        """获取PATEOAS导航信息"""
        return {
            "current_state": "memory_recalled",
            "available_transitions": ["recall", "remember", "action", "welcome"],
            "next_actions": [
                {
                    "name": "继续搜索",
                    "command": "recall",
                    "args": ["new_query"],
                    "description": "使用新关键词搜索记忆"
                },
                {
                    "name": "记录新记忆",
                    "command": "remember",
                    "args": ["content"],
                    "description": "保存新的开发记忆"
                },
                {
                    "name": "激活专家",
                    "command": "action",
                    "args": ["role_id"],
                    "description": "激活专家角色获得专业分析"
                },
                {
                    "name": "返回主页",
                    "command": "welcome",
                    "description": "返回系统主页"
                }
            ]
        }