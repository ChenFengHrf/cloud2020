from typing import List, Dict, Any, Optional
import asyncio
import os
from ..CommandManager import BaseCommand
from ..UnifiedOutput import UnifiedOutput as TPPOutput, OutputStatus, PATEOASLink, unified_output
from ..resource.resource_manager import ResourceManager


class AgentCommand(BaseCommand):
    """
    AI代理命令 - 增强版
    管理和激活AI代理，支持角色资源查询、记忆操作和action功能
    参考PromptX ActionCommand.js实现
    """
    
    def __init__(self, output_formatter=None, session_id: str = None, silent_mode: bool = False):
        super().__init__(output_formatter, session_id, silent_mode)
        self.name = "agent"
        self.category = "ai"
        self.version = "2.0.0"
        self.resource_manager = None
        self._initialized = False
    
    def execute(self, *args) -> TPPOutput:
        """
        执行代理命令
        
        Args:
            *args: 命令参数 (action, role_id, ...)
            
        Returns:
            TPPOutput: 执行结果
        """
        # 确保资源管理器已初始化
        if not self._initialized:
            self._ensure_initialized()
        
        if not args:
            return self._show_help()
        
        action = args[0].lower()
        
        if action == "list":
            # 支持按类型过滤：agent list roles
            filter_type = args[1] if len(args) > 1 else None
            return self._list_agents(filter_type)
        elif action == "activate" or action == "action":
            role_id = args[1] if len(args) > 1 else None
            if not role_id:
                return self.error("请指定要激活的角色ID", {"error_code": "MISSING_ROLE_ID"})
            return self._activate_agent_with_resources(role_id)
        elif action == "status":
            return self._show_status()
        elif action == "info":
            role_id = args[1] if len(args) > 1 else None
            if not role_id:
                return self.error("请指定要查询的角色ID", {"error_code": "MISSING_ROLE_ID"})
            return self._get_role_info(role_id)
        elif action == "recall":
            role_id = args[1] if len(args) > 1 else None
            query = args[2] if len(args) > 2 else None
            return self._recall_memories(role_id, query)
        elif action == "remember":
            role_id = args[1] if len(args) > 1 else None
            content = " ".join(args[2:]) if len(args) > 2 else None
            if not role_id or not content:
                return self.error("请指定角色ID和要记忆的内容", {"error_code": "MISSING_PARAMETERS"})
            return self._remember_content(role_id, content)
        else:
            return self.error(f"未知的代理动作: {action}", {"error_code": "UNKNOWN_ACTION"})
    
    def _ensure_initialized(self):
        """确保资源管理器已初始化"""
        if not self.resource_manager:
            try:
                # 获取项目根目录
                current_dir = os.getcwd()
                self.resource_manager = ResourceManager(current_dir)
                # 同步初始化，避免异步问题
                try:
                    loop = asyncio.get_event_loop()
                    if loop.is_running():
                        # 如果事件循环正在运行，创建新的任务
                        import concurrent.futures
                        with concurrent.futures.ThreadPoolExecutor() as executor:
                            future = executor.submit(asyncio.run, self.resource_manager.initialize())
                            future.result(timeout=5)  # 5秒超时
                    else:
                        asyncio.run(self.resource_manager.initialize())
                except Exception:
                    # 如果异步初始化失败，尝试同步初始化
                    pass
                self._initialized = True
            except Exception as e:
                self.resource_manager = None
                self._initialized = False
                if not self.silent_mode:
                    print(f"Warning: 无法初始化资源管理器: {e}")

    def _show_help(self) -> TPPOutput:
        """显示帮助信息"""
        help_text = """
AI代理命令使用说明 (增强版):

基本用法:
  tpp agent <action> [options]

可用动作:
  list [roles]            列出所有可用的AI代理或角色资源
  activate <role_id>      激活指定的AI代理角色
  action <role_id>        激活角色并执行action (同activate)
  info <role_id>          查询指定角色的详细信息
  status                  显示当前代理状态
  recall <role_id> [query] 检索指定角色的记忆
  remember <role_id> <content> 为指定角色添加记忆

示例:
  tpp agent list                    # 列出所有代理
  tpp agent list roles              # 列出所有角色资源
  tpp agent activate mcp-developer  # 激活MCP开发者角色
  tpp agent info mcp-developer      # 查看角色详细信息
  tpp agent recall mcp-developer    # 检索角色记忆
  tpp agent remember mcp-developer "项目配置已更新"  # 添加记忆
  tpp agent status                  # 查看状态
        """
        
        return self.success(help_text, {
            "command": "agent",
            "version": "2.0.0",
            "available_actions": ["list", "activate", "action", "info", "status", "recall", "remember"]
        })
    
    def _list_agents(self, filter_type: Optional[str] = None) -> TPPOutput:
        """列出所有可用的AI代理或角色资源"""
        try:
            if filter_type == "roles" and self.resource_manager:
                # 查询角色资源
                role_resources = self.resource_manager.list_resources(resource_type="role")
                
                agents = []
                for resource in role_resources:
                    agents.append({
                        "id": resource.get("id"),
                        "name": resource.get("id"),
                        "type": "role_resource",
                        "reference": resource.get("reference"),
                        "description": f"角色资源: {resource.get('id')}",
                        "status": "available",
                        "source": "resource_manager"
                    })
                
                return self.success(agents, f"找到 {len(agents)} 个角色资源")
            else:
                # 默认列出所有代理（包括内置和资源）
                agents = []
                
                # 内置代理
                builtin_agents = [
                    {
                        "id": "developer",
                        "name": "开发专家",
                        "type": "builtin",
                        "description": "全栈开发专家，精通多种编程语言",
                        "capabilities": ["代码开发", "架构设计", "代码审查", "性能优化"],
                        "status": "available"
                    },
                    {
                        "id": "python-expert", 
                        "name": "Python专家",
                        "type": "builtin",
                        "description": "Python编程语言专家",
                        "capabilities": ["Python开发", "框架设计", "性能优化", "代码审查"],
                        "status": "available"
                    },
                    {
                        "id": "architect",
                        "name": "系统架构师",
                        "type": "builtin",
                        "description": "系统架构设计专家",
                        "capabilities": ["系统设计", "架构规划", "技术选型", "性能优化"],
                        "status": "available"
                    },
                    {
                        "id": "tester",
                        "name": "测试专家",
                        "type": "builtin", 
                        "description": "软件测试和质量保证专家",
                        "capabilities": ["测试设计", "自动化测试", "性能测试", "质量保证"],
                        "status": "available"
                    }
                ]
                agents.extend(builtin_agents)
                
                # 添加角色资源
                if self.resource_manager:
                    role_resources = self.resource_manager.list_resources(resource_type="role")
                    for resource in role_resources:
                        agents.append({
                            "id": resource.get("id"),
                            "name": resource.get("id"),
                            "type": "role_resource",
                            "reference": resource.get("reference"),
                            "description": f"角色资源: {resource.get('id')}",
                            "status": "available",
                            "source": "resource_manager"
                        })
                
                pateoas = [
                    self.add_pateoas_link("self", "/agent/list", "GET", "代理列表", "查看所有可用代理"),
                    self.add_pateoas_link("activate", "/agent/activate/{role}", "POST", "激活代理", "激活指定代理角色"),
                    self.add_pateoas_link("back", "/agent", "GET", "返回", "返回代理管理主页")
                ]
                
                return self.success({"agents": agents}, "可用AI代理列表", pateoas)
                
        except Exception as e:
            return self.error(f"列出代理时出错: {str(e)}", {"error_code": "LIST_AGENTS_ERROR"})
    
    def _activate_agent_with_resources(self, role_id: str) -> TPPOutput:
        """激活指定的AI代理（增强版，支持资源查询）"""
        try:
            # 首先尝试从资源管理器获取角色信息
            role_info = None
            if self.resource_manager:
                try:
                    role_resources = self.resource_manager.list_resources(resource_type="role")
                    role_info = next((r for r in role_resources if r.get("id") == role_id), None)
                except Exception as e:
                    if not self.silent_mode:
                        print(f"Warning: 无法查询角色资源: {e}")
            
            # 构建激活数据
            activation_data = {
                "role_id": role_id,
                "status": "activated",
                "timestamp": "2024-01-01T00:00:00Z",
                "session_id": self.session_id or "default",
                "source": "resource_manager" if role_info else "builtin"
            }
            
            if role_info:
                activation_data.update({
                    "reference": role_info.get("reference"),
                    "type": "role_resource",
                    "capabilities": ["resource_based_activation", "memory_support", "action_support"]
                })
                
                # 尝试加载角色依赖
                dependencies = self._analyze_role_dependencies(role_id)
                if dependencies:
                    activation_data["dependencies"] = dependencies
                    activation_data["learning_plan"] = self._generate_learning_plan(dependencies)
            else:
                # 内置角色
                activation_data.update({
                    "type": "builtin",
                    "capabilities": ["basic_activation"]
                })
            
            return self.success(activation_data, f"成功激活代理: {role_id}")
            
        except Exception as e:
            return self.error(f"激活代理时出错: {str(e)}", {"error_code": "ACTIVATION_ERROR", "role_id": role_id})

    def _get_role_info(self, role_id: str) -> TPPOutput:
        """查询指定角色的详细信息"""
        try:
            if not self.resource_manager:
                return self.error("资源管理器未初始化", {"error_code": "RESOURCE_MANAGER_NOT_INITIALIZED"})
            
            # 查询角色资源
            role_resources = self.resource_manager.list_resources(resource_type="role")
            role_info = next((r for r in role_resources if r.get("id") == role_id), None)
            
            if not role_info:
                return self.error(f"未找到角色: {role_id}", {"error_code": "ROLE_NOT_FOUND", "role_id": role_id})
            
            # 分析角色依赖
            dependencies = self._analyze_role_dependencies(role_id)
            
            detailed_info = {
                "id": role_info.get("id"),
                "reference": role_info.get("reference"),
                "type": "role_resource",
                "dependencies": dependencies,
                "capabilities": ["memory_support", "action_support", "dependency_analysis"],
                "status": "available"
            }
            
            return self.success(detailed_info, f"角色信息: {role_id}")
            
        except Exception as e:
            return self.error(f"查询角色信息时出错: {str(e)}", {"error_code": "ROLE_INFO_ERROR", "role_id": role_id})

    def _recall_memories(self, role_id: Optional[str], query: Optional[str]) -> TPPOutput:
        """检索指定角色的记忆"""
        try:
            # 这里应该集成MCP PromptX的recall功能
            # 目前返回模拟数据
            memories = [
                {
                    "id": "mem_001",
                    "role_id": role_id,
                    "content": f"角色 {role_id} 的记忆内容示例",
                    "timestamp": "2024-01-01T00:00:00Z",
                    "tags": ["example", "memory"],
                    "relevance": 0.95
                }
            ]
            
            if query:
                # 过滤相关记忆
                filtered_memories = [m for m in memories if query.lower() in m["content"].lower()]
                memories = filtered_memories
            
            return self.success(memories, f"检索到 {len(memories)} 条记忆")
            
        except Exception as e:
            return self.error(f"检索记忆时出错: {str(e)}", {"error_code": "RECALL_ERROR", "role_id": role_id})

    def _remember_content(self, role_id: str, content: str) -> TPPOutput:
        """为指定角色添加记忆"""
        try:
            # 这里应该集成MCP PromptX的remember功能
            # 目前返回模拟数据
            memory_data = {
                "id": f"mem_{hash(content) % 10000:04d}",
                "role_id": role_id,
                "content": content,
                "timestamp": "2024-01-01T00:00:00Z",
                "tags": ["user_input"],
                "status": "saved"
            }
            
            return self.success(memory_data, f"已为角色 {role_id} 添加记忆")
            
        except Exception as e:
            return self.error(f"添加记忆时出错: {str(e)}", {"error_code": "REMEMBER_ERROR", "role_id": role_id})

    def _analyze_role_dependencies(self, role_id: str) -> Dict[str, List[str]]:
        """分析角色依赖（参考ActionCommand.js）"""
        try:
            if not self.resource_manager:
                return {}
            
            dependencies = {
                "thoughts": [],
                "executions": [],
                "knowledge": [],
                "manuals": [],
                "tools": []
            }
            
            # 查询相关资源
            for dep_type in ["thought", "execution", "knowledge", "manual", "tool"]:
                resources = self.resource_manager.list_resources(resource_type=dep_type)
                # 简单的关联逻辑：名称包含role_id的资源
                related = [r.get("id") for r in resources if role_id in r.get("id", "")]
                if dep_type == "thought":
                    dependencies["thoughts"] = related
                elif dep_type == "execution":
                    dependencies["executions"] = related
                elif dep_type == "knowledge":
                    dependencies["knowledge"] = related
                elif dep_type == "manual":
                    dependencies["manuals"] = related
                elif dep_type == "tool":
                    dependencies["tools"] = related
            
            return dependencies
            
        except Exception as e:
            if not self.silent_mode:
                print(f"Warning: 分析角色依赖时出错: {e}")
            return {}

    def _generate_learning_plan(self, dependencies: Dict[str, List[str]]) -> List[str]:
        """生成学习计划（参考ActionCommand.js）"""
        plan = []
        
        # 按优先级生成学习计划
        if dependencies.get("thoughts"):
            plan.extend([f"@thought://{t}" for t in dependencies["thoughts"]])
        
        if dependencies.get("executions"):
            plan.extend([f"@execution://{e}" for e in dependencies["executions"]])
        
        if dependencies.get("knowledge"):
            plan.extend([f"@knowledge://{k}" for k in dependencies["knowledge"]])
        
        if dependencies.get("manuals"):
            plan.extend([f"@manual://{m}" for m in dependencies["manuals"]])
        
        return plan

    def _activate_agent(self, role: str) -> TPPOutput:
        """激活指定的AI代理（兼容旧版本）"""
        return self._activate_agent_with_resources(role)
    
    def _show_status(self) -> TPPOutput:
        """显示代理状态"""
        status_data = {
            "current_agent": None,
            "session_id": self.session_id,
            "uptime": "0 minutes",
            "total_agents": 4,
            "available_agents": 4
        }
        
        pateoas = [
            self.add_pateoas_link("self", "/agent/status", "GET", "代理状态", "当前代理状态"),
            self.add_pateoas_link("list", "/agent/list", "GET", "代理列表", "查看所有可用代理"),
            self.add_pateoas_link("back", "/agent", "GET", "返回", "返回代理管理主页")
        ]
        
        return self.success(status_data, "AI代理状态信息", pateoas)
    
    def get_purpose(self) -> str:
        """获取命令用途"""
        return "管理和激活AI代理"
    
    def get_content(self) -> str:
        """获取命令内容"""
        return "提供AI代理的激活、列表查看和状态管理功能"
    
    def get_pateoas(self, args: List[str] = None) -> Dict[str, Any]:
        """获取PATEOAS导航信息"""
        return {
            "current_state": "agent_management",
            "available_transitions": ["list", "activate", "status"],
            "next_actions": [
                {
                    "name": "列出代理",
                    "command": "agent",
                    "args": ["list"],
                    "description": "查看所有可用的AI代理"
                },
                {
                    "name": "激活代理",
                    "command": "agent", 
                    "args": ["activate", "<role>"],
                    "description": "激活指定的AI代理角色"
                },
                {
                    "name": "查看状态",
                    "command": "agent",
                    "args": ["status"], 
                    "description": "查看当前代理状态"
                }
            ]
        }