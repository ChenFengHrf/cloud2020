


"""
基础命令类

所有命令的基类，定义了命令的基本接口和行为。
集成了新的输出系统和状态管理功能。
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
import time
import json

from .UnifiedOutput import UnifiedOutput, unified_output, OutputFormat, OutputStatus, PATEOASLink
from .state.StateManager import state_manager


class BaseCommand(ABC):
    """
    基础命令抽象类
    
    所有TPP命令都应该继承这个类并实现必要的方法。
    集成了统一的输出系统和状态管理功能。
    """
    
    def __init__(self, output_formatter=None, session_id: str = None, silent_mode: bool = False):
        self.context: Dict[str, Any] = {}
        self.start_time: Optional[float] = None
        self.end_time: Optional[float] = None
        self.output_formatter = output_formatter or unified_output
        self.session_id: str = session_id
        self.silent_mode: bool = silent_mode  # MCP模式下的静默执行
    
    @abstractmethod
    def execute(self, *args, **kwargs) -> UnifiedOutput:
        """
        执行命令
        
        Args:
            *args: 位置参数
            **kwargs: 关键字参数
            
        Returns:
            UnifiedOutput对象
        """
        pass
    
    @abstractmethod
    def get_purpose(self) -> str:
        """
        获取命令的用途描述
        
        Returns:
            命令用途的字符串描述
        """
        pass
    
    @abstractmethod
    def get_content(self) -> str:
        """
        获取命令的详细内容
        
        Returns:
            命令详细内容的字符串描述
        """
        pass
    
    @abstractmethod
    def get_pateoas(self) -> List[PATEOASLink]:
        """
        获取PATEOAS导航信息
        
        Returns:
            PATEOASLink对象列表
        """
        pass
    
    def get_metadata(self) -> Dict[str, Any]:
        """
        获取命令元数据
        
        Returns:
            命令元数据字典
        """
        return {
            "purpose": self.get_purpose(),
            "content": self.get_content(),
            "execution_time": self.get_execution_time(),
            "context": self.context
        }
    
    def set_context(self, context: Dict[str, Any]):
        """
        设置命令执行上下文
        
        Args:
            context: 上下文字典
        """
        self.context = context
        self.session_id = context.get("session_id")
        self.silent_mode = context.get("silent_mode", False)
    
    def get_context(self) -> Dict[str, Any]:
        """
        获取命令执行上下文
        
        Returns:
            上下文字典
        """
        return self.context
    
    def start_timing(self):
        """开始计时"""
        self.start_time = time.time()
    
    def end_timing(self):
        """结束计时"""
        self.end_time = time.time()
    
    def get_execution_time(self) -> Optional[float]:
        """
        获取执行时间
        
        Returns:
            执行时间（秒），如果未完成计时则返回None
        """
        if self.start_time and self.end_time:
            return self.end_time - self.start_time
        return None
    
    def create_output(
        self,
        status: OutputStatus,
        data: Any = None,
        message: Optional[str] = None,
        pateoas: Optional[List[PATEOASLink]] = None
    ) -> UnifiedOutput:
        """
        创建标准化输出
        
        Args:
            status: 输出状态
            data: 输出数据
            message: 输出消息
            pateoas: PATEOAS导航链接
            
        Returns:
            UnifiedOutput对象
        """
        if pateoas is None:
            pateoas = self.get_pateoas()
        
        output = UnifiedOutput(
            status=status,
            data=data,
            message=message,
            command=self.__class__.__name__,
            pateoas=pateoas,
            metadata=self.context
        )
        
        # 设置执行时间
        if self.get_execution_time():
            output.metadata.execution_time = self.get_execution_time()
        
        return output
    
    def success(
        self,
        data: Any = None,
        message: str = "Operation completed successfully",
        pateoas: Optional[List[PATEOASLink]] = None
    ) -> UnifiedOutput:
        """创建成功输出"""
        return self.create_output(OutputStatus.SUCCESS, data, message, pateoas)
    
    def error(
        self,
        message: str,
        data: Any = None,
        error_code: Optional[str] = None
    ) -> UnifiedOutput:
        """创建错误输出"""
        error_data = {"error_code": error_code} if error_code else None
        if data:
            error_data = {**(error_data or {}), "details": data}
        
        return self.create_output(OutputStatus.ERROR, error_data, message)
    
    def warning(
        self,
        message: str,
        data: Any = None,
        pateoas: Optional[List[PATEOASLink]] = None
    ) -> UnifiedOutput:
        """创建警告输出"""
        return self.create_output(OutputStatus.WARNING, data, message, pateoas)
    

    
    def info(
        self,
        message: str,
        data: Any = None,
        pateoas: Optional[List[PATEOASLink]] = None
    ) -> UnifiedOutput:
        """创建信息输出"""
        return self.create_output(OutputStatus.INFO, data, message, pateoas)
    
    def format_output(self, output: UnifiedOutput, format_type: str = "human") -> str:
        """
        格式化输出
        
        Args:
            output: UnifiedOutput对象
            format_type: 输出格式类型
            
        Returns:
            格式化后的字符串
        """
        if format_type == "human":
            return output.to_human()
        elif format_type == "json":
            return json.dumps(output.to_dict(), indent=2, ensure_ascii=False)
        else:
            return str(output.to_dict())
    
    def execute_with_state_management(self, *args, **kwargs) -> UnifiedOutput:
        """
        带状态管理的命令执行
        
        Args:
            *args: 位置参数
            **kwargs: 关键字参数
            
        Returns:
            UnifiedOutput对象
        """
        # 获取状态机
        state_machine = state_manager.get_state_machine(self.session_id)
        
        try:
            # 开始执行
            self.start_timing()
            state_machine.trigger("execute", {
                "command": self.__class__.__name__,
                "args": args,
                "kwargs": kwargs
            })
            
            # 执行命令
            result = self.execute(*args, **kwargs)
            
            # 结束计时
            self.end_timing()
            
            # 完成执行
            state_machine.trigger("complete", {"result": result})
            
            return result
            
        except Exception as e:
            # 错误处理
            self.end_timing()
            state_machine.trigger("error", {"error": str(e)})
            
            return self.error(
                message=f"Command execution failed: {str(e)}",
                error_code="EXECUTION_ERROR"
            )
    
    def get_state_info(self) -> Dict[str, Any]:
        """获取当前状态信息"""
        state_machine = state_manager.get_state_machine(self.session_id)
        return state_machine.get_state_info()
    
    def add_pateoas_link(
        self,
        rel: str,
        href: str,
        method: str = "GET",
        title: Optional[str] = None,
        description: Optional[str] = None
    ) -> PATEOASLink:
        """
        创建PATEOAS链接
        
        Args:
            rel: 关系类型
            href: 链接地址
            method: HTTP方法
            title: 链接标题
            description: 链接描述
            
        Returns:
            PATEOASLink对象
        """
        return PATEOASLink(
            rel=rel,
            href=href,
            method=method,
            title=title,
            description=description
        )
