"""
Enhanced CLI Output Tools

提供现代化、美观的CLI输出工具，包括进度条、加载动画、表格、面板等。
"""

import time
from typing import Optional, List, Dict, Any, Union
from contextlib import contextmanager
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn, TimeElapsedColumn, TimeRemainingColumn
from rich.status import Status
from rich.tree import Tree
from rich.columns import Columns
from rich.align import Align
from rich.layout import Layout
from rich.live import Live
from rich.spinner import Spinner
from rich.prompt import Prompt, Confirm
from rich.syntax import Syntax
from rich.markdown import Markdown
from rich.rule import Rule
from rich.box import ROUNDED, DOUBLE, SIMPLE, HEAVY
import typer


class EnhancedCLI:
    """增强的CLI输出工具类"""
    
    def __init__(self):
        self.console = Console()
        self.current_status = None
        
    def print_banner(self, title: str, subtitle: str = "", style: str = "bold blue"):
        """显示应用横幅"""
        banner_text = Text()
        banner_text.append("🚀 ", style="bold yellow")
        banner_text.append(title, style=style)
        if subtitle:
            banner_text.append(f"\n   {subtitle}", style="dim")
            
        panel = Panel(
            Align.center(banner_text),
            box=DOUBLE,
            border_style="blue",
            padding=(1, 2)
        )
        self.console.print(panel)
        self.console.print()

    def print_success(self, message: str, details: str = ""):
        """显示成功消息"""
        text = Text()
        text.append("✅ ", style="bold green")
        text.append(message, style="green")
        if details:
            text.append(f"\n   {details}", style="dim green")
        self.console.print(text)

    def print_error(self, message: str, details: str = ""):
        """显示错误消息"""
        text = Text()
        text.append("❌ ", style="bold red")
        text.append(message, style="red")
        if details:
            text.append(f"\n   {details}", style="dim red")
        self.console.print(text)

    def print_warning(self, message: str, details: str = ""):
        """显示警告消息"""
        text = Text()
        text.append("⚠️  ", style="bold yellow")
        text.append(message, style="yellow")
        if details:
            text.append(f"\n   {details}", style="dim yellow")
        self.console.print(text)

    def print_info(self, message: str, details: str = ""):
        """显示信息消息"""
        text = Text()
        text.append("ℹ️  ", style="bold blue")
        text.append(message, style="blue")
        if details:
            text.append(f"\n   {details}", style="dim blue")
        self.console.print(text)

    def create_table(self, title: str, columns: List[Dict[str, str]], data: List[Dict[str, Any]], 
                    show_lines: bool = True, box_style = ROUNDED) -> Table:
        """创建美观的表格"""
        table = Table(
            title=title,
            show_header=True,
            header_style="bold magenta",
            show_lines=show_lines,
            box=box_style,
            title_style="bold blue"
        )
        
        # 添加列
        for col in columns:
            table.add_column(
                col["name"], 
                style=col.get("style", ""),
                justify=col.get("justify", "left"),
                width=col.get("width")
            )
        
        # 添加数据行
        for row in data:
            values = []
            for col in columns:
                key = col["key"]
                value = str(row.get(key, ""))
                
                # 特殊格式化
                if col.get("format") == "status":
                    if value.lower() in ["active", "success", "available"]:
                        value = f"[green]{value}[/green]"
                    elif value.lower() in ["inactive", "error", "unavailable"]:
                        value = f"[red]{value}[/red]"
                    elif value.lower() in ["pending", "warning"]:
                        value = f"[yellow]{value}[/yellow]"
                
                values.append(value)
            
            table.add_row(*values)
        
        return table

    def print_tree(self, title: str, tree_data: Dict[str, Any]):
        """显示树形结构"""
        tree = Tree(f"📁 {title}", style="bold blue")
        
        def add_nodes(parent, data):
            if isinstance(data, dict):
                for key, value in data.items():
                    if isinstance(value, (dict, list)):
                        branch = parent.add(f"📂 {key}", style="yellow")
                        add_nodes(branch, value)
                    else:
                        parent.add(f"📄 {key}: {value}", style="green")
            elif isinstance(data, list):
                for i, item in enumerate(data):
                    if isinstance(item, (dict, list)):
                        branch = parent.add(f"📂 [{i}]", style="yellow")
                        add_nodes(branch, item)
                    else:
                        parent.add(f"📄 [{i}]: {item}", style="green")
        
        add_nodes(tree, tree_data)
        self.console.print(tree)

    @contextmanager
    def status(self, message: str, spinner: str = "dots"):
        """显示状态加载动画"""
        with self.console.status(f"[bold blue]{message}...", spinner=spinner) as status:
            self.current_status = status
            yield status
            self.current_status = None

    @contextmanager
    def progress(self, description: str = "Processing"):
        """显示进度条"""
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            TimeElapsedColumn(),
            TimeRemainingColumn(),
            console=self.console
        ) as progress:
            yield progress

    def print_code(self, code: str, language: str = "python", theme: str = "monokai", 
                  line_numbers: bool = True):
        """显示语法高亮的代码"""
        syntax = Syntax(code, language, theme=theme, line_numbers=line_numbers)
        self.console.print(syntax)

    def print_markdown(self, markdown_text: str):
        """显示Markdown格式文本"""
        md = Markdown(markdown_text)
        self.console.print(md)

    def print_rule(self, title: str = "", style: str = "blue"):
        """显示分隔线"""
        rule = Rule(title, style=style)
        self.console.print(rule)

    def print_columns(self, items: List[str], equal: bool = True):
        """显示多列布局"""
        columns = Columns(items, equal=equal, expand=True)
        self.console.print(columns)

    def confirm(self, message: str, default: bool = False) -> bool:
        """显示确认对话框"""
        return Confirm.ask(f"[yellow]{message}[/yellow]", default=default)

    def prompt(self, message: str, default: str = "", password: bool = False) -> str:
        """显示输入提示"""
        return Prompt.ask(f"[cyan]{message}[/cyan]", default=default, password=password)

    def print_stats_panel(self, stats: Dict[str, Any], title: str = "Statistics"):
        """显示统计信息面板"""
        stats_text = ""
        for key, value in stats.items():
            if isinstance(value, float) and 0 < value < 1:
                # 百分比格式
                stats_text += f"[cyan]{key}:[/cyan] [green]{value:.1%}[/green]\n"
            elif isinstance(value, (int, float)):
                # 数字格式
                stats_text += f"[cyan]{key}:[/cyan] [yellow]{value:,}[/yellow]\n"
            else:
                # 字符串格式
                stats_text += f"[cyan]{key}:[/cyan] [white]{value}[/white]\n"
        
        panel = Panel(
            stats_text.rstrip(),
            title=f"📊 {title}",
            border_style="green",
            box=ROUNDED
        )
        self.console.print(panel)

    def print_help_panel(self, commands: List[Dict[str, str]], title: str = "Available Commands"):
        """显示帮助面板"""
        help_text = ""
        for cmd in commands:
            name = cmd.get("name", "")
            desc = cmd.get("description", "")
            usage = cmd.get("usage", "")
            
            help_text += f"[bold cyan]{name}[/bold cyan]\n"
            help_text += f"  {desc}\n"
            if usage:
                help_text += f"  [dim]Usage: {usage}[/dim]\n"
            help_text += "\n"
        
        panel = Panel(
            help_text.rstrip(),
            title=f"❓ {title}",
            border_style="blue",
            box=ROUNDED
        )
        self.console.print(panel)

    def create_unified_panel(self, title: str, sections: List[Dict[str, Any]], 
                           border_style: str = "blue", emoji: str = "📋") -> Panel:
        """创建统一的Panel，包含多个部分的信息"""
        content_parts = []
        
        for section in sections:
            section_type = section.get("type", "text")
            section_title = section.get("title", "")
            section_data = section.get("data", "")
            
            if section_title:
                content_parts.append(f"[bold yellow]📌 {section_title}[/bold yellow]")
            
            if section_type == "table":
                # 表格数据转换为文本格式
                columns = section.get("columns", [])
                data = section.get("data", [])
                
                if columns and data:
                    # 创建表格头
                    headers = [col.get("name", col.get("key", "")) for col in columns]
                    content_parts.append(f"[dim]{'  '.join(headers)}[/dim]")
                    content_parts.append("[dim]" + "─" * 60 + "[/dim]")
                    
                    # 添加数据行（最多显示5行，避免Panel过长）
                    for i, row in enumerate(data[:5]):
                        row_values = []
                        for col in columns:
                            key = col["key"]
                            value = str(row.get(key, ""))
                            style = col.get("style", "white")
                            row_values.append(f"[{style}]{value}[/{style}]")
                        content_parts.append("  ".join(row_values))
                    
                    if len(data) > 5:
                        content_parts.append(f"[dim]... 还有 {len(data) - 5} 项[/dim]")
            
            elif section_type == "stats":
                # 统计信息
                stats = section_data
                if isinstance(stats, dict):
                    for key, value in stats.items():
                        if isinstance(value, float) and 0 < value < 1:
                            content_parts.append(f"[cyan]{key}:[/cyan] [green]{value:.1%}[/green]")
                        elif isinstance(value, (int, float)):
                            content_parts.append(f"[cyan]{key}:[/cyan] [yellow]{value:,}[/yellow]")
                        else:
                            content_parts.append(f"[cyan]{key}:[/cyan] [white]{value}[/white]")
            
            elif section_type == "commands":
                # 命令列表
                commands = section_data
                if isinstance(commands, list):
                    for cmd in commands:
                        name = cmd.get("name", "")
                        desc = cmd.get("description", "")
                        usage = cmd.get("usage", "")
                        
                        content_parts.append(f"[bold cyan]{name}[/bold cyan]")
                        content_parts.append(f"  {desc}")
                        if usage:
                            content_parts.append(f"  [dim]Usage: {usage}[/dim]")
            
            elif section_type == "text":
                # 纯文本
                content_parts.append(str(section_data))
            
            elif section_type == "success":
                # 成功消息
                content_parts.append(f"[green]✅ {section_data}[/green]")
            
            elif section_type == "warning":
                # 警告消息
                content_parts.append(f"[yellow]⚠️ {section_data}[/yellow]")
            
            elif section_type == "info":
                # 信息消息
                content_parts.append(f"[blue]ℹ️ {section_data}[/blue]")
            
            elif section_type == "banner":
                # 横幅消息
                content_parts.append(f"[bold bright_blue]🎉 {section_data}[/bold bright_blue]")
            
            # 添加分隔符（除了最后一个section）
            if section != sections[-1]:
                content_parts.append("")
        
        panel_content = "\n".join(content_parts)
        
        return Panel(
            panel_content,
            title=f"{emoji} {title}",
            border_style=border_style,
            box=ROUNDED,
            padding=(1, 2)
        )

    def simulate_loading(self, duration: float = 2.0, message: str = "Loading"):
        """模拟加载过程"""
        with self.progress() as progress:
            task = progress.add_task(f"[cyan]{message}...", total=100)
            
            for i in range(100):
                time.sleep(duration / 100)
                progress.update(task, advance=1)


# 全局实例
enhanced_cli = EnhancedCLI()


# 便捷函数
def print_banner(title: str, subtitle: str = "", style: str = "bold blue"):
    enhanced_cli.print_banner(title, subtitle, style)

def print_success(message: str, details: str = ""):
    enhanced_cli.print_success(message, details)

def print_error(message: str, details: str = ""):
    enhanced_cli.print_error(message, details)

def print_warning(message: str, details: str = ""):
    enhanced_cli.print_warning(message, details)

def print_info(message: str, details: str = ""):
    enhanced_cli.print_info(message, details)

def create_table(title: str, columns: List[Dict[str, str]], data: List[Dict[str, Any]]) -> Table:
    return enhanced_cli.create_table(title, columns, data)

def status(message: str, spinner: str = "dots"):
    return enhanced_cli.status(message, spinner)

def progress(description: str = "Processing"):
    return enhanced_cli.progress(description)

def confirm(message: str, default: bool = False) -> bool:
    return enhanced_cli.confirm(message, default)

def prompt(message: str, default: str = "", password: bool = False) -> str:
    return enhanced_cli.prompt(message, default, password)

def create_unified_panel(title: str, sections: List[Dict[str, Any]], 
                        border_style: str = "blue", emoji: str = "📋") -> Panel:
    return enhanced_cli.create_unified_panel(title, sections, border_style, emoji)