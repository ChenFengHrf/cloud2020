



import asyncio
from typing import Dict, List, Any, Optional
from .FlowStateMachine import FlowStateMachine
from .CommandManager import PouchRegistry
from .FlowCLI import FlowCLI


class FlowManager:
    """
    流程管理器
    负责协调状态机、注册中心和CLI的整体工作
    """
    
    def __init__(self):
        self.state_machine = FlowStateMachine()
        self.registry = PouchRegistry()
        self.cli = FlowCLI()
        # 确保CLI使用同一个registry和state_machine实例
        self.cli.registry = self.registry
        self.cli.state_machine = self.state_machine
        self.initialized = False
    
    async def initialize(self):
        """初始化流程管理器"""
        if self.initialized:
            return
        
        # 初始化CLI（会自动初始化状态机和注册中心）
        await self.cli.initialize()
        
        # 标记为已初始化
        self.initialized = True
    
    async def execute_command(self, command_name: str, args: List[str] = None, silent: bool = False) -> Any:
        """
        执行命令
        
        Args:
            command_name: 命令名称
            args: 命令参数
            silent: 静默模式
            
        Returns:
            执行结果
        """
        if not self.initialized:
            await self.initialize()
        
        return await self.cli.execute(command_name, args, silent)
    
    def get_current_state(self) -> str:
        """获取当前状态"""
        return self.state_machine.get_current_state()
    
    def get_available_commands(self) -> List[str]:
        """获取可用命令列表"""
        return self.registry.list()
    
    def get_available_transitions(self) -> List[str]:
        """获取可用状态转换"""
        return self.state_machine.get_available_transitions()
    
    def get_status(self) -> Dict[str, Any]:
        """获取完整状态信息"""
        return self.cli.get_status()
    
    def register_command(self, name: str, command_class):
        """
        注册新命令
        
        Args:
            name: 命令名称
            command_class: 命令类
        """
        self.registry.register(name, command_class)
        
        # 同时注册到状态机
        command_instance = self.registry.get(name)
        self.state_machine.register_command(name, command_instance)
    
    def register_batch_commands(self, commands):
        """
        批量注册命令
        
        Args:
            commands: 命令列表或命令映射字典
        """
        if isinstance(commands, list):
            # 如果是列表，转换为字典
            command_map = {}
            for cmd in commands:
                # 从类名推导命令名称
                cmd_name = cmd.__class__.__name__.lower().replace('command', '')
                command_map[cmd_name] = cmd
        else:
            # 如果已经是字典，直接使用
            command_map = commands
            
        self.registry.register_batch(command_map)
        
        # 同时注册到状态机
        for name in command_map.keys():
            command_instance = self.registry.get(name)
            self.state_machine.register_command(name, command_instance)
    
    async def run_interactive(self):
        """运行交互式CLI"""
        if not self.initialized:
            await self.initialize()
        
        await self.cli.run_interactive()
    
    async def reset(self):
        """重置流程管理器"""
        self.state_machine.reset()
        self.registry.clear()
        self.initialized = False
    
    def get_help(self) -> str:
        """获取帮助信息"""
        return self.cli.get_help()
    
    def validate_command(self, command_name: str) -> bool:
        """
        验证命令是否存在
        
        Args:
            command_name: 命令名称
            
        Returns:
            是否存在
        """
        return self.registry.validate(command_name)
    
    def get_command_details(self, command_name: str = None) -> List[Dict[str, str]]:
        """获取命令的详细信息"""
        if command_name:
            # 获取单个命令的详细信息
            if self.registry.validate(command_name):
                command = self.registry.get(command_name)
                return [{
                    'name': command_name,
                    'purpose': command.get_purpose(),
                    'content': command.get_content()
                }]
            else:
                return []
        else:
            # 获取所有命令的详细信息
            return self.registry.get_command_details()
