"""
命令管理器

负责管理和执行各种命令。
支持批量注册、命令发现、验证和元数据管理。
集成新的输出系统和状态管理。
"""

from typing import Dict, List, Any, Optional, Type, Set, Callable
import importlib
import inspect
import asyncio
from pathlib import Path
from dataclasses import dataclass
from datetime import datetime

from .BaseCommand import BaseCommand
from .UnifiedOutput import UnifiedOutput, OutputStatus, unified_output
from .state.StateManager import state_manager


@dataclass
class CommandMetadata:
    """命令元数据"""
    name: str
    class_name: str
    module_path: str
    purpose: str
    content: str
    category: str = "general"
    version: str = "1.0.0"
    author: str = "TPP Team"
    dependencies: List[str] = None
    async_support: bool = False
    state_aware: bool = False
    mcp_compatible: bool = True
    last_updated: datetime = None
    
    def __post_init__(self):
        if self.dependencies is None:
            self.dependencies = []
        if self.last_updated is None:
            self.last_updated = datetime.now()


class CommandRegistry:
    """命令注册表"""
    
    def __init__(self):
        self.commands: Dict[str, Type[BaseCommand]] = {}
        self.metadata: Dict[str, CommandMetadata] = {}
        self.categories: Dict[str, Set[str]] = {}
        self.validators: List[Callable[[str, Type[BaseCommand]], bool]] = []
    
    def register(self, name: str, command_class: Type[BaseCommand], metadata: CommandMetadata = None):
        """注册单个命令"""
        # 验证命令类
        if not self._validate_command(name, command_class):
            raise ValueError(f"Command validation failed for {name}")
        
        self.commands[name] = command_class
        
        # 生成或使用提供的元数据
        if metadata is None:
            metadata = self._generate_metadata(name, command_class)
        
        self.metadata[name] = metadata
        
        # 更新分类
        category = metadata.category
        if category not in self.categories:
            self.categories[category] = set()
        self.categories[category].add(name)
    
    def batch_register(self, commands: Dict[str, Type[BaseCommand]]):
        """批量注册命令"""
        for name, command_class in commands.items():
            try:
                self.register(name, command_class)
            except Exception as e:
                print(f"Failed to register command {name}: {e}")
    
    def unregister(self, name: str):
        """注销命令"""
        if name in self.commands:
            metadata = self.metadata.get(name)
            if metadata and metadata.category in self.categories:
                self.categories[metadata.category].discard(name)
                if not self.categories[metadata.category]:
                    del self.categories[metadata.category]
            
            del self.commands[name]
            if name in self.metadata:
                del self.metadata[name]
    
    def get_command_class(self, name: str) -> Optional[Type[BaseCommand]]:
        """获取命令类"""
        return self.commands.get(name)
    
    def get_metadata(self, name: str) -> Optional[CommandMetadata]:
        """获取命令元数据"""
        return self.metadata.get(name)
    
    def list_commands(self, category: str = None) -> List[str]:
        """列出命令"""
        if category:
            return list(self.categories.get(category, set()))
        return list(self.commands.keys())
    
    def list_categories(self) -> List[str]:
        """列出所有分类"""
        return list(self.categories.keys())
    
    def add_validator(self, validator: Callable[[str, Type[BaseCommand]], bool]):
        """添加命令验证器"""
        self.validators.append(validator)
    
    def _validate_command(self, name: str, command_class: Type[BaseCommand]) -> bool:
        """验证命令类"""
        # 基本验证
        if not issubclass(command_class, BaseCommand):
            return False
        
        # 检查必需方法
        required_methods = ['execute', 'get_purpose', 'get_content', 'get_pateoas']
        for method in required_methods:
            if not hasattr(command_class, method):
                return False
        
        # 运行自定义验证器
        for validator in self.validators:
            if not validator(name, command_class):
                return False
        
        return True
    
    def _generate_metadata(self, name: str, command_class: Type[BaseCommand]) -> CommandMetadata:
        """生成命令元数据"""
        # 尝试创建实例获取信息
        try:
            instance = command_class()
            purpose = instance.get_purpose()
            content = instance.get_content()
        except Exception:
            purpose = "Unknown purpose"
            content = "Unknown content"
        
        # 检查异步支持
        async_support = asyncio.iscoroutinefunction(command_class.execute)
        
        # 检查状态感知
        state_aware = hasattr(command_class, 'session_id') or 'state' in inspect.signature(command_class.__init__).parameters
        
        return CommandMetadata(
            name=name,
            class_name=command_class.__name__,
            module_path=command_class.__module__,
            purpose=purpose,
            content=content,
            async_support=async_support,
            state_aware=state_aware
        )


class CommandManager:
    """
    增强的命令管理器
    
    提供命令注册、发现、执行和管理功能。
    集成状态管理和输出系统。
    """
    
    def __init__(self):
        self.registry = CommandRegistry()
        self.command_instances: Dict[str, BaseCommand] = {}
        self.execution_stats: Dict[str, Dict[str, Any]] = {}
        self._setup_default_validators()
        self._auto_discover_commands()
    
    def _setup_default_validators(self):
        """设置默认验证器"""
        def validate_base_command(name: str, command_class: Type[BaseCommand]) -> bool:
            """验证是否继承自BaseCommand"""
            return issubclass(command_class, BaseCommand)
        
        def validate_naming_convention(name: str, command_class: Type[BaseCommand]) -> bool:
            """验证命名约定"""
            return name.isalnum() and name.islower()
        
        self.registry.add_validator(validate_base_command)
        self.registry.add_validator(validate_naming_convention)
    
    def _auto_discover_commands(self):
        """自动发现命令"""
        commands_dir = Path(__file__).parent / "commands"
        if not commands_dir.exists():
            return
        
        discovered_commands = {}
        
        for file_path in commands_dir.glob("*.py"):
            if file_path.name.startswith("__"):
                continue
            
            module_name = file_path.stem
            try:
                # 动态导入命令模块
                module = importlib.import_module(f".commands.{module_name}", package=__package__)
                
                # 查找命令类
                for attr_name in dir(module):
                    attr = getattr(module, attr_name)
                    if (isinstance(attr, type) and 
                        issubclass(attr, BaseCommand) and 
                        attr != BaseCommand):
                        
                        command_name = module_name.lower().replace("command", "")
                        discovered_commands[command_name] = attr
                        break
                        
            except ImportError as e:
                print(f"Failed to discover command {module_name}: {e}")
        
        # 批量注册发现的命令
        if discovered_commands:
            self.registry.batch_register(discovered_commands)
        
        # 移除自动注册的多余命令
        # 只保留核心命令：welcome, tool, recall, agent
        core_commands = ['welcome', 'tool', 'recall', 'agent']
        commands_to_remove = []
        
        for name in discovered_commands.keys():
            if name not in core_commands:
                commands_to_remove.append(name)
        
        # 从注册表中移除多余的命令
        for name in commands_to_remove:
            if name in self.registry.commands:
                del self.registry.commands[name]
            if name in self.registry.metadata:
                del self.registry.metadata[name]
            # 从分类中移除
            for category, command_set in self.registry.categories.items():
                if name in command_set:
                    command_set.remove(name)
    
    def register_command(self, name: str, command_class: Type[BaseCommand], metadata: CommandMetadata = None):
        """注册命令"""
        self.registry.register(name, command_class, metadata)
    
    def batch_register_commands(self, commands: Dict[str, Type[BaseCommand]]):
        """批量注册命令"""
        self.registry.batch_register(commands)
    
    def get_command_instance(self, name: str, session_id: str = None, silent_mode: bool = False) -> Optional[BaseCommand]:
        """获取命令实例"""
        command_class = self.registry.get_command_class(name)
        if not command_class:
            return None
        
        # 为每个会话创建独立的命令实例
        instance_key = f"{name}_{session_id or 'default'}"
        
        if instance_key not in self.command_instances:
            try:
                # 尝试创建命令实例，优雅地处理参数
                import inspect
                sig = inspect.signature(command_class.__init__)
                params = list(sig.parameters.keys())
                
                # 构建参数字典
                kwargs = {}
                if 'session_id' in params:
                    kwargs['session_id'] = session_id
                if 'silent_mode' in params:
                    kwargs['silent_mode'] = silent_mode
                if 'output_formatter' in params:
                    kwargs['output_formatter'] = unified_output
                
                instance = command_class(**kwargs)
                self.command_instances[instance_key] = instance
            except Exception as e:
                print(f"Failed to create command instance {name}: {e}")
                return None
        
        return self.command_instances[instance_key]
    
    async def execute_command(self, name: str, args: List[str] = None, 
                            session_id: str = None, context: Dict[str, Any] = None,
                            silent_mode: bool = False) -> UnifiedOutput:
        """执行命令"""
        # 获取命令实例
        command = self.get_command_instance(name, session_id, silent_mode)
        if not command:
            return UnifiedOutput(
                status=OutputStatus.ERROR,
                message=f"Command '{name}' not found",
                data={"error_code": "COMMAND_NOT_FOUND", "available_commands": self.registry.list_commands()}
            )
        
        # 设置上下文
        if context:
            command.set_context(context)
        
        # 记录执行统计
        self._record_execution_start(name)
        
        try:
            # 使用状态管理执行命令
            if hasattr(command, 'execute_with_state_management'):
                result = command.execute_with_state_management(*args if args else [])
            else:
                # 兼容旧的执行方式
                if asyncio.iscoroutinefunction(command.execute):
                    result = await command.execute(*args if args else [])
                else:
                    result = command.execute(*args if args else [])
            
            self._record_execution_success(name)
            return result
            
        except Exception as e:
            self._record_execution_error(name, str(e))
            return UnifiedOutput(
                status=OutputStatus.ERROR,
                message=f"Command execution failed: {str(e)}",
                data={"error_code": "COMMAND_EXECUTION_ERROR"}
            )
    
    def list_commands(self, category: str = None) -> List[Dict[str, Any]]:
        """列出所有可用命令"""
        commands_info = []
        command_names = self.registry.list_commands(category)
        
        for name in command_names:
            metadata = self.registry.get_metadata(name)
            stats = self.execution_stats.get(name, {})
            
            commands_info.append({
                "name": name,
                "purpose": metadata.purpose if metadata else "Unknown",
                "content": metadata.content if metadata else "Unknown",
                "category": metadata.category if metadata else "general",
                "version": metadata.version if metadata else "1.0.0",
                "async_support": metadata.async_support if metadata else False,
                "state_aware": metadata.state_aware if metadata else False,
                "execution_count": stats.get("count", 0),
                "success_rate": stats.get("success_rate", 0.0),
                "last_executed": stats.get("last_executed")
            })
        
        return commands_info
    
    def get_command_help(self, name: str, session_id: str = None) -> Optional[UnifiedOutput]:
        """获取命令帮助信息"""
        command = self.get_command_instance(name, session_id)
        metadata = self.registry.get_metadata(name)
        
        if not command or not metadata:
            return UnifiedOutput(
                status=OutputStatus.ERROR,
                message=f"Command '{name}' not found",
                data={"error_code": "COMMAND_NOT_FOUND"}
            )
        
        help_data = {
            "name": name,
            "purpose": metadata.purpose,
            "content": metadata.content,
            "category": metadata.category,
            "version": metadata.version,
            "author": metadata.author,
            "dependencies": metadata.dependencies,
            "async_support": metadata.async_support,
            "state_aware": metadata.state_aware,
            "mcp_compatible": metadata.mcp_compatible,
            "pateoas": command.get_pateoas() if hasattr(command, 'get_pateoas') else []
        }
        
        return UnifiedOutput(
            status=OutputStatus.SUCCESS,
            message=f"Help information for command '{name}'",
            data=help_data
        )
    
    def get_execution_stats(self) -> Dict[str, Any]:
        """获取执行统计信息"""
        total_executions = sum(stats.get("count", 0) for stats in self.execution_stats.values())
        total_errors = sum(stats.get("errors", 0) for stats in self.execution_stats.values())
        
        return {
            "total_commands": len(self.registry.commands),
            "total_executions": total_executions,
            "total_errors": total_errors,
            "overall_success_rate": (total_executions - total_errors) / total_executions if total_executions > 0 else 0.0,
            "command_stats": self.execution_stats,
            "categories": {cat: len(commands) for cat, commands in self.registry.categories.items()}
        }
    
    def _record_execution_start(self, command_name: str):
        """记录命令执行开始"""
        if command_name not in self.execution_stats:
            self.execution_stats[command_name] = {
                "count": 0,
                "errors": 0,
                "success_rate": 0.0,
                "last_executed": None
            }
        
        self.execution_stats[command_name]["count"] += 1
        self.execution_stats[command_name]["last_executed"] = datetime.now().isoformat()
    
    def _record_execution_success(self, command_name: str):
        """记录命令执行成功"""
        stats = self.execution_stats[command_name]
        stats["success_rate"] = (stats["count"] - stats["errors"]) / stats["count"]
    
    def _record_execution_error(self, command_name: str, error: str):
        """记录命令执行错误"""
        stats = self.execution_stats[command_name]
        stats["errors"] += 1
        stats["success_rate"] = (stats["count"] - stats["errors"]) / stats["count"]


# 全局命令管理器实例
command_manager = CommandManager()
