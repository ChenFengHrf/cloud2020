#!/usr/bin/env python3
"""
TPP CLI 资源管理功能演示脚本

演示通过主CLI接口使用资源管理功能
"""

import subprocess
import sys
import time
from pathlib import Path

def run_command(cmd: str, description: str = ""):
    """运行CLI命令并显示结果"""
    print(f"\n{'='*60}")
    print(f"🔧 {description}")
    print(f"命令: {cmd}")
    print(f"{'='*60}")
    
    try:
        result = subprocess.run(
            cmd.split(),
            capture_output=True,
            text=True,
            cwd=Path(__file__).parent
        )
        
        if result.stdout:
            print("📤 输出:")
            print(result.stdout)
        
        if result.stderr:
            print("⚠️ 错误:")
            print(result.stderr)
            
        print(f"✅ 退出码: {result.returncode}")
        
    except Exception as e:
        print(f"❌ 执行失败: {e}")
    
    time.sleep(1)  # 短暂暂停以便阅读

def main():
    """主演示函数"""
    print("🎯 TPP CLI 资源管理功能演示")
    print("=" * 60)
    
    # 1. 显示CLI帮助
    run_command(
        "uv run src/tpp/cli.py --help",
        "显示CLI主帮助信息"
    )
    
    # 2. 显示资源管理命令帮助
    run_command(
        "uv run src/tpp/cli.py resource --help",
        "显示资源管理命令帮助"
    )
    
    # 3. 查看资源统计
    run_command(
        "uv run src/tpp/cli.py resource stats",
        "查看资源管理器统计信息"
    )
    
    # 4. 列出所有资源
    run_command(
        "uv run src/tpp/cli.py resource list",
        "列出所有可用资源"
    )
    
    # 5. 按类型列出资源
    run_command(
        "uv run src/tpp/cli.py resource list --type role",
        "列出角色类型资源"
    )
    
    # 6. 刷新资源
    run_command(
        "uv run src/tpp/cli.py resource refresh",
        "刷新资源发现"
    )
    
    # 7. 注册新资源
    run_command(
        "uv run src/tpp/cli.py resource register demo-role --type role --ref 'role://demo'",
        "注册演示角色资源"
    )
    
    # 8. 查看资源信息
    run_command(
        "uv run src/tpp/cli.py resource info demo-role",
        "查看演示角色资源信息"
    )
    
    # 9. JSON格式输出
    run_command(
        "uv run src/tpp/cli.py resource stats --format json",
        "JSON格式显示资源统计"
    )
    
    # 10. 显示欢迎信息（包含资源管理命令）
    run_command(
        "uv run src/tpp/cli.py welcome",
        "显示包含资源管理的欢迎信息"
    )
    
    print("\n🎉 演示完成！")
    print("=" * 60)
    print("✅ TPP CLI 资源管理功能已成功集成")
    print("📋 支持的功能:")
    print("   • 资源统计和列表")
    print("   • 资源注册和查询")
    print("   • 多种输出格式")
    print("   • 类型过滤")
    print("   • 资源刷新")
    print("   • 完整的CLI集成")

if __name__ == "__main__":
    main()