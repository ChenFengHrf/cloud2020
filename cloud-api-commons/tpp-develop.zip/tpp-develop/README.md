# TPP Develop - MCP Server for Python Development

[![Python Version](https://img.shields.io/badge/python-3.8%2B-blue.svg)](https://python.org)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Tests](https://img.shields.io/badge/tests-passing-brightgreen.svg)](tests/)
[![Code Style](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

TPP Develop 是一个基于 Model Context Protocol (MCP) 的 Python 开发工具服务器，提供代码生成、测试生成和代码分析等功能，帮助开发者提高开发效率。

## ✨ 特性

- 🚀 **代码生成**: 自动生成 Python 组件模板（服务、模型、控制器、工具等）
- 🧪 **测试生成**: 智能生成单元测试、集成测试、端到端测试和性能测试
- 📊 **代码分析**: 全面的代码质量分析，包括复杂度、可维护性、技术债务等指标
- ⚙️ **配置管理**: 灵活的配置系统，支持自定义模板和规则
- 🔌 **MCP 协议**: 基于标准 MCP 协议，易于集成到各种开发环境
- 📦 **开箱即用**: 提供完整的安装、开发、测试和部署脚本

## 📋 系统要求

- Python 3.8 或更高版本
- pip 包管理器
- Git（用于版本控制）

## 🚀 快速开始

### 1. 克隆项目

```bash
git clone https://github.com/yourusername/tpp-develop.git
cd tpp-develop
```

### 2. 安装

使用提供的安装脚本：

```bash
# 基础安装
./scripts/install.sh

# 开发环境安装（包含开发和测试依赖）
./scripts/install.sh --dev

# 运行测试
./scripts/install.sh --run-tests
```

### 3. 配置

安装后会自动创建默认配置文件 `config/config.json`，你可以根据需要进行修改：

```json
{
  "server": {
    "name": "tpp-develop",
    "version": "1.0.0",
    "description": "TPP Develop MCP Server"
  },
  "tools": {
    "code_generator": {
      "enabled": true,
      "templates_dir": "templates"
    },
    "test_generator": {
      "enabled": true,
      "test_framework": "pytest"
    },
    "code_analyzer": {
      "enabled": true,
      "max_complexity": 10
    }
  }
}
```

### 4. 运行服务器

```bash
# 直接运行
python -m tpp_develop.server

# 或使用开发脚本
./scripts/dev.sh run

# 调试模式
./scripts/dev.sh run --debug
```

## 🛠️ 开发工具

项目提供了完整的开发工具链：

### 代码质量

```bash
# 代码格式化
./scripts/dev.sh format

# 导入排序
./scripts/dev.sh isort

# 类型检查
./scripts/dev.sh typecheck

# 代码检查
./scripts/dev.sh lint

# 运行所有检查
./scripts/dev.sh check
```

### 测试

```bash
# 运行所有测试
./scripts/dev.sh test

# 运行特定测试文件
./scripts/dev.sh test tests/test_server.py

# 生成覆盖率报告
./scripts/dev.sh test --cov
```

### 构建和清理

```bash
# 构建包
./scripts/dev.sh build

# 清理构建产物
./scripts/dev.sh clean

# 显示项目状态
./scripts/dev.sh status
```

## 📦 使用方法

### CLI 接口

TPP 提供了全面的命令行接口，支持多种运行方式：

#### 1. 控制台脚本（推荐）
安装后，直接使用 `tpp` 命令：
```bash
# 显示欢迎信息和系统状态
tpp welcome

# 激活 AI 代理角色
tpp agent python-expert

# 执行开发工具
tpp tool create_component --name MyComponent --type react --description "A sample React component"
tpp tool generate_tests --file src/example.py --type python
tpp tool analyze_code --file src/example.py --analysis-type quality

# 搜索记忆
tpp recall "python best practices" --limit 10 --category development

# 启动 MCP 服务器
tpp mcp-server --protocol sse --host localhost --port 8000

# 显示帮助
tpp --help
```

#### 2. UV Run（开发环境）
用于开发或未安装时：
```bash
# 使用 uv run 和控制台脚本
uv run tpp welcome
uv run tpp agent python-expert

# 直接文件执行
uv run src/tpp/cli.py welcome
uv run src/tpp/cli.py agent python-expert
```

#### 3. 模块执行
作为 Python 模块运行：
```bash
python -m src.tpp.cli welcome
python -m src.tpp.cli agent python-expert
```

#### 可用命令

- **`welcome`** - 显示欢迎信息、可用 AI 角色和开发工具
- **`agent <role_id>`** - 激活 AI 代理角色（如 python-expert、data-scientist）
- **`tool <tool_name>`** - 执行开发工具：
  - `create_component` - 生成代码组件（React、Vue、Python 等）
  - `generate_tests` - 为代码创建测试文件
  - `analyze_code` - 执行代码质量分析
- **`recall <query>`** - 搜索开发记忆和知识
- **`mcp-server`** - 使用 stdio 或 sse 协议启动 MCP 服务器
- **`--help`** - 显示帮助信息

### MCP 服务器

#### 启动 MCP 服务器

```bash
# SSE 协议（推荐用于测试）
tpp mcp-server --protocol sse --host localhost --port 8000

# stdio 协议（用于 Claude Desktop 集成）
tpp mcp-server --protocol stdio
```

### MCP 工具

TPP Develop 提供以下 MCP 工具：

#### 1. 代码生成 (create_component)

```json
{
  "name": "create_component",
  "arguments": {
    "component_type": "service",
    "name": "UserService",
    "description": "用户管理服务"
  }
}
```

支持的组件类型：
- `service`: 服务类
- `model`: 数据模型
- `controller`: 控制器
- `utility`: 工具类
- `test`: 测试类

#### 2. 测试生成 (generate_tests)

```json
{
  "name": "generate_tests",
  "arguments": {
    "source_file": "src/myproject/user_service.py",
    "test_type": "unit",
    "output_file": "tests/test_user_service.py"
  }
}
```

支持的测试类型：
- `unit`: 单元测试
- `integration`: 集成测试
- `e2e`: 端到端测试
- `performance`: 性能测试

#### 3. 代码分析 (analyze_code)

```json
{
  "name": "analyze_code",
  "arguments": {
    "file_path": "src/myproject/user_service.py",
    "output_format": "json"
  }
}
```

支持的输出格式：
- `json`: JSON 格式
- `markdown`: Markdown 格式
- `html`: HTML 格式

详细的使用示例请参考 `tests/` 目录中的测试文件。

### MCP 资源

- `component-templates`: 组件模板
- `best-practices`: 最佳实践指南
- `project-config`: 项目配置

### MCP 提示

- `code-review`: 代码审查提示
- `architecture-design`: 架构设计提示

## 🚀 发布和部署

### 发布到 PyPI

```bash
# 发布补丁版本
./scripts/release.sh patch

# 发布次要版本
./scripts/release.sh minor

# 发布主要版本
./scripts/release.sh major

# 发布特定版本
./scripts/release.sh version 1.2.3
```

### 部署选项

#### Docker 部署

```bash
# 构建 Docker 镜像
./scripts/deploy.sh docker

# 推送到 Docker Hub
./scripts/deploy.sh docker-hub yourusername
```

#### Kubernetes 部署

```bash
# 创建 Kubernetes 清单
./scripts/deploy.sh k8s

# 部署到 Kubernetes
./scripts/deploy.sh k8s-deploy production
```

#### Helm 部署

```bash
# 创建 Helm Chart
./scripts/deploy.sh helm

# 使用 Helm 部署
./scripts/deploy.sh helm-deploy myapp production
```

#### 云平台部署

```bash
# 部署到 AWS
./scripts/deploy.sh cloud aws

# 部署到 Google Cloud
./scripts/deploy.sh cloud gcp

# 部署到 Azure
./scripts/deploy.sh cloud azure

# 部署到 Heroku
./scripts/deploy.sh cloud heroku
```

#### 系统服务

```bash
# 创建 systemd 服务
./scripts/deploy.sh systemd

# 然后手动安装服务
sudo cp /tmp/tpp-develop.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable tpp-develop
sudo systemctl start tpp-develop
```

## 📁 项目结构

```
tpp-develop/
├── src/
│   └── tpp_develop/
│       ├── __init__.py          # 包初始化
│       ├── server.py            # MCP 服务器主文件
│       ├── config.py            # 配置管理
│       └── tools/               # 工具模块
│           ├── __init__.py
│           ├── code_generator.py    # 代码生成器
│           ├── test_generator.py    # 测试生成器
│           └── code_analyzer.py     # 代码分析器
├── tests/                       # 测试文件
│   ├── __init__.py
│   ├── conftest.py             # 测试配置
│   ├── test_server.py          # 服务器测试
│   ├── test_tools.py           # 工具测试
│   └── test_config.py          # 配置测试
├── scripts/                     # 脚本文件
│   ├── install.sh              # 安装脚本
│   ├── dev.sh                  # 开发脚本
│   ├── release.sh              # 发布脚本
│   └── deploy.sh               # 部署脚本
├── config/                      # 配置文件
│   └── config.json             # 默认配置
├── templates/                   # 代码模板
├── docs/                        # 文档
├── pyproject.toml              # 项目配置
├── requirements.txt            # 依赖列表
├── requirements-dev.txt        # 开发依赖
├── requirements-test.txt       # 测试依赖
├── .gitignore                  # Git 忽略文件
├── .pre-commit-config.yaml     # Pre-commit 配置
└── README.md                   # 项目说明
```

## 🧪 测试

项目包含全面的测试套件：

- **单元测试**: 测试各个组件的功能
- **集成测试**: 测试组件间的交互
- **端到端测试**: 测试完整的工作流程
- **性能测试**: 测试性能指标

运行测试：

```bash
# 运行所有测试
pytest

# 运行特定测试
pytest tests/test_server.py

# 生成覆盖率报告
pytest --cov=src/tpp_develop --cov-report=html

# 运行性能测试
pytest tests/ -m performance
```

## 📚 API 文档

### 服务器 API

- `TPPServer`: 主服务器类
- `create_server()`: 创建服务器实例
- `main()`: 服务器入口点

### 工具 API

- `CodeGenerator`: 代码生成器
- `TestGenerator`: 测试生成器
- `CodeAnalyzer`: 代码分析器

### 配置 API

- `Config`: 配置管理类
- `load_config()`: 加载配置
- `save_config()`: 保存配置

详细的 API 文档请参考源代码中的文档字符串。

## 🤝 贡献

欢迎贡献代码！请遵循以下步骤：

1. Fork 项目
2. 创建特性分支 (`git checkout -b feature/amazing-feature`)
3. 提交更改 (`git commit -m 'Add some amazing feature'`)
4. 推送到分支 (`git push origin feature/amazing-feature`)
5. 创建 Pull Request

### 开发指南

1. 安装开发依赖：`./scripts/install.sh --dev`
2. 设置 pre-commit 钩子：`pre-commit install`
3. 运行测试：`./scripts/dev.sh test`
4. 检查代码质量：`./scripts/dev.sh check`

## 📄 许可证

本项目采用 MIT 许可证 - 详见 [LICENSE](LICENSE) 文件。

## 🆘 支持

如果你遇到问题或有疑问：

1. 查看 [Issues](https://github.com/yourusername/tpp-develop/issues)
2. 创建新的 Issue
3. 查看文档和示例

## 🔄 更新日志

查看 [CHANGELOG.md](CHANGELOG.md) 了解版本更新信息。

## 🙏 致谢

感谢所有贡献者和开源社区的支持！

---

**TPP Develop** - 让 Python 开发更高效！ 🚀