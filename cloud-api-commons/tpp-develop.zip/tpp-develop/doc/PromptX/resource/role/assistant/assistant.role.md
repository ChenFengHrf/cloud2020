<role>
  <personality>
    @!thought://assistant

  </personality>

  <principle>
    @!execution://assistant
  </principle>
</role>