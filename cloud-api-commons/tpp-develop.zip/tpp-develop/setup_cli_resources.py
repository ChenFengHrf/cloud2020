#!/usr/bin/env python3
"""
通过CLI命令设置和测试资源管理
"""

import subprocess
import sys
import os
from pathlib import Path

# 项目根目录
project_root = Path(__file__).parent
os.chdir(project_root)

def run_cli_command(cmd_args):
    """运行CLI命令"""
    cmd = ["uv", "run", "src/tpp/cli.py"] + cmd_args
    print(f"🔧 执行命令: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, cwd=project_root)
        print(f"返回码: {result.returncode}")
        if result.stdout:
            print("输出:")
            print(result.stdout)
        if result.stderr:
            print("错误:")
            print(result.stderr)
        print("-" * 50)
        return result.returncode == 0
    except Exception as e:
        print(f"❌ 命令执行失败: {e}")
        return False

def main():
    """主函数"""
    print("🚀 开始设置CLI资源管理")
    print("=" * 60)
    
    # 1. 首先查看当前资源状态
    print("📊 1. 查看当前资源统计")
    run_cli_command(["resource", "stats"])
    
    print("📋 2. 查看当前资源列表")
    run_cli_command(["resource", "list"])
    
    # 3. 刷新资源发现
    print("🔄 3. 刷新资源发现")
    run_cli_command(["resource", "refresh"])
    
    # 4. 手动注册测试资源
    print("📝 4. 手动注册测试资源")
    test_resources = [
        ["cli-role-assistant", "role", "file://src/tpp/agents/assistant.py"],
        ["cli-tool-calculator", "tool", "file://src/tpp/tool/calculator.py"],
        ["cli-manual-python", "manual", "file://docs/python-guide.md"],
        ["cli-execution-best", "execution", "execution://best-practice"],
        ["cli-knowledge-prog", "knowledge", "knowledge://programming"],
        ["cli-thought-creative", "thought", "thought://creativity"],
        ["cli-prompt-welcome", "prompt", "prompt://system/welcome"],
        ["cli-project-src", "project", "project://src"],
        ["cli-user-config", "user", "user://config"],
        ["cli-package-lodash", "package", "package://lodash"]
    ]
    
    for resource_id, resource_type, reference in test_resources:
        print(f"注册资源: {resource_id}")
        success = run_cli_command(["resource", "register", resource_id, resource_type, reference])
        if success:
            print(f"✅ 成功注册: {resource_id}")
        else:
            print(f"❌ 注册失败: {resource_id}")
    
    # 5. 再次查看资源列表
    print("📋 5. 查看注册后的资源列表")
    run_cli_command(["resource", "list"])
    
    # 6. 按类型查看资源
    print("📂 6. 按类型查看资源")
    resource_types = ["role", "tool", "manual", "execution", "knowledge", "thought", "prompt", "project", "user", "package"]
    for res_type in resource_types:
        print(f"查看 {res_type} 类型资源:")
        run_cli_command(["resource", "list", res_type])
    
    # 7. 查看特定资源信息
    print("ℹ️  7. 查看特定资源信息")
    run_cli_command(["resource", "info", "cli-role-assistant"])
    run_cli_command(["resource", "info", "cli-execution-best"])
    
    # 8. 最终统计
    print("📊 8. 最终资源统计")
    run_cli_command(["resource", "stats"])
    
    print("\n🎉 CLI资源管理设置完成!")

if __name__ == "__main__":
    main()