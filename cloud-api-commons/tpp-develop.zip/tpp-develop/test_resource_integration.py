#!/usr/bin/env python3
"""
测试资源管理功能集成到FlowCLI
"""

import asyncio
import sys
import os

# 添加项目路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from tpp.core.FlowCLI import FlowCLI


async def test_resource_integration():
    """测试资源管理功能集成"""
    print("🧪 测试资源管理功能集成到FlowCLI")
    print("=" * 50)
    
    # 创建FlowCLI实例
    cli = FlowCLI(working_directory=os.getcwd())
    
    try:
        # 测试初始化
        print("\n1. 测试初始化...")
        await cli.initialize()
        print("✅ 初始化成功")
        
        # 测试状态命令（包含资源管理器信息）
        print("\n2. 测试状态命令...")
        status_result = await cli.execute("status", silent=True)
        print(f"✅ 状态命令执行成功")
        print(f"   资源管理器已初始化: {status_result['content']['resource_manager']['initialized']}")
        print(f"   支持的协议: {status_result['content']['resource_manager']['protocols']}")
        
        # 测试资源列表命令
        print("\n3. 测试资源列表命令...")
        list_result = await cli.execute("resource", ["list"], silent=True)
        print(f"✅ 资源列表命令执行成功")
        print(f"   发现资源数量: {len(list_result['content'])}")
        
        # 测试资源统计命令
        print("\n4. 测试资源统计命令...")
        stats_result = await cli.execute("resource", ["stats"], silent=True)
        print(f"✅ 资源统计命令执行成功")
        print(f"   总资源数: {stats_result['content']['total_resources']}")
        
        # 测试资源刷新命令
        print("\n5. 测试资源刷新命令...")
        refresh_result = await cli.execute("resource", ["refresh"], silent=True)
        print(f"✅ 资源刷新命令执行成功")
        print(f"   刷新结果: {refresh_result['content']['message']}")
        
        # 测试资源注册命令
        print("\n6. 测试资源注册命令...")
        register_result = await cli.execute("resource", [
            "register", "test-role", "role", "file://test.py"
        ], silent=True)
        print(f"✅ 资源注册命令执行成功")
        print(f"   注册结果: {register_result['content']['message']}")
        
        # 测试资源信息命令
        print("\n7. 测试资源信息命令...")
        info_result = await cli.execute("resource", ["info", "test-role"], silent=True)
        if 'error' not in info_result:
            print(f"✅ 资源信息命令执行成功")
            print(f"   资源ID: {info_result['content']['id']}")
            print(f"   资源类型: {info_result['content']['type']}")
        else:
            print(f"⚠️  资源信息命令返回错误: {info_result['error']}")
        
        # 测试帮助命令
        print("\n8. 测试帮助命令...")
        help_result = await cli.execute("help", silent=True)
        print(f"✅ 帮助命令执行成功")
        print(f"   帮助内容包含资源管理: {'resource list' in help_result['content']}")
        
        print("\n🎉 所有测试完成！资源管理功能已成功集成到FlowCLI")
        
    except Exception as e:
        print(f"❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True


if __name__ == "__main__":
    success = asyncio.run(test_resource_integration())
    sys.exit(0 if success else 1)