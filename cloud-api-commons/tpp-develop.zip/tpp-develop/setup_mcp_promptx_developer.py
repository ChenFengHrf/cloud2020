#!/usr/bin/env python3
"""
MCP PromptX 开发者资源注册脚本
为MCP PromptX开发者设置完整的资源环境
"""

import subprocess
import json
import time
from typing import List, Dict, Any

def run_cli_command(command: str) -> Dict[str, Any]:
    """运行CLI命令并返回结果"""
    try:
        result = subprocess.run(
            command.split(),
            capture_output=True,
            text=True,
            cwd="/Users/renfenghuang/PycharmProjects/tpp-develop"
        )
        return {
            "success": result.returncode == 0,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "returncode": result.returncode
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "returncode": -1
        }

def print_section(title: str):
    """打印分节标题"""
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")

def print_result(operation: str, result: Dict[str, Any]):
    """打印操作结果"""
    status = "✅ 成功" if result["success"] else "❌ 失败"
    print(f"{operation}: {status}")
    if result["success"]:
        if result["stdout"].strip():
            print(result["stdout"])
    else:
        print(f"错误: {result.get('stderr', result.get('error', '未知错误'))}")
    print("-" * 40)

def main():
    """主函数 - 设置MCP PromptX开发者环境"""
    print("🚀 MCP PromptX 开发者资源环境设置")
    print("为MCP PromptX开发者注册专业资源...")
    
    # MCP PromptX 开发者专用资源
    mcp_promptx_resources = [
        # 角色资源
        {
            "id": "mcp-developer",
            "type": "role",
            "ref": "file://src/tpp/agents/mcp_developer.py",
            "description": "MCP协议开发专家"
        },
        {
            "id": "promptx-expert",
            "type": "role", 
            "ref": "file://src/tpp/agents/promptx_expert.py",
            "description": "PromptX系统专家"
        },
        {
            "id": "ai-assistant",
            "type": "role",
            "ref": "file://src/tpp/agents/assistant.py",
            "description": "AI助手角色"
        },
        
        # 工具资源
        {
            "id": "mcp-server",
            "type": "tool",
            "ref": "file://src/tpp/mcp/server.py",
            "description": "MCP服务器工具"
        },
        {
            "id": "promptx-init",
            "type": "tool",
            "ref": "file://src/tpp/promptx/init.py",
            "description": "PromptX初始化工具"
        },
        {
            "id": "resource-manager",
            "type": "tool",
            "ref": "file://src/tpp/core/resource/resource_manager.py",
            "description": "资源管理工具"
        },
        {
            "id": "flow-cli",
            "type": "tool",
            "ref": "file://src/tpp/core/FlowCLI.py",
            "description": "Flow CLI工具"
        },
        
        # 手册资源
        {
            "id": "mcp-protocol-manual",
            "type": "manual",
            "ref": "file://docs/mcp_protocol.md",
            "description": "MCP协议使用手册"
        },
        {
            "id": "promptx-manual",
            "type": "manual",
            "ref": "file://docs/promptx_guide.md",
            "description": "PromptX使用指南"
        },
        {
            "id": "resource-management-manual",
            "type": "manual",
            "ref": "file://docs/resource_management.md",
            "description": "资源管理手册"
        },
        
        # 执行指南
        {
            "id": "mcp-best-practices",
            "type": "execution",
            "ref": "file://docs/mcp_best_practices.md",
            "description": "MCP开发最佳实践"
        },
        {
            "id": "promptx-workflow",
            "type": "execution",
            "ref": "file://docs/promptx_workflow.md",
            "description": "PromptX工作流程"
        },
        {
            "id": "debugging-guide",
            "type": "execution",
            "ref": "file://docs/debugging_guide.md",
            "description": "调试指南"
        },
        
        # 知识库
        {
            "id": "mcp-architecture",
            "type": "knowledge",
            "ref": "file://docs/mcp_architecture.md",
            "description": "MCP架构知识"
        },
        {
            "id": "promptx-concepts",
            "type": "knowledge",
            "ref": "file://docs/promptx_concepts.md",
            "description": "PromptX核心概念"
        },
        {
            "id": "python-async-patterns",
            "type": "knowledge",
            "ref": "file://docs/async_patterns.md",
            "description": "Python异步编程模式"
        },
        
        # 思维模式
        {
            "id": "system-thinking",
            "type": "thought",
            "ref": "file://docs/system_thinking.md",
            "description": "系统性思维模式"
        },
        {
            "id": "problem-solving",
            "type": "thought",
            "ref": "file://docs/problem_solving.md",
            "description": "问题解决思维"
        },
        {
            "id": "architectural-thinking",
            "type": "thought",
            "ref": "file://docs/architectural_thinking.md",
            "description": "架构设计思维"
        },
        
        # 提示词模板
        {
            "id": "mcp-development-prompt",
            "type": "prompt",
            "ref": "file://prompts/mcp_development.txt",
            "description": "MCP开发提示词"
        },
        {
            "id": "code-review-prompt",
            "type": "prompt",
            "ref": "file://prompts/code_review.txt",
            "description": "代码审查提示词"
        },
        {
            "id": "debugging-prompt",
            "type": "prompt",
            "ref": "file://prompts/debugging.txt",
            "description": "调试分析提示词"
        },
        
        # 项目资源
        {
            "id": "tpp-project",
            "type": "project",
            "ref": "file://.",
            "description": "TPP主项目"
        },
        {
            "id": "mcp-module",
            "type": "project",
            "ref": "file://src/tpp/mcp",
            "description": "MCP模块"
        },
        {
            "id": "promptx-module",
            "type": "project",
            "ref": "file://src/tpp/promptx",
            "description": "PromptX模块"
        },
        
        # 用户配置
        {
            "id": "developer-config",
            "type": "user",
            "ref": "file://config/developer.json",
            "description": "开发者配置"
        },
        {
            "id": "mcp-config",
            "type": "user",
            "ref": "file://config/mcp_settings.json",
            "description": "MCP配置"
        },
        
        # 包资源
        {
            "id": "core-package",
            "type": "package",
            "ref": "file://src/tpp/core",
            "description": "核心功能包"
        },
        {
            "id": "utils-package",
            "type": "package",
            "ref": "file://src/tpp/utils",
            "description": "工具函数包"
        },
        {
            "id": "agents-package",
            "type": "package",
            "ref": "file://src/tpp/agents",
            "description": "智能代理包"
        }
    ]
    
    # 1. 检查当前状态
    print_section("1. 检查当前资源状态")
    result = run_cli_command("uv run src/tpp/cli.py resource stats")
    print_result("当前资源统计", result)
    
    # 2. 注册MCP PromptX开发者资源
    print_section("2. 注册MCP PromptX开发者资源")
    success_count = 0
    total_count = len(mcp_promptx_resources)
    
    for resource in mcp_promptx_resources:
        command = f"uv run src/tpp/cli.py resource register {resource['id']} --type {resource['type']} --ref \"{resource['ref']}\""
        result = run_cli_command(command)
        
        if result["success"]:
            success_count += 1
            print(f"✅ {resource['id']} ({resource['type']}) - {resource['description']}")
        else:
            print(f"❌ {resource['id']} ({resource['type']}) - 注册失败")
            print(f"   错误: {result.get('stderr', result.get('error', '未知错误'))}")
        
        time.sleep(0.1)  # 避免过快操作
    
    print(f"\n📊 注册结果: {success_count}/{total_count} 个资源注册成功")
    
    # 3. 验证注册结果
    print_section("3. 验证注册结果")
    result = run_cli_command("uv run src/tpp/cli.py resource list")
    print_result("完整资源列表", result)
    
    # 4. 按类型查看资源分布
    print_section("4. 资源类型分布")
    resource_types = ["role", "tool", "manual", "execution", "knowledge", "thought", "prompt", "project", "user", "package"]
    
    for resource_type in resource_types:
        result = run_cli_command(f"uv run src/tpp/cli.py resource list --type {resource_type}")
        if result["success"] and "总计: 0 个资源" not in result["stdout"]:
            print_result(f"类型 {resource_type}", result)
    
    # 5. 测试关键资源信息
    print_section("5. 关键资源详细信息")
    key_resources = ["mcp-developer", "promptx-expert", "resource-manager", "mcp-protocol-manual"]
    
    for resource_id in key_resources:
        result = run_cli_command(f"uv run src/tpp/cli.py resource info {resource_id}")
        print_result(f"资源 {resource_id} 详情", result)
    
    # 6. 最终统计
    print_section("6. 最终环境统计")
    result = run_cli_command("uv run src/tpp/cli.py resource stats")
    print_result("最终资源统计", result)
    
    # 7. 生成资源清单
    print_section("7. 生成资源清单")
    result = run_cli_command("uv run src/tpp/cli.py resource list --format json")
    if result["success"]:
        print("✅ 资源清单已生成 (JSON格式)")
        # 可以选择保存到文件
        try:
            with open("mcp_promptx_resources.json", "w", encoding="utf-8") as f:
                f.write(result["stdout"])
            print("📄 资源清单已保存到: mcp_promptx_resources.json")
        except Exception as e:
            print(f"⚠️  保存资源清单失败: {e}")
    else:
        print_result("生成资源清单", result)
    
    print("\n🎉 MCP PromptX 开发者环境设置完成！")
    print("现在你可以使用以下命令管理资源:")
    print("  - uv run src/tpp/cli.py resource list")
    print("  - uv run src/tpp/cli.py resource stats") 
    print("  - uv run src/tpp/cli.py resource info <resource_id>")
    print("  - uv run src/tpp/cli.py resource refresh")

if __name__ == "__main__":
    main()