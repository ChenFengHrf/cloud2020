#!/usr/bin/env python3
"""
完整的资源管理测试脚本
测试所有资源类型的注册、查询、刷新、信息功能
"""

import subprocess
import json
import time
from typing import List, Dict, Any

def run_cli_command(command: str) -> Dict[str, Any]:
    """运行CLI命令并返回结果"""
    try:
        result = subprocess.run(
            command.split(),
            capture_output=True,
            text=True,
            cwd="/Users/renfenghuang/PycharmProjects/tpp-develop"
        )
        return {
            "success": result.returncode == 0,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "returncode": result.returncode
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "returncode": -1
        }

def print_section(title: str):
    """打印分节标题"""
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}")

def print_result(operation: str, result: Dict[str, Any]):
    """打印操作结果"""
    status = "✅ 成功" if result["success"] else "❌ 失败"
    print(f"{operation}: {status}")
    if result["success"]:
        if result["stdout"].strip():
            print(result["stdout"])
    else:
        print(f"错误: {result.get('stderr', result.get('error', '未知错误'))}")
    print("-" * 40)

def main():
    """主测试函数"""
    print("🚀 开始完整的资源管理测试")
    
    # 测试资源列表
    test_resources = [
        {
            "id": "assistant-role",
            "type": "role",
            "ref": "file://src/tpp/agents/assistant.py",
            "description": "AI助手角色"
        },
        {
            "id": "calculator-tool",
            "type": "tool", 
            "ref": "file://src/tpp/tool/calculator.py",
            "description": "计算器工具"
        },
        {
            "id": "calculator-manual",
            "type": "manual",
            "ref": "file://docs/calculator_manual.md",
            "description": "计算器使用手册"
        },
        {
            "id": "best-practice",
            "type": "execution",
            "ref": "file://docs/best_practices.md",
            "description": "最佳实践执行指南"
        },
        {
            "id": "python-knowledge",
            "type": "knowledge",
            "ref": "file://docs/python_knowledge.md",
            "description": "Python知识库"
        },
        {
            "id": "creative-thought",
            "type": "thought",
            "ref": "file://docs/creative_thinking.md",
            "description": "创意思维模式"
        },
        {
            "id": "code-prompt",
            "type": "prompt",
            "ref": "file://prompts/code_generation.txt",
            "description": "代码生成提示词"
        },
        {
            "id": "current-project",
            "type": "project",
            "ref": "file://.",
            "description": "当前项目"
        },
        {
            "id": "user-config",
            "type": "user",
            "ref": "file://config/user_settings.json",
            "description": "用户配置"
        },
        {
            "id": "utils-package",
            "type": "package",
            "ref": "file://src/tpp/utils",
            "description": "工具包"
        }
    ]
    
    # 1. 检查初始状态
    print_section("1. 检查初始状态")
    result = run_cli_command("uv run src/tpp/cli.py resource stats")
    print_result("资源统计", result)
    
    result = run_cli_command("uv run src/tpp/cli.py resource list")
    print_result("资源列表", result)
    
    # 2. 注册所有测试资源
    print_section("2. 注册测试资源")
    for resource in test_resources:
        command = f"uv run src/tpp/cli.py resource register {resource['id']} --type {resource['type']} --ref \"{resource['ref']}\""
        result = run_cli_command(command)
        print_result(f"注册 {resource['id']} ({resource['type']})", result)
        time.sleep(0.1)  # 避免过快操作
    
    # 3. 查看注册后的资源列表
    print_section("3. 查看注册后的资源列表")
    result = run_cli_command("uv run src/tpp/cli.py resource list")
    print_result("完整资源列表", result)
    
    # 4. 按类型查看资源
    print_section("4. 按类型查看资源")
    resource_types = ["role", "tool", "manual", "execution", "knowledge", "thought", "prompt", "project", "user", "package"]
    
    for resource_type in resource_types:
        result = run_cli_command(f"uv run src/tpp/cli.py resource list --type {resource_type}")
        print_result(f"类型 {resource_type} 的资源", result)
    
    # 5. 查看具体资源信息
    print_section("5. 查看具体资源信息")
    for resource in test_resources[:3]:  # 只查看前3个资源的详细信息
        result = run_cli_command(f"uv run src/tpp/cli.py resource info {resource['id']}")
        print_result(f"资源 {resource['id']} 的详细信息", result)
    
    # 6. 刷新资源
    print_section("6. 刷新资源")
    result = run_cli_command("uv run src/tpp/cli.py resource refresh")
    print_result("刷新资源", result)
    
    # 7. 最终统计
    print_section("7. 最终统计")
    result = run_cli_command("uv run src/tpp/cli.py resource stats")
    print_result("最终资源统计", result)
    
    # 8. 测试JSON格式输出
    print_section("8. 测试JSON格式输出")
    result = run_cli_command("uv run src/tpp/cli.py resource list --format json")
    print_result("JSON格式资源列表", result)
    
    print("\n🎉 完整的资源管理测试完成！")

if __name__ == "__main__":
    main()