#!/bin/bash

# TPP Develop Development Script
# This script provides common development tasks

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if virtual environment is activated
check_venv() {
    if [[ -z "$VIRTUAL_ENV" ]]; then
        log_warning "Virtual environment not activated"
        if [[ -d "tpp-develop-env" ]]; then
            log_info "Activating virtual environment..."
            source tpp-develop-env/bin/activate
        else
            log_error "Virtual environment not found. Run install.sh first."
            exit 1
        fi
    fi
}

# Format code with black
format_code() {
    log_info "Formatting code with black..."
    black src/ tests/ --line-length 88
    log_success "Code formatted"
}

# Sort imports with isort
sort_imports() {
    log_info "Sorting imports with isort..."
    isort src/ tests/ --profile black
    log_success "Imports sorted"
}

# Run type checking with mypy
type_check() {
    log_info "Running type checking with mypy..."
    mypy src/tpp_develop/
    log_success "Type checking passed"
}

# Run linting with flake8
lint_code() {
    log_info "Running linting with flake8..."
    flake8 src/ tests/ --max-line-length 88 --extend-ignore E203,W503
    log_success "Linting passed"
}

# Run all code quality checks
quality_check() {
    log_info "Running all code quality checks..."
    format_code
    sort_imports
    type_check
    lint_code
    log_success "All quality checks passed"
}

# Run tests
run_tests() {
    log_info "Running tests..."
    pytest tests/ -v --cov=src/tpp_develop --cov-report=html --cov-report=term
    log_success "Tests completed"
}

# Run tests with coverage
run_tests_coverage() {
    log_info "Running tests with coverage..."
    pytest tests/ -v --cov=src/tpp_develop --cov-report=html --cov-report=term --cov-fail-under=80
    log_success "Tests with coverage completed"
}

# Run specific test file
run_test_file() {
    if [[ -z "$1" ]]; then
        log_error "Please specify a test file"
        exit 1
    fi
    
    log_info "Running test file: $1"
    pytest "$1" -v
    log_success "Test file completed"
}

# Run tests in watch mode
run_tests_watch() {
    log_info "Running tests in watch mode..."
    pytest-watch tests/ -- -v
}

# Build the package
build_package() {
    log_info "Building package..."
    python -m build
    log_success "Package built successfully"
}

# Clean build artifacts
clean_build() {
    log_info "Cleaning build artifacts..."
    rm -rf build/
    rm -rf dist/
    rm -rf *.egg-info/
    rm -rf .pytest_cache/
    rm -rf htmlcov/
    rm -rf .coverage
    find . -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null || true
    find . -type f -name "*.pyc" -delete
    log_success "Build artifacts cleaned"
}

# Install in development mode
install_dev() {
    log_info "Installing in development mode..."
    pip install -e ".[dev,test]"
    log_success "Development installation completed"
}

# Update dependencies
update_deps() {
    log_info "Updating dependencies..."
    pip install --upgrade pip
    pip install --upgrade -e ".[dev,test]"
    log_success "Dependencies updated"
}

# Generate requirements.txt
generate_requirements() {
    log_info "Generating requirements.txt..."
    pip freeze > requirements.txt
    log_success "requirements.txt generated"
}

# Run the MCP server in development mode
run_server() {
    log_info "Starting MCP server in development mode..."
    python -m tpp_develop.server
}

# Run the server with debug logging
run_server_debug() {
    log_info "Starting MCP server with debug logging..."
    export TPP_LOG_LEVEL=DEBUG
    python -m tpp_develop.server
}

# Create a new component
create_component() {
    if [[ -z "$1" ]] || [[ -z "$2" ]]; then
        log_error "Usage: create_component <type> <name> [description]"
        log_info "Types: service, model, controller, utility, test"
        exit 1
    fi
    
    local component_type="$1"
    local component_name="$2"
    local description="${3:-A new $component_type component}"
    
    log_info "Creating $component_type component: $component_name"
    
    python -c "
from tpp_develop.tools import CodeGenerator
generator = CodeGenerator()
code = generator.generate_component('$component_type', '$component_name', '$description')
filename = '${component_name,,}.py'
with open(f'src/tpp_develop/{filename}', 'w') as f:
    f.write(code)
print(f'Component created: src/tpp_develop/{filename}')
"
    
    log_success "Component created successfully"
}

# Generate tests for a file
generate_tests() {
    if [[ -z "$1" ]]; then
        log_error "Usage: generate_tests <source_file> [test_type]"
        log_info "Test types: unit, integration, e2e, performance"
        exit 1
    fi
    
    local source_file="$1"
    local test_type="${2:-unit}"
    
    log_info "Generating $test_type tests for $source_file"
    
    python -c "
from tpp_develop.tools import TestGenerator
generator = TestGenerator()
tests = generator.generate_tests('$source_file', '$test_type')
test_filename = 'test_' + '$(basename "$source_file")'
with open(f'tests/{test_filename}', 'w') as f:
    f.write(tests)
print(f'Tests generated: tests/{test_filename}')
"
    
    log_success "Tests generated successfully"
}

# Analyze code
analyze_code() {
    if [[ -z "$1" ]]; then
        log_error "Usage: analyze_code <file_path> [format]"
        log_info "Formats: json, markdown, html"
        exit 1
    fi
    
    local file_path="$1"
    local format="${2:-markdown}"
    
    log_info "Analyzing code: $file_path"
    
    python -c "
from tpp_develop.tools import CodeAnalyzer
analyzer = CodeAnalyzer()
result = analyzer.analyze_file('$file_path')
report = analyzer.generate_report(result, '$format')
report_filename = 'analysis_report.$format'
with open(report_filename, 'w') as f:
    f.write(report)
print(f'Analysis report generated: {report_filename}')
"
    
    log_success "Code analysis completed"
}

# Setup pre-commit hooks
setup_hooks() {
    log_info "Setting up pre-commit hooks..."
    pre-commit install
    pre-commit run --all-files
    log_success "Pre-commit hooks setup completed"
}

# Show project status
show_status() {
    log_info "Project Status"
    echo "===================="
    
    echo "Python version: $(python --version)"
    echo "Virtual environment: ${VIRTUAL_ENV:-Not activated}"
    echo "Package version: $(python -c 'from tpp_develop import __version__; print(__version__)' 2>/dev/null || echo 'Not installed')"
    
    echo
    echo "Dependencies:"
    pip list | grep -E "(tpp-develop|mcp|typer|pydantic|pytest|black|isort|mypy|flake8)"
    
    echo
    echo "Git status:"
    git status --porcelain || echo "Not a git repository"
    
    echo
    echo "Test coverage:"
    if [[ -f ".coverage" ]]; then
        coverage report --show-missing | tail -1
    else
        echo "No coverage data available"
    fi
}

# Show help
show_help() {
    echo "TPP Develop Development Script"
    echo
    echo "Usage: $0 <command> [arguments]"
    echo
    echo "Code Quality:"
    echo "  format              Format code with black"
    echo "  sort-imports        Sort imports with isort"
    echo "  type-check          Run type checking with mypy"
    echo "  lint                Run linting with flake8"
    echo "  quality             Run all code quality checks"
    echo
    echo "Testing:"
    echo "  test                Run all tests"
    echo "  test-cov            Run tests with coverage"
    echo "  test-file <file>    Run specific test file"
    echo "  test-watch          Run tests in watch mode"
    echo
    echo "Development:"
    echo "  run                 Run MCP server"
    echo "  run-debug           Run MCP server with debug logging"
    echo "  install             Install in development mode"
    echo "  update              Update dependencies"
    echo
    echo "Code Generation:"
    echo "  create <type> <name> [desc]  Create new component"
    echo "  gen-tests <file> [type]      Generate tests for file"
    echo "  analyze <file> [format]      Analyze code"
    echo
    echo "Build & Deploy:"
    echo "  build               Build package"
    echo "  clean               Clean build artifacts"
    echo "  requirements        Generate requirements.txt"
    echo
    echo "Utilities:"
    echo "  hooks               Setup pre-commit hooks"
    echo "  status              Show project status"
    echo "  help                Show this help message"
}

# Main function
main() {
    if [[ $# -eq 0 ]]; then
        show_help
        exit 0
    fi
    
    # Check virtual environment for most commands
    case "$1" in
        help|--help|-h)
            show_help
            exit 0
            ;;
        *)
            check_venv
            ;;
    esac
    
    case "$1" in
        format)
            format_code
            ;;
        sort-imports)
            sort_imports
            ;;
        type-check)
            type_check
            ;;
        lint)
            lint_code
            ;;
        quality)
            quality_check
            ;;
        test)
            run_tests
            ;;
        test-cov)
            run_tests_coverage
            ;;
        test-file)
            run_test_file "$2"
            ;;
        test-watch)
            run_tests_watch
            ;;
        run)
            run_server
            ;;
        run-debug)
            run_server_debug
            ;;
        install)
            install_dev
            ;;
        update)
            update_deps
            ;;
        create)
            create_component "$2" "$3" "$4"
            ;;
        gen-tests)
            generate_tests "$2" "$3"
            ;;
        analyze)
            analyze_code "$2" "$3"
            ;;
        build)
            build_package
            ;;
        clean)
            clean_build
            ;;
        requirements)
            generate_requirements
            ;;
        hooks)
            setup_hooks
            ;;
        status)
            show_status
            ;;
        help|--help|-h)
            show_help
            ;;
        *)
            log_error "Unknown command: $1"
            echo "Use '$0 help' for available commands"
            exit 1
            ;;
    esac
}

# Run main function
main "$@"