#!/bin/bash

# TPP Develop Release Script
# This script handles the release process for TPP Develop

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PACKAGE_NAME="tpp-develop"
PYPI_REPOSITORY="pypi"
TEST_PYPI_REPOSITORY="testpypi"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if we're in a git repository
check_git_repo() {
    if ! git rev-parse --git-dir > /dev/null 2>&1; then
        log_error "Not in a git repository"
        exit 1
    fi
}

# Check if working directory is clean
check_clean_working_dir() {
    if [[ -n $(git status --porcelain) ]]; then
        log_error "Working directory is not clean. Please commit or stash changes."
        git status --short
        exit 1
    fi
    log_success "Working directory is clean"
}

# Check if we're on the main branch
check_main_branch() {
    local current_branch=$(git branch --show-current)
    if [[ "$current_branch" != "main" && "$current_branch" != "master" ]]; then
        log_warning "Not on main/master branch (current: $current_branch)"
        read -p "Continue anyway? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
}

# Get current version from pyproject.toml
get_current_version() {
    python -c "
import tomllib
with open('pyproject.toml', 'rb') as f:
    data = tomllib.load(f)
print(data['project']['version'])
" 2>/dev/null || python -c "
import toml
with open('pyproject.toml', 'r') as f:
    data = toml.load(f)
print(data['project']['version'])
"
}

# Update version in pyproject.toml
update_version() {
    local new_version="$1"
    
    log_info "Updating version to $new_version"
    
    # Use sed to update version in pyproject.toml
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        sed -i '' "s/^version = .*/version = \"$new_version\"/" pyproject.toml
    else
        # Linux
        sed -i "s/^version = .*/version = \"$new_version\"/" pyproject.toml
    fi
    
    # Update version in __init__.py
    if [[ -f "src/tpp_develop/__init__.py" ]]; then
        if [[ "$OSTYPE" == "darwin"* ]]; then
            sed -i '' "s/__version__ = .*/__version__ = \"$new_version\"/" src/tpp_develop/__init__.py
        else
            sed -i "s/__version__ = .*/__version__ = \"$new_version\"/" src/tpp_develop/__init__.py
        fi
    fi
    
    log_success "Version updated to $new_version"
}

# Validate version format
validate_version() {
    local version="$1"
    if [[ ! $version =~ ^[0-9]+\.[0-9]+\.[0-9]+(-[a-zA-Z0-9]+)?$ ]]; then
        log_error "Invalid version format: $version"
        log_info "Expected format: X.Y.Z or X.Y.Z-suffix"
        exit 1
    fi
}

# Run all tests
run_tests() {
    log_info "Running tests..."
    
    if ! command -v pytest &> /dev/null; then
        log_error "pytest not found. Please install test dependencies."
        exit 1
    fi
    
    pytest tests/ -v --cov=src/tpp_develop --cov-fail-under=80
    log_success "All tests passed"
}

# Run code quality checks
run_quality_checks() {
    log_info "Running code quality checks..."
    
    # Format check
    if command -v black &> /dev/null; then
        black --check src/ tests/
        log_success "Code formatting check passed"
    else
        log_warning "black not found, skipping format check"
    fi
    
    # Import sorting check
    if command -v isort &> /dev/null; then
        isort --check-only src/ tests/
        log_success "Import sorting check passed"
    else
        log_warning "isort not found, skipping import check"
    fi
    
    # Type checking
    if command -v mypy &> /dev/null; then
        mypy src/tpp_develop/
        log_success "Type checking passed"
    else
        log_warning "mypy not found, skipping type check"
    fi
    
    # Linting
    if command -v flake8 &> /dev/null; then
        flake8 src/ tests/ --max-line-length 88 --extend-ignore E203,W503
        log_success "Linting passed"
    else
        log_warning "flake8 not found, skipping lint check"
    fi
}

# Build the package
build_package() {
    log_info "Building package..."
    
    # Clean previous builds
    rm -rf build/ dist/ *.egg-info/
    
    # Build package
    python -m build
    
    log_success "Package built successfully"
    
    # Show built files
    log_info "Built files:"
    ls -la dist/
}

# Check package with twine
check_package() {
    log_info "Checking package with twine..."
    
    if ! command -v twine &> /dev/null; then
        log_error "twine not found. Please install: pip install twine"
        exit 1
    fi
    
    twine check dist/*
    log_success "Package check passed"
}

# Upload to Test PyPI
upload_test_pypi() {
    log_info "Uploading to Test PyPI..."
    
    twine upload --repository testpypi dist/*
    log_success "Package uploaded to Test PyPI"
    
    local version=$(get_current_version)
    log_info "Test installation command:"
    echo "pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/ $PACKAGE_NAME==$version"
}

# Upload to PyPI
upload_pypi() {
    log_info "Uploading to PyPI..."
    
    read -p "Are you sure you want to upload to PyPI? This cannot be undone. (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        log_info "Upload cancelled"
        exit 0
    fi
    
    twine upload dist/*
    log_success "Package uploaded to PyPI"
    
    local version=$(get_current_version)
    log_info "Installation command:"
    echo "pip install $PACKAGE_NAME==$version"
}

# Create git tag
create_git_tag() {
    local version="$1"
    local tag_name="v$version"
    
    log_info "Creating git tag: $tag_name"
    
    git add pyproject.toml src/tpp_develop/__init__.py
    git commit -m "Bump version to $version"
    git tag -a "$tag_name" -m "Release $version"
    
    log_success "Git tag created: $tag_name"
}

# Push to remote
push_to_remote() {
    log_info "Pushing to remote repository..."
    
    git push origin
    git push origin --tags
    
    log_success "Changes pushed to remote"
}

# Generate changelog
generate_changelog() {
    local version="$1"
    local changelog_file="CHANGELOG.md"
    
    log_info "Generating changelog..."
    
    if [[ ! -f "$changelog_file" ]]; then
        cat > "$changelog_file" << EOF
# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [$version] - $(date +%Y-%m-%d)

### Added
- Initial release of TPP Develop MCP server
- Code generation tools for Python components
- Test generation capabilities
- Code analysis and metrics
- Configuration management
- Development and deployment scripts

### Changed
- N/A

### Deprecated
- N/A

### Removed
- N/A

### Fixed
- N/A

### Security
- N/A
EOF
    else
        # Insert new version entry
        local temp_file=$(mktemp)
        local date_str=$(date +%Y-%m-%d)
        
        # Create new entry
        cat > "$temp_file" << EOF
## [$version] - $date_str

### Added
- 

### Changed
- 

### Fixed
- 

EOF
        
        # Insert after "## [Unreleased]" line
        awk -v new_content="$(cat "$temp_file")" '
        /^## \[Unreleased\]/ {
            print $0
            print ""
            print new_content
            next
        }
        {print}
        ' "$changelog_file" > "${changelog_file}.tmp"
        
        mv "${changelog_file}.tmp" "$changelog_file"
        rm "$temp_file"
    fi
    
    log_success "Changelog updated"
    log_info "Please edit $changelog_file to add release notes"
}

# Create GitHub release
create_github_release() {
    local version="$1"
    local tag_name="v$version"
    
    if ! command -v gh &> /dev/null; then
        log_warning "GitHub CLI not found. Please create release manually at:"
        echo "https://github.com/$(git config --get remote.origin.url | sed 's/.*github.com[:/]\([^/]*\/[^/]*\).*/\1/' | sed 's/\.git$//')/releases/new?tag=$tag_name"
        return
    fi
    
    log_info "Creating GitHub release..."
    
    # Extract release notes from changelog
    local release_notes=""
    if [[ -f "CHANGELOG.md" ]]; then
        release_notes=$(awk "/^## \[$version\]/,/^## \[/{if(/^## \[/ && !/^## \[$version\]/) exit; if(!/^## \[$version\]/) print}" CHANGELOG.md)
    fi
    
    if [[ -z "$release_notes" ]]; then
        release_notes="Release $version"
    fi
    
    gh release create "$tag_name" \
        --title "Release $version" \
        --notes "$release_notes" \
        dist/*
    
    log_success "GitHub release created"
}

# Show release summary
show_release_summary() {
    local version="$1"
    
    log_success "Release $version completed successfully!"
    echo
    echo "Summary:"
    echo "- Version: $version"
    echo "- Git tag: v$version"
    echo "- PyPI package: https://pypi.org/project/$PACKAGE_NAME/$version/"
    echo "- Installation: pip install $PACKAGE_NAME==$version"
    echo
    log_info "Don't forget to:"
    echo "- Update documentation if needed"
    echo "- Announce the release"
    echo "- Update any dependent projects"
}

# Show help
show_help() {
    echo "TPP Develop Release Script"
    echo
    echo "Usage: $0 <command> [version]"
    echo
    echo "Commands:"
    echo "  patch               Bump patch version (X.Y.Z -> X.Y.Z+1)"
    echo "  minor               Bump minor version (X.Y.Z -> X.Y+1.0)"
    echo "  major               Bump major version (X.Y.Z -> X+1.0.0)"
    echo "  version <version>   Set specific version"
    echo "  build               Build package only"
    echo "  test-upload         Upload to Test PyPI"
    echo "  upload              Upload to PyPI"
    echo "  check               Run all checks without releasing"
    echo "  help                Show this help message"
    echo
    echo "Full release process:"
    echo "  $0 minor           # or patch/major/version"
    echo
    echo "Test release:"
    echo "  $0 build && $0 test-upload"
}

# Bump version
bump_version() {
    local bump_type="$1"
    local current_version=$(get_current_version)
    
    log_info "Current version: $current_version"
    
    # Parse current version
    local major minor patch suffix
    if [[ $current_version =~ ^([0-9]+)\.([0-9]+)\.([0-9]+)(-.*)?$ ]]; then
        major=${BASH_REMATCH[1]}
        minor=${BASH_REMATCH[2]}
        patch=${BASH_REMATCH[3]}
        suffix=${BASH_REMATCH[4]}
    else
        log_error "Cannot parse current version: $current_version"
        exit 1
    fi
    
    # Calculate new version
    local new_version
    case "$bump_type" in
        patch)
            new_version="$major.$minor.$((patch + 1))"
            ;;
        minor)
            new_version="$major.$((minor + 1)).0"
            ;;
        major)
            new_version="$((major + 1)).0.0"
            ;;
        *)
            log_error "Unknown bump type: $bump_type"
            exit 1
            ;;
    esac
    
    echo "$new_version"
}

# Main release process
release() {
    local version="$1"
    
    log_info "Starting release process for version $version"
    
    # Pre-release checks
    check_git_repo
    check_clean_working_dir
    check_main_branch
    
    # Update version
    update_version "$version"
    
    # Generate changelog
    generate_changelog "$version"
    
    # Run checks
    run_quality_checks
    run_tests
    
    # Build and check package
    build_package
    check_package
    
    # Create git tag
    create_git_tag "$version"
    
    # Push to remote
    push_to_remote
    
    # Upload to PyPI
    upload_pypi
    
    # Create GitHub release
    create_github_release "$version"
    
    # Show summary
    show_release_summary "$version"
}

# Main function
main() {
    if [[ $# -eq 0 ]]; then
        show_help
        exit 0
    fi
    
    case "$1" in
        patch|minor|major)
            local new_version=$(bump_version "$1")
            validate_version "$new_version"
            release "$new_version"
            ;;
        version)
            if [[ -z "$2" ]]; then
                log_error "Please specify version"
                exit 1
            fi
            validate_version "$2"
            release "$2"
            ;;
        build)
            build_package
            check_package
            ;;
        test-upload)
            if [[ ! -d "dist" ]] || [[ -z "$(ls -A dist)" ]]; then
                log_info "No built package found, building first..."
                build_package
                check_package
            fi
            upload_test_pypi
            ;;
        upload)
            if [[ ! -d "dist" ]] || [[ -z "$(ls -A dist)" ]]; then
                log_error "No built package found. Run 'build' first."
                exit 1
            fi
            upload_pypi
            ;;
        check)
            check_git_repo
            check_clean_working_dir
            run_quality_checks
            run_tests
            log_success "All checks passed"
            ;;
        help|--help|-h)
            show_help
            ;;
        *)
            log_error "Unknown command: $1"
            echo "Use '$0 help' for available commands"
            exit 1
            ;;
    esac
}

# Run main function
main "$@"