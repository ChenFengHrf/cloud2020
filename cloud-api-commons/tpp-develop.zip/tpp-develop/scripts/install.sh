#!/bin/bash

# TPP Develop Installation Script
# This script installs the TPP Develop MCP server

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PYTHON_MIN_VERSION="3.8"
PROJECT_NAME="tpp-develop"
VENV_NAME="tpp-develop-env"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_python() {
    log_info "Checking Python installation..."
    
    if ! command -v python3 &> /dev/null; then
        log_error "Python 3 is not installed. Please install Python 3.8 or higher."
        exit 1
    fi
    
    PYTHON_VERSION=$(python3 -c "import sys; print('.'.join(map(str, sys.version_info[:2])))")
    log_info "Found Python $PYTHON_VERSION"
    
    # Check if version is sufficient
    if python3 -c "import sys; exit(0 if sys.version_info >= (3, 8) else 1)"; then
        log_success "Python version is compatible"
    else
        log_error "Python $PYTHON_VERSION is too old. Please install Python $PYTHON_MIN_VERSION or higher."
        exit 1
    fi
}

check_pip() {
    log_info "Checking pip installation..."
    
    if ! python3 -m pip --version &> /dev/null; then
        log_error "pip is not installed. Please install pip."
        exit 1
    fi
    
    log_success "pip is available"
}

create_virtual_environment() {
    log_info "Creating virtual environment..."
    
    if [ -d "$VENV_NAME" ]; then
        log_warning "Virtual environment already exists. Removing..."
        rm -rf "$VENV_NAME"
    fi
    
    # Use Python 3.12 if available, otherwise fall back to python3
    if command -v python3.12 &> /dev/null; then
        python3.12 -m venv "$VENV_NAME"
    else
        python3 -m venv "$VENV_NAME"
    fi
    log_success "Virtual environment created: $VENV_NAME"
}

activate_virtual_environment() {
    log_info "Activating virtual environment..."
    source "$VENV_NAME/bin/activate"
    
    # Verify activation worked
    if [ "$VIRTUAL_ENV" != "" ]; then
        log_success "Virtual environment activated"
    else
        log_error "Failed to activate virtual environment"
        exit 1
    fi
}

upgrade_pip() {
    log_info "Upgrading pip..."
    python -m pip install --upgrade pip
    log_success "pip upgraded"
}

install_dependencies() {
    log_info "Installing project dependencies..."
    
    if [ -f "requirements.txt" ]; then
        log_info "Installing from requirements.txt..."
        pip install -r requirements.txt
    fi
    
    log_info "Installing project in development mode..."
    pip install -e .
    
    log_success "Dependencies installed"
}

install_dev_dependencies() {
    log_info "Installing development dependencies..."
    pip install -e ".[dev]"
    log_success "Development dependencies installed"
}

install_test_dependencies() {
    log_info "Installing test dependencies..."
    pip install -e ".[test]"
    log_success "Test dependencies installed"
}

run_tests() {
    log_info "Running tests to verify installation..."
    
    if command -v pytest &> /dev/null; then
        pytest tests/ -v
        log_success "All tests passed"
    else
        log_warning "pytest not available, skipping tests"
    fi
}

setup_pre_commit() {
    log_info "Setting up pre-commit hooks..."
    
    if command -v pre-commit &> /dev/null; then
        pre-commit install
        log_success "Pre-commit hooks installed"
    else
        log_warning "pre-commit not available, skipping hook setup"
    fi
}

create_config() {
    log_info "Creating default configuration..."
    
    CONFIG_DIR="$HOME/.config/tpp-develop"
    CONFIG_FILE="$CONFIG_DIR/config.json"
    
    mkdir -p "$CONFIG_DIR"
    
    if [ ! -f "$CONFIG_FILE" ]; then
        python -c "
import json
import os

config = {
    'server': {
        'host': 'localhost',
        'port': 8000,
        'debug': False
    },
    'logging': {
        'level': 'INFO',
        'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    },
    'development': {
        'auto_reload': True,
        'test_on_save': False
    },
    'paths': {
        'templates': 'templates/',
        'tests': 'tests/',
        'output': 'output/'
    }
}

with open('$CONFIG_FILE', 'w') as f:
    json.dump(config, f, indent=2)

print('Default configuration created at: $CONFIG_FILE')
"
        log_success "Configuration created at $CONFIG_FILE"
    else
        log_info "Configuration already exists at $CONFIG_FILE"
    fi
}

show_usage() {
    log_success "Installation completed successfully!"
    echo
    echo "To use TPP Develop:"
    echo "1. Activate the virtual environment:"
    echo "   source $VENV_NAME/bin/activate"
    echo
    echo "2. Run the MCP server:"
    echo "   tpp-mcp"
    echo
    echo "3. Or use it programmatically:"
    echo "   python -c 'from tpp_develop import create_server; server = create_server()'"
    echo
    echo "Configuration file: $HOME/.config/tpp-develop/config.json"
    echo "Documentation: README.md"
    echo
    log_info "Happy coding!"
}

# Main installation process
main() {
    log_info "Starting TPP Develop installation..."
    echo
    
    # Parse command line arguments
    INSTALL_DEV=false
    INSTALL_TEST=false
    RUN_TESTS=false
    SKIP_VENV=false
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --dev)
                INSTALL_DEV=true
                shift
                ;;
            --test)
                INSTALL_TEST=true
                shift
                ;;
            --run-tests)
                RUN_TESTS=true
                shift
                ;;
            --skip-venv)
                SKIP_VENV=true
                shift
                ;;
            --help)
                echo "TPP Develop Installation Script"
                echo
                echo "Usage: $0 [OPTIONS]"
                echo
                echo "Options:"
                echo "  --dev         Install development dependencies"
                echo "  --test        Install test dependencies"
                echo "  --run-tests   Run tests after installation"
                echo "  --skip-venv   Skip virtual environment creation"
                echo "  --help        Show this help message"
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                echo "Use --help for usage information"
                exit 1
                ;;
        esac
    done
    
    # Check prerequisites
    check_python
    check_pip
    
    # Create and activate virtual environment
    if [ "$SKIP_VENV" = false ]; then
        create_virtual_environment
        activate_virtual_environment
        upgrade_pip
    else
        log_info "Skipping virtual environment creation"
    fi
    
    # Install dependencies
    install_dependencies
    
    if [ "$INSTALL_DEV" = true ]; then
        install_dev_dependencies
    fi
    
    if [ "$INSTALL_TEST" = true ]; then
        install_test_dependencies
    fi
    
    # Setup additional tools
    if [ "$INSTALL_DEV" = true ]; then
        setup_pre_commit
    fi
    
    # Create configuration
    create_config
    
    # Run tests if requested
    if [ "$RUN_TESTS" = true ]; then
        run_tests
    fi
    
    # Show usage information
    show_usage
}

# Check if script is being sourced or executed
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi