#!/bin/bash

# TPP Develop Deployment Script
# This script handles deployment to various platforms

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PACKAGE_NAME="tpp-develop"
DOCKER_IMAGE="tpp-develop"
DOCKER_TAG="latest"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check dependencies
check_dependencies() {
    local deps=("$@")
    local missing=()
    
    for dep in "${deps[@]}"; do
        if ! command -v "$dep" &> /dev/null; then
            missing+=("$dep")
        fi
    done
    
    if [[ ${#missing[@]} -gt 0 ]]; then
        log_error "Missing dependencies: ${missing[*]}"
        log_info "Please install them and try again"
        exit 1
    fi
}

# Create Docker image
create_docker_image() {
    log_info "Creating Docker image..."
    
    # Create Dockerfile if it doesn't exist
    if [[ ! -f "Dockerfile" ]]; then
        log_info "Creating Dockerfile..."
        cat > Dockerfile << 'EOF'
FROM python:3.11-slim

# Set working directory
WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    git \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements first for better caching
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy source code
COPY src/ src/
COPY pyproject.toml .
COPY README.md .

# Install the package
RUN pip install -e .

# Create non-root user
RUN useradd -m -u 1000 tppuser && chown -R tppuser:tppuser /app
USER tppuser

# Expose port (if needed for web interface)
EXPOSE 8000

# Set environment variables
ENV PYTHONPATH=/app/src
ENV TPP_CONFIG_PATH=/app/config

# Create config directory
RUN mkdir -p /app/config

# Default command
CMD ["python", "-m", "tpp_develop.server"]
EOF
        log_success "Dockerfile created"
    fi
    
    # Build Docker image
    docker build -t "$DOCKER_IMAGE:$DOCKER_TAG" .
    log_success "Docker image built: $DOCKER_IMAGE:$DOCKER_TAG"
}

# Deploy to Docker Hub
deploy_docker_hub() {
    local username="$1"
    local tag="${2:-$DOCKER_TAG}"
    
    if [[ -z "$username" ]]; then
        log_error "Docker Hub username required"
        exit 1
    fi
    
    log_info "Deploying to Docker Hub..."
    
    # Tag image for Docker Hub
    docker tag "$DOCKER_IMAGE:$DOCKER_TAG" "$username/$DOCKER_IMAGE:$tag"
    
    # Login to Docker Hub
    log_info "Please login to Docker Hub:"
    docker login
    
    # Push image
    docker push "$username/$DOCKER_IMAGE:$tag"
    
    log_success "Image pushed to Docker Hub: $username/$DOCKER_IMAGE:$tag"
    log_info "Pull command: docker pull $username/$DOCKER_IMAGE:$tag"
}

# Create Kubernetes manifests
create_k8s_manifests() {
    log_info "Creating Kubernetes manifests..."
    
    mkdir -p k8s
    
    # ConfigMap
    cat > k8s/configmap.yaml << 'EOF'
apiVersion: v1
kind: ConfigMap
metadata:
  name: tpp-develop-config
  namespace: default
data:
  config.json: |
    {
      "server": {
        "name": "tpp-develop",
        "version": "1.0.0",
        "description": "TPP Develop MCP Server"
      },
      "tools": {
        "code_generator": {
          "enabled": true,
          "templates_dir": "templates"
        },
        "test_generator": {
          "enabled": true,
          "test_framework": "pytest"
        },
        "code_analyzer": {
          "enabled": true,
          "max_complexity": 10
        }
      },
      "logging": {
        "level": "INFO",
        "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
      }
    }
EOF

    # Deployment
    cat > k8s/deployment.yaml << 'EOF'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: tpp-develop
  namespace: default
  labels:
    app: tpp-develop
spec:
  replicas: 1
  selector:
    matchLabels:
      app: tpp-develop
  template:
    metadata:
      labels:
        app: tpp-develop
    spec:
      containers:
      - name: tpp-develop
        image: tpp-develop:latest
        ports:
        - containerPort: 8000
        env:
        - name: TPP_CONFIG_PATH
          value: "/app/config"
        volumeMounts:
        - name: config-volume
          mountPath: /app/config
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          exec:
            command:
            - python
            - -c
            - "import tpp_develop; print('OK')"
          initialDelaySeconds: 30
          periodSeconds: 30
        readinessProbe:
          exec:
            command:
            - python
            - -c
            - "import tpp_develop; print('OK')"
          initialDelaySeconds: 5
          periodSeconds: 10
      volumes:
      - name: config-volume
        configMap:
          name: tpp-develop-config
EOF

    # Service
    cat > k8s/service.yaml << 'EOF'
apiVersion: v1
kind: Service
metadata:
  name: tpp-develop-service
  namespace: default
  labels:
    app: tpp-develop
spec:
  selector:
    app: tpp-develop
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8000
  type: ClusterIP
EOF

    # Ingress (optional)
    cat > k8s/ingress.yaml << 'EOF'
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: tpp-develop-ingress
  namespace: default
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  rules:
  - host: tpp-develop.local
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: tpp-develop-service
            port:
              number: 80
EOF

    log_success "Kubernetes manifests created in k8s/ directory"
}

# Deploy to Kubernetes
deploy_k8s() {
    local namespace="${1:-default}"
    
    log_info "Deploying to Kubernetes namespace: $namespace"
    
    check_dependencies kubectl
    
    # Create namespace if it doesn't exist
    kubectl create namespace "$namespace" --dry-run=client -o yaml | kubectl apply -f -
    
    # Apply manifests
    kubectl apply -f k8s/ -n "$namespace"
    
    log_success "Deployed to Kubernetes"
    
    # Show status
    log_info "Deployment status:"
    kubectl get pods -n "$namespace" -l app=tpp-develop
    
    log_info "Service status:"
    kubectl get svc -n "$namespace" -l app=tpp-develop
}

# Create Helm chart
create_helm_chart() {
    log_info "Creating Helm chart..."
    
    check_dependencies helm
    
    # Create chart
    helm create tpp-develop-chart
    
    # Customize values.yaml
    cat > tpp-develop-chart/values.yaml << 'EOF'
# Default values for tpp-develop-chart.
replicaCount: 1

image:
  repository: tpp-develop
  pullPolicy: IfNotPresent
  tag: "latest"

imagePullSecrets: []
nameOverride: ""
fullnameOverride: ""

serviceAccount:
  create: true
  annotations: {}
  name: ""

podAnnotations: {}

podSecurityContext: {}

securityContext: {}

service:
  type: ClusterIP
  port: 80
  targetPort: 8000

ingress:
  enabled: false
  className: ""
  annotations: {}
  hosts:
    - host: tpp-develop.local
      paths:
        - path: /
          pathType: ImplementationSpecific
  tls: []

resources:
  limits:
    cpu: 500m
    memory: 512Mi
  requests:
    cpu: 250m
    memory: 256Mi

autoscaling:
  enabled: false
  minReplicas: 1
  maxReplicas: 100
  targetCPUUtilizationPercentage: 80

nodeSelector: {}

tolerations: []

affinity: {}

config:
  server:
    name: "tpp-develop"
    version: "1.0.0"
    description: "TPP Develop MCP Server"
  tools:
    code_generator:
      enabled: true
      templates_dir: "templates"
    test_generator:
      enabled: true
      test_framework: "pytest"
    code_analyzer:
      enabled: true
      max_complexity: 10
  logging:
    level: "INFO"
    format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
EOF

    # Update deployment template
    cat > tpp-develop-chart/templates/deployment.yaml << 'EOF'
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "tpp-develop-chart.fullname" . }}
  labels:
    {{- include "tpp-develop-chart.labels" . | nindent 4 }}
spec:
  {{- if not .Values.autoscaling.enabled }}
  replicas: {{ .Values.replicaCount }}
  {{- end }}
  selector:
    matchLabels:
      {{- include "tpp-develop-chart.selectorLabels" . | nindent 6 }}
  template:
    metadata:
      {{- with .Values.podAnnotations }}
      annotations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      labels:
        {{- include "tpp-develop-chart.selectorLabels" . | nindent 8 }}
    spec:
      {{- with .Values.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      serviceAccountName: {{ include "tpp-develop-chart.serviceAccountName" . }}
      securityContext:
        {{- toYaml .Values.podSecurityContext | nindent 8 }}
      containers:
        - name: {{ .Chart.Name }}
          securityContext:
            {{- toYaml .Values.securityContext | nindent 12 }}
          image: "{{ .Values.image.repository }}:{{ .Values.image.tag | default .Chart.AppVersion }}"
          imagePullPolicy: {{ .Values.image.pullPolicy }}
          ports:
            - name: http
              containerPort: {{ .Values.service.targetPort }}
              protocol: TCP
          env:
            - name: TPP_CONFIG_PATH
              value: "/app/config"
          volumeMounts:
            - name: config-volume
              mountPath: /app/config
          livenessProbe:
            exec:
              command:
              - python
              - -c
              - "import tpp_develop; print('OK')"
            initialDelaySeconds: 30
            periodSeconds: 30
          readinessProbe:
            exec:
              command:
              - python
              - -c
              - "import tpp_develop; print('OK')"
            initialDelaySeconds: 5
            periodSeconds: 10
          resources:
            {{- toYaml .Values.resources | nindent 12 }}
      volumes:
        - name: config-volume
          configMap:
            name: {{ include "tpp-develop-chart.fullname" . }}-config
      {{- with .Values.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.affinity }}
      affinity:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
EOF

    # Create ConfigMap template
    cat > tpp-develop-chart/templates/configmap.yaml << 'EOF'
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ include "tpp-develop-chart.fullname" . }}-config
  labels:
    {{- include "tpp-develop-chart.labels" . | nindent 4 }}
data:
  config.json: |
    {{- .Values.config | toJson | nindent 4 }}
EOF

    log_success "Helm chart created in tpp-develop-chart/ directory"
}

# Deploy with Helm
deploy_helm() {
    local release_name="${1:-tpp-develop}"
    local namespace="${2:-default}"
    
    log_info "Deploying with Helm..."
    
    check_dependencies helm
    
    if [[ ! -d "tpp-develop-chart" ]]; then
        create_helm_chart
    fi
    
    # Create namespace if it doesn't exist
    kubectl create namespace "$namespace" --dry-run=client -o yaml | kubectl apply -f -
    
    # Install or upgrade
    helm upgrade --install "$release_name" ./tpp-develop-chart \
        --namespace "$namespace" \
        --create-namespace \
        --wait
    
    log_success "Deployed with Helm"
    
    # Show status
    helm status "$release_name" -n "$namespace"
}

# Create systemd service
create_systemd_service() {
    local user="${1:-$(whoami)}"
    local install_path="${2:-$(pwd)}"
    
    log_info "Creating systemd service..."
    
    # Create service file
    local service_file="/tmp/tpp-develop.service"
    cat > "$service_file" << EOF
[Unit]
Description=TPP Develop MCP Server
After=network.target
Wants=network.target

[Service]
Type=simple
User=$user
WorkingDirectory=$install_path
Environment=PYTHONPATH=$install_path/src
Environment=TPP_CONFIG_PATH=$install_path/config
ExecStart=$install_path/venv/bin/python -m tpp_develop.server
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

    log_success "Systemd service file created: $service_file"
    log_info "To install the service, run:"
    echo "  sudo cp $service_file /etc/systemd/system/"
    echo "  sudo systemctl daemon-reload"
    echo "  sudo systemctl enable tpp-develop"
    echo "  sudo systemctl start tpp-develop"
    echo "  sudo systemctl status tpp-develop"
}

# Deploy to cloud platforms
deploy_cloud() {
    local platform="$1"
    
    case "$platform" in
        aws)
            deploy_aws
            ;;
        gcp)
            deploy_gcp
            ;;
        azure)
            deploy_azure
            ;;
        heroku)
            deploy_heroku
            ;;
        *)
            log_error "Unsupported platform: $platform"
            log_info "Supported platforms: aws, gcp, azure, heroku"
            exit 1
            ;;
    esac
}

# Deploy to AWS (ECS)
deploy_aws() {
    log_info "Deploying to AWS ECS..."
    
    check_dependencies aws
    
    # Create task definition
    cat > task-definition.json << 'EOF'
{
  "family": "tpp-develop",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "256",
  "memory": "512",
  "executionRoleArn": "arn:aws:iam::ACCOUNT:role/ecsTaskExecutionRole",
  "containerDefinitions": [
    {
      "name": "tpp-develop",
      "image": "tpp-develop:latest",
      "portMappings": [
        {
          "containerPort": 8000,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "TPP_CONFIG_PATH",
          "value": "/app/config"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/tpp-develop",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "ecs"
        }
      }
    }
  ]
}
EOF

    log_success "AWS ECS task definition created"
    log_info "Please update the task definition with your AWS account details and deploy using AWS CLI or console"
}

# Deploy to Google Cloud Platform (Cloud Run)
deploy_gcp() {
    log_info "Deploying to Google Cloud Run..."
    
    check_dependencies gcloud
    
    # Create cloudbuild.yaml
    cat > cloudbuild.yaml << 'EOF'
steps:
  # Build the container image
  - name: 'gcr.io/cloud-builders/docker'
    args: ['build', '-t', 'gcr.io/$PROJECT_ID/tpp-develop:$COMMIT_SHA', '.']
  
  # Push the container image to Container Registry
  - name: 'gcr.io/cloud-builders/docker'
    args: ['push', 'gcr.io/$PROJECT_ID/tpp-develop:$COMMIT_SHA']
  
  # Deploy container image to Cloud Run
  - name: 'gcr.io/google.com/cloudsdktool/cloud-sdk'
    entrypoint: gcloud
    args:
    - 'run'
    - 'deploy'
    - 'tpp-develop'
    - '--image'
    - 'gcr.io/$PROJECT_ID/tpp-develop:$COMMIT_SHA'
    - '--region'
    - 'us-central1'
    - '--platform'
    - 'managed'
    - '--allow-unauthenticated'

images:
  - 'gcr.io/$PROJECT_ID/tpp-develop:$COMMIT_SHA'
EOF

    log_success "Google Cloud Build configuration created"
    log_info "Deploy using: gcloud builds submit --config cloudbuild.yaml"
}

# Deploy to Azure (Container Instances)
deploy_azure() {
    log_info "Deploying to Azure Container Instances..."
    
    check_dependencies az
    
    # Create deployment template
    cat > azure-deploy.json << 'EOF'
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "containerGroupName": {
      "type": "string",
      "defaultValue": "tpp-develop-group"
    },
    "containerName": {
      "type": "string",
      "defaultValue": "tpp-develop"
    },
    "image": {
      "type": "string",
      "defaultValue": "tpp-develop:latest"
    }
  },
  "resources": [
    {
      "type": "Microsoft.ContainerInstance/containerGroups",
      "apiVersion": "2019-12-01",
      "name": "[parameters('containerGroupName')]",
      "location": "[resourceGroup().location]",
      "properties": {
        "containers": [
          {
            "name": "[parameters('containerName')]",
            "properties": {
              "image": "[parameters('image')]",
              "ports": [
                {
                  "port": 8000,
                  "protocol": "TCP"
                }
              ],
              "environmentVariables": [
                {
                  "name": "TPP_CONFIG_PATH",
                  "value": "/app/config"
                }
              ],
              "resources": {
                "requests": {
                  "cpu": 0.5,
                  "memoryInGB": 1
                }
              }
            }
          }
        ],
        "osType": "Linux",
        "ipAddress": {
          "type": "Public",
          "ports": [
            {
              "port": 8000,
              "protocol": "TCP"
            }
          ]
        }
      }
    }
  ]
}
EOF

    log_success "Azure deployment template created"
    log_info "Deploy using: az deployment group create --resource-group <rg-name> --template-file azure-deploy.json"
}

# Deploy to Heroku
deploy_heroku() {
    log_info "Deploying to Heroku..."
    
    check_dependencies heroku
    
    # Create Procfile
    if [[ ! -f "Procfile" ]]; then
        echo "worker: python -m tpp_develop.server" > Procfile
        log_success "Procfile created"
    fi
    
    # Create heroku.yml for container deployment
    cat > heroku.yml << 'EOF'
build:
  docker:
    worker: Dockerfile
run:
  worker: python -m tpp_develop.server
EOF

    log_success "Heroku configuration created"
    log_info "To deploy to Heroku:"
    echo "  heroku create your-app-name"
    echo "  heroku stack:set container"
    echo "  git push heroku main"
}

# Show deployment status
show_status() {
    local platform="$1"
    
    case "$platform" in
        docker)
            docker ps --filter "ancestor=$DOCKER_IMAGE:$DOCKER_TAG"
            ;;
        k8s|kubernetes)
            kubectl get pods -l app=tpp-develop
            kubectl get svc -l app=tpp-develop
            ;;
        helm)
            helm list
            ;;
        systemd)
            systemctl status tpp-develop
            ;;
        *)
            log_error "Unknown platform: $platform"
            exit 1
            ;;
    esac
}

# Show help
show_help() {
    echo "TPP Develop Deployment Script"
    echo
    echo "Usage: $0 <command> [options]"
    echo
    echo "Commands:"
    echo "  docker                    Build Docker image"
    echo "  docker-hub <username>     Deploy to Docker Hub"
    echo "  k8s                       Create Kubernetes manifests"
    echo "  k8s-deploy [namespace]    Deploy to Kubernetes"
    echo "  helm                      Create Helm chart"
    echo "  helm-deploy [name] [ns]   Deploy with Helm"
    echo "  systemd [user] [path]     Create systemd service"
    echo "  cloud <platform>          Deploy to cloud (aws/gcp/azure/heroku)"
    echo "  status <platform>         Show deployment status"
    echo "  help                      Show this help message"
    echo
    echo "Examples:"
    echo "  $0 docker                 # Build Docker image"
    echo "  $0 docker-hub myuser      # Push to Docker Hub"
    echo "  $0 k8s-deploy production  # Deploy to k8s production namespace"
    echo "  $0 helm-deploy myapp      # Deploy with Helm"
    echo "  $0 cloud aws              # Deploy to AWS"
    echo "  $0 status k8s             # Show Kubernetes status"
}

# Main function
main() {
    if [[ $# -eq 0 ]]; then
        show_help
        exit 0
    fi
    
    case "$1" in
        docker)
            create_docker_image
            ;;
        docker-hub)
            create_docker_image
            deploy_docker_hub "$2" "$3"
            ;;
        k8s|kubernetes)
            create_k8s_manifests
            ;;
        k8s-deploy)
            deploy_k8s "$2"
            ;;
        helm)
            create_helm_chart
            ;;
        helm-deploy)
            deploy_helm "$2" "$3"
            ;;
        systemd)
            create_systemd_service "$2" "$3"
            ;;
        cloud)
            deploy_cloud "$2"
            ;;
        status)
            show_status "$2"
            ;;
        help|--help|-h)
            show_help
            ;;
        *)
            log_error "Unknown command: $1"
            echo "Use '$0 help' for available commands"
            exit 1
            ;;
    esac
}

# Run main function
main "$@"